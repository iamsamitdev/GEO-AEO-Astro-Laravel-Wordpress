#!/usr/bin/env bash
# scripts/wait-for-api.sh - ปลุก API ให้ตื่นก่อน build
# จำเป็นเมื่อ API อยู่บน PaaS แผนฟรี (เช่น Render) ที่หลับหลังไม่มี traffic 15 นาที
# และใช้เวลาตื่นราว 1 นาที ถ้าไม่ปลุกก่อน Astro จะ fetch ไม่ทันแล้ว build ล้มเหลว
set -euo pipefail

API_URL="${API_URL:-http://127.0.0.1:8000}"
ATTEMPTS="${WAIT_ATTEMPTS:-24}"      # 24 ครั้ง x 5 วินาที = รอสูงสุด 2 นาที
SLEEP_SECONDS="${WAIT_SLEEP:-5}"

echo "▶ ปลุก API ที่ $API_URL/api/health"

for i in $(seq 1 "$ATTEMPTS"); do
  if curl -sf -m 15 -o /dev/null "$API_URL/api/health"; then
    echo "✓ API พร้อมแล้ว (ครั้งที่ $i)"
    exit 0
  fi
  echo "  ยังไม่ตอบ รออีก ${SLEEP_SECONDS}s ($i/$ATTEMPTS)"
  sleep "$SLEEP_SECONDS"
done

echo "✗ API ไม่ตอบภายใน $((ATTEMPTS * SLEEP_SECONDS)) วินาที - ยกเลิก build"
exit 1
