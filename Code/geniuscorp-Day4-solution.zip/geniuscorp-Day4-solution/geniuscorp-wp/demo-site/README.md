# GeniusCorp WP Demo Site (ไฟล์ WXR สำหรับ Workshop Day 3)

ไฟล์ `geniuscorp-wp-demo.xml` คือ WordPress eXtended RSS (WXR 1.2) ที่มีเนื้อหาเหมือน GeniusCorp Modern
แต่ตั้งใจใส่ "ปัญหา GEO" ไว้ครบชุดตาม Day3_note.md เพื่อให้ผู้เรียนทำ Retrofit

## วิธี Import (ใช้ได้กับ WordPress เปล่าทุกแบบ ไม่ต้องมี plugin เสริม)

0. ก่อน Import: Appearance → Themes → Add New → ติดตั้งและ Activate **Astra** (แทน Twenty Twenty-Five ซึ่งเป็น block theme ที่ Child Theme ของคอร์สไม่รองรับ) และเปิดใช้ Rank Math + ACF ตาม Day3_note.md ขั้นที่ 0
1. เข้า `/wp-admin` → Tools → Import → WordPress → **Install Now** → **Run Importer**
2. เลือกไฟล์ `geniuscorp-wp-demo.xml` → Upload file and import
3. Assign Authors: เลือก "assign posts to an existing user" = ผู้ใช้ของคุณ (ไม่ต้องติ๊ก Download attachments เพราะไม่มีรูป)
4. Settings → Reading → "A static page": Homepage = **หน้าแรก**, Posts page = **บทความ** → Save
5. Settings → General: ชื่อเว็บ = `GeniusCorp` และ Tagline (คำโปรย) วางข้อความนี้ `บริษัทพัฒนาเว็บ แอป ซอฟต์แวร์ ERP CRM ครบวงจร ราคาถูก คุณภาพดี บริการทั่วประเทศ รับทำเว็บไซต์ รับเขียนโปรแกรม รับทำแอป` → Save (Importer ไม่แตะ Settings จึงต้องตั้งเอง เป็นการจำลองปัญหาข้อ 3 ที่จะแก้ใน Module 3)
6. Settings → Permalinks → Post name → Save (flush rewrite)
7. เปิด http://geniuscorp.test/ ตรวจว่าเห็นหน้าแรก (สร้างเมนูที่ Appearance → Menus ถ้า theme ไม่แสดงอัตโนมัติ)

## ปัญหาที่ตั้งใจใส่ไว้ (ตรงกับตาราง "ทัวร์ปัญหา" ใน Day3_note.md)

| # | ปัญหา | อยู่ที่ |
|---|---|---|
| 1 | H1 ซ้ำ (theme + ในเนื้อหา) | หน้าบริการทั้ง 3 หน้า (Page ธรรมดา) |
| 2 | หน้าแรกไม่มี H1, ตัวเลขสถิติเป็น H2, การ์ดเป็น H2 | หน้าแรก, หน้า "บริการ" |
| 3 | Tagline ยาว keyword stuffing → Title หน้าแรกยาว 120+ (Rank Math ใช้ `%sitedesc%` ในหน้าแรก) และ Tagline โผล่ทุกหน้าใน header/footer ของ theme | **ผู้เรียนตั้งเอง** ในขั้นตอน Import ข้อ 5 (Settings → General → Tagline) เพราะ WXR ไม่นำเข้า Settings |
| 4 | ไม่มี excerpt → description auto จาก boilerplate เดียวกันทุกหน้า | ทุกโพสต์และหน้าบริการ |
| 8 | บริการเป็น Page ธรรมดา ไม่มี CPT, ไม่มีราคา/FAQ แบบมีโครงสร้าง | /web-development/ ฯลฯ |
| 11 | post_modified เท่ากันทุกโพสต์ (2026-09-12) | ทุก item |

ปัญหาข้อ 5-7, 9-10, 12 (canonical pagination, Schema ซ้ำจาก plugin, รูปใหญ่, plugin 23 ตัว, llms.txt)
ขึ้นกับ theme/plugin ที่ติดตั้ง: ข้อ 6-7 เห็นได้ทันทีเมื่อเปิด Rank Math (Schema Article ทุก post type, ชื่อองค์กรเก่าจาก Setup Wizard) + Astra (Schema microdata ในแท็ก HTML) ส่วนข้อ 9-10 ผู้สอนสาธิต

## ไฟล์ "หลังแก้": geniuscorp-wp-demo-after.xml (เฉลยฝั่งเนื้อหา)

เนื้อหาเดียวกันที่ทำ Retrofit ฝั่งเนื้อหาเสร็จแล้ว: H1 เดียวและมีความหมายทุกหน้า (hero หน้าแรกเป็น H1), การ์ดเป็น H3,
excerpt 70-170 ตัวอักษรทุกโพสต์, ย่อหน้าแรกตอบคำถามหลัก, บริการ 3 ตัวเป็น CPT `service` พร้อม price_from / duration_days
และ FAQ 4 ข้อต่อบริการ (เก็บ 2 แบบ: postmeta แบบ ACF Repeater สำหรับ ACF PRO และ CPT `faq` ผูกด้วย slug สำหรับ ACF ฟรี),
post_modified ต่างกันทุกโพสต์ · **ไม่มีหน้า Page "บริการ" และ 3 หน้าบริการแบบ Page** เพราะย้ายเป็น CPT แล้ว

ใช้กับ **เว็บเปล่า** (ยังไม่ Import ไฟล์ก่อนแก้ หรือลบเนื้อหาเดิมออกก่อน เพราะ Importer จะข้ามโพสต์ที่ชื่อ+วันที่ซ้ำ):

1. ติดตั้ง Astra + Rank Math + ACF ตามขั้นที่ 0 ใน Day3_note.md แล้ว **Activate Child Theme `geniuscorp-geo` ก่อน** (ไม่งั้น post type service/faq ยังไม่มี Importer จะข้าม)
2. Tools → Import → WordPress → เลือก `geniuscorp-wp-demo-after.xml` → assign author = ผู้ใช้ของคุณ
3. Settings → Reading → Homepage = หน้าแรก, Posts page = บทความ → Settings → Permalinks → Save
4. Tools → **GEO Setup** → กดปุ่ม (ตั้ง Rank Math + Tagline ตามตาราง Module 3.2)
5. เปิด `/services/web-development/` → View Source ต้องเห็น JSON-LD block เดียวที่มี Service + Offer + FAQPage + BreadcrumbList และ `<h1` 1 ตัว
6. (Day 4) รัน `fix-lastmod-after-import.sql` เพราะ Importer ตั้ง post_modified = post_date

ผลทดสอบไฟล์นี้บน WordPress 7.1 + Astra 4.13 + Rank Math 1.0.278 + ACF ฟรี: ผ่าน Checklist กลุ่ม A-C ครบ (ดูตารางใน Day3_note.md Workshop ขั้นที่ 2)

## รหัสผ่านและผู้ใช้

ไฟล์นี้ **ไม่มี** รหัสผ่านใด ๆ ผู้เรียนใช้บัญชี admin ที่สร้างเองตอนติดตั้ง WordPress

## หลัง Retrofit เสร็จ (การบ้าน Day 3)

ย้ายหน้าบริการ 3 หน้าจาก Page เป็น CPT `service` (สร้างใหม่ + คัดลอกเนื้อหา หรือใช้ plugin "Post Type Switcher")
แล้วตั้ง Redirect 301 ใน Rank Math → Redirections: `/web-development/` → `/services/web-development/` (ทำครบ 3 หน้า)
