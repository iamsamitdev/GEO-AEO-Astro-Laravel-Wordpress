<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class IssueBuildToken extends Command
{
    protected $signature = 'geo:issue-build-token
                            {--email=astro-build@geniuscorp.example : อีเมลของผู้ใช้ที่จะออก token ให้}
                            {--name=astro-build : ชื่อ token}
                            {--token= : กำหนดค่า token เอง (ใช้บน PaaS ที่ฐานข้อมูลถูกสร้างใหม่ทุกครั้ง)}';

    protected $description = 'ออก Sanctum token แบบอ่านอย่างเดียว (content:read) สำหรับ Astro build process';

    public function handle(): int
    {
        $user = User::where('email', $this->option('email'))->first();

        if (! $user) {
            $this->error('ไม่พบผู้ใช้ ' . $this->option('email') . ' - รัน php artisan db:seed ก่อน');
            return self::FAILURE;
        }

        $name  = (string) $this->option('name');
        $plain = (string) $this->option('token');

        $user->tokens()->where('name', $name)->delete();

        if ($plain !== '') {
            if (mb_strlen($plain) < 32) {
                $this->error('--token ต้องยาวอย่างน้อย 32 ตัวอักษร (สุ่มด้วย openssl rand -hex 24)');
                return self::FAILURE;
            }

            /**
             * สร้าง token จากค่าที่กำหนดเอง: Sanctum เก็บเฉพาะ hash และรองรับ token
             * ที่ไม่มีส่วน "{id}|" ด้วยการค้นจาก hash ตรง ๆ จึงใช้ค่าเดิมซ้ำได้ทุกครั้งที่ deploy
             */
            $user->tokens()->create([
                'name'      => $name,
                'token'     => hash('sha256', $plain),
                'abilities' => ['content:read'],
            ]);

            $this->info('ออก token จากค่าที่กำหนดเองสำเร็จ (ค่าเดิมกับ BUILD_TOKEN/API_TOKEN)');

            return self::SUCCESS;
        }

        $token = $user->createToken($name, ['content:read']);

        $this->info('สร้าง token สำเร็จ นำค่าด้านล่างไปใส่ใน .env ของโปรเจกต์ Astro (API_TOKEN=...)');
        $this->newLine();
        $this->line($token->plainTextToken);

        return self::SUCCESS;
    }
}
