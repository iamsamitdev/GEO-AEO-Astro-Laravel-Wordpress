# Day 3 - WordPress GEO/AEO (โค้ดเฉลย = Day2 + geniuscorp-wp)

## ติดตั้ง

1. WordPress เปล่าในเครื่อง (ตาม precourse ส่วน B) พร้อม theme และ plugin ตามนี้ (ตรงกับ Day3_note.md "ขั้นที่ 0"):

   | Theme / Plugin | สถานะ | เหตุผล |
   |---|---|---|
   | **Theme Astra** (ฟรี) | **เปิดใช้งาน** แทน Twenty Twenty-Five | Child Theme นี้เป็น classic theme (`single-service.php`, `get_header()`) ใช้กับ block theme อย่าง Twenty Twenty-Five ไม่ได้ และ `style.css` ตั้ง `Template: astra` ไว้แล้ว |
   | Rank Math SEO (หรือ Yoast) | **เปิดใช้งาน** | Child Theme พึ่งพา filter ของมัน (`geo-cleanup.php`, `geo-metadata.php`, `geo-post-types.php`) และปล่อยให้มันทำ Title/Meta/Canonical/Sitemap |
   | Advanced Custom Fields | **เปิดใช้งาน** (PRO ถ้ามี; ฟรีใช้ได้ แต่ FAQ จะเป็น CPT `faq` แทน Repeater) | ฟิลด์ price_from / duration_days / faqs / job_title ใน `geo-post-types.php`, `geo-faq.php`, `geo-eeat.php` |
   | Query Monitor | ติดตั้ง เปิดได้ | ใช้หา callback ของ theme ในข้อ 4 |
   | LiteSpeed Cache (หรือ WP Super Cache) | ติดตั้ง **ยังไม่เปิด** | เปิดตอน Module 6 เท่านั้น |
2. Import Demo Site: `geniuscorp-wp/demo-site/geniuscorp-wp-demo.xml` (อ่าน `demo-site/README.md`)
3. คัดลอก `geniuscorp-wp/wp-content/themes/geniuscorp-geo/` ไปที่ `wp-content/themes/` ของเว็บ
4. ถ้าใช้ Astra ตามคอร์ส ไม่ต้องแก้อะไร · ถ้าเว็บจริงใช้ classic theme อื่น แก้ `Template:` ใน `style.css` ให้ตรงกับชื่อโฟลเดอร์ parent (เช่น `generatepress`) และแก้ `remove_action` ใน `inc/geo-cleanup.php` / filter ใน `inc/geo-headings.php` ให้ตรงกับ theme นั้น (ดูชื่อ callback จาก Query Monitor)
5. Appearance → Themes → Activate **GeniusCorp GEO**
6. Settings → Permalinks → Save (flush rewrite ให้ CPT `service`)
7. ตั้งค่า Rank Math ตามตาราง Day3_note.md หัวข้อ 3.2 (Schema Type = None สำหรับ post/service) หรือกดปุ่มใน **Tools → GEO Setup** (หน้าเดียวกันแสดงตารางค่าก่อน-หลังทุก key)
8. แก้เนื้อหาตาม Module 3.4 / การบ้าน (excerpt, H1, ย้ายบริการเป็น CPT) หรือดูสภาพที่ทำเสร็จแล้วจาก `demo-site/geniuscorp-wp-demo-after.xml` (Import ลงเว็บเปล่า - อ่าน `demo-site/README.md`)

> ⚠️ เปิด Child Theme อย่างเดียว **ไม่** ทำให้ Checklist ผ่าน 20 ข้อ: โค้ดจัดการได้เฉพาะกลุ่ม A (canonical, cleanup, JSON-LD, heading) ส่วน B ตั้งค่า plugin และ C เนื้อหา ต้องทำตามข้อ 7-8 (ตารางแบ่งกลุ่มอยู่ใน Day3_note.md Workshop ขั้นที่ 2)

## โครงสร้าง Child Theme

```
geniuscorp-geo/
├── style.css                 ← header + CSS ของ FAQ/breadcrumb/facts/author-box
├── functions.php             ← enqueue + require inc/*.php
├── header.php.example        ← ตัวอย่าง override โลโก้ (ถ้า theme ไม่มี filter)
├── single-service.php        ← หน้าบริการ
├── archive-service.php       ← หน้ารวมบริการ (การ์ดเป็น H3)
├── template-parts/faq.php, breadcrumb.php
├── assets/logo.png, og-default.png   ← placeholder แทนที่ด้วยรูปจริง
└── inc/
    ├── geo-cleanup.php       ← ลบ head noise, ปิด Schema ของ Rank Math/Yoast/Theme, ปิด XML-RPC
    ├── geo-post-types.php    ← CPT service + ACF fields (price_from, duration_days, faqs)
    ├── geo-metadata.php      ← บังคับ excerpt, canonical filter, OG เสริม
    ├── geo-headings.php      ← โลโก้เป็น <p>, <h1> ในเนื้อหา → <h2>, H1 หน้าแรก/Posts page (Astra/GeneratePress/Kadence)
    ├── geo-schema.php        ← gc_site(), builders, gc_build_graph(), wp_head
    ├── geo-faq.php           ← gc_get_faqs() (Repeater หรือ CPT faq ผูกด้วย ID/slug), guideline ใน Admin
    ├── geo-performance.php   ← dequeue, jquery-migrate, WebP, image sizes, LCP
    └── geo-setup.php         ← Tools → GEO Setup: ตั้งค่า Rank Math/Tagline ปุ่มเดียว + ตารางก่อน-หลัง
```

## การบ้าน

ย้ายบริการ 3 หน้าจาก Page → CPT `service` (ไม่คัดลอก `<h1>` ติดไป) ใส่ excerpt/ราคา/ระยะเวลา/FAQ → Trash Page "บริการ" + 3 หน้าบริการเดิม → Permalinks → Save (URL `/services/` จะเป็น archive ของ CPT เมื่อไม่มี Page slug นี้) → ตั้ง 301 จาก URL เดิมใน Rank Math → Redirections, รัน `demo-site/fix-lastmod-after-import.sql` (มีใน Day4) หลัง backup
