# Day 2 - GEO Core Engineering (โค้ดเฉลย = Day1 + GEO Layer)

## ติดตั้ง

เหมือน Day 1 (ถ้าเริ่มจากโฟลเดอร์นี้โดยตรง: ทำตาม Day1/README.md แต่ใช้ไฟล์จาก Day2)

## สิ่งที่เพิ่มจาก Day 1

**Laravel**
- `app/Http/Controllers/Api/V1/FaqController.php` + route `GET /api/v1/faqs?service=slug`
- `FaqResource` ส่ง `service` เมื่อโหลดมา

**Astro**
- `src/lib/site.ts` ค่ากลางองค์กร + `absoluteUrl()`
- `src/lib/schema.ts` builders: organization, website, webPage, service, article, person, breadcrumb, faq, portfolio, itemList + `graph()`
- `src/components/SeoHead.astro` title/description/canonical/OG/Twitter/hreflang/noindex (เตือนใน build log ถ้ายาวเกิน)
- `src/components/JsonLd.astro` clean + escape `<`,`>`,`&`,U+2028/2029 + `set:html`
- `src/components/Breadcrumb.astro`, `src/components/FaqSection.astro` (`<details>` Zero-JS)
- `src/layouts/BaseLayout.astro` รับ `seo` props + `<slot name="head" />`
- ทุกหน้าใน `src/pages/` ใส่ `seo={...}` + `<JsonLd slot="head" />` ตาม spec ใน Day2_note.md
- `scripts/check-geo.mjs` + `package.json` → `"build": "astro build && node scripts/check-geo.mjs"`

## ทดสอบ

```bash
npm run build     # ต้องจบด้วย ✓ GEO check ผ่านทุกหน้า (14 หน้า)
```
แล้วนำ `dist/services/web-development/index.html` ไปวางใน validator.schema.org (Code Snippet) → 0 errors
