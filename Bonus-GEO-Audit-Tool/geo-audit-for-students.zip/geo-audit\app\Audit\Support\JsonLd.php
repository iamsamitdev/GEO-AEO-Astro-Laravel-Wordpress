<?php

namespace App\Audit\Support;

/**
 * เดินโครงสร้าง JSON-LD ที่ดึงมาจากหน้า
 *
 * รองรับรูปแบบที่เจอจริง: @graph, @type เป็น array, node ซ้อนใน property,
 * และหลาย <script type="application/ld+json"> ในหน้าเดียว
 */
final class JsonLd
{
    /** @var list<array> node ทั้งหมดที่แบนแล้ว (ทุกระดับ) */
    public readonly array $nodes;

    /** @param list<mixed> $blocks บล็อกที่ decode สำเร็จแล้ว */
    public function __construct(public readonly array $blocks, public readonly array $parseErrors = [])
    {
        $nodes = [];
        foreach ($blocks as $block) {
            self::flatten($block, $nodes);
        }
        $this->nodes = $nodes;
    }

    public function isEmpty(): bool
    {
        return $this->blocks === [];
    }

    /** @return list<string> @type ทุกตัวที่พบในหน้า */
    public function types(): array
    {
        $types = [];
        foreach ($this->nodes as $node) {
            foreach (self::typesOf($node) as $t) {
                $types[$t] = true;
            }
        }

        return array_keys($types);
    }

    public function hasType(string $type): bool
    {
        return in_array($type, $this->types(), true);
    }

    /** node แรกที่เป็น @type ที่ระบุ */
    public function firstOfType(string $type): ?array
    {
        foreach ($this->nodes as $node) {
            if (in_array($type, self::typesOf($node), true)) {
                return $node;
            }
        }

        return null;
    }

    /** @return list<array> */
    public function allOfType(string $type): array
    {
        return array_values(array_filter(
            $this->nodes,
            fn ($node) => in_array($type, self::typesOf($node), true)
        ));
    }

    /**
     * คู่ [property, value] ของ property วันที่ทั้งหมด - ใช้ตรวจ ISO 8601
     *
     * @return list<array{0:string,1:mixed}>
     */
    public function dateValues(): array
    {
        $out = [];
        foreach ($this->nodes as $node) {
            foreach ($node as $k => $v) {
                if (is_string($k) && preg_match('/^date(Published|Modified|Created)$/', $k) && ! is_array($v)) {
                    $out[] = [$k, $v];
                }
            }
        }

        return $out;
    }

    /** @return list<string> ค่า @id ทุกตัวที่ประกาศไว้ */
    public function declaredIds(): array
    {
        $ids = [];
        foreach ($this->nodes as $node) {
            if (isset($node['@id']) && is_string($node['@id'])) {
                $ids[$node['@id']] = true;
            }
        }

        return array_keys($ids);
    }

    /** @return list<string> @id ที่ถูกอ้างถึงจากที่อื่น (node ที่มีแค่ {"@id": ...}) */
    public function referencedIds(): array
    {
        $refs = [];
        foreach ($this->nodes as $node) {
            foreach ($node as $k => $v) {
                if ($k === '@id') {
                    continue;
                }
                foreach (is_array($v) && array_is_list($v) ? $v : [$v] as $item) {
                    if (is_array($item) && isset($item['@id']) && count($item) === 1 && is_string($item['@id'])) {
                        $refs[$item['@id']] = true;
                    }
                }
            }
        }

        return array_keys($refs);
    }

    /** @return list<string> */
    public static function typesOf(array $node): array
    {
        $t = $node['@type'] ?? null;

        if (is_string($t)) {
            return [$t];
        }
        if (is_array($t)) {
            return array_values(array_filter($t, 'is_string'));
        }

        return [];
    }

    /** อ่านค่าจาก node โดยยอมรับทั้ง string, {"@value":...} และ array ตัวแรก */
    public static function scalar(array $node, string $key): ?string
    {
        $v = $node[$key] ?? null;

        if (is_string($v)) {
            return $v;
        }
        if (is_array($v)) {
            if (isset($v['@value']) && is_string($v['@value'])) {
                return $v['@value'];
            }
            if (array_is_list($v) && isset($v[0])) {
                return is_string($v[0]) ? $v[0] : (is_array($v[0]) ? self::scalar($v[0], 'name') : null);
            }
            if (isset($v['name']) && is_string($v['name'])) {
                return $v['name'];
            }
            if (isset($v['url']) && is_string($v['url'])) {
                return $v['url'];
            }
        }

        return null;
    }

    private static function flatten(mixed $value, array &$out): void
    {
        if (is_array($value) && array_is_list($value)) {
            foreach ($value as $item) {
                self::flatten($item, $out);
            }

            return;
        }

        if (! is_array($value)) {
            return;
        }

        if (isset($value['@graph'])) {
            self::flatten($value['@graph'], $out);
        }

        if (self::typesOf($value) !== []) {
            $out[] = $value;
        }

        foreach ($value as $k => $v) {
            if ($k === '@graph' || ! is_array($v)) {
                continue;
            }
            self::flatten($v, $out);
        }
    }
}
