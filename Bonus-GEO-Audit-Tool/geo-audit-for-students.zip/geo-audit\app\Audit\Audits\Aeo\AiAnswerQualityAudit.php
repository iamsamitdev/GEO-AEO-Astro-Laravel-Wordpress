<?php

namespace App\Audit\Audits\Aeo;

use App\Audit\Ai\AnswerQualityJudge;
use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Content\Section;
use App\Audit\Support\Text;

/**
 * ให้ Claude ตัดสินว่าคำตอบใต้หัวข้อ "ตอบจริง" หรือแค่ "ยาวพอ"
 *
 * เป็น audit ตัวเดียวในระบบที่ไม่ได้ตัดสินด้วยกฎ จึงถูกกำกับไว้สองชั้น:
 *   1. ทำงานเฉพาะเมื่อเปิดโหมด AI และตั้ง API key แล้ว
 *   2. ถ้าเรียกไม่สำเร็จจะคืน N/A ไม่ใช่ 0 - หน้าเว็บไม่ควรถูกหักคะแนน
 *      เพราะปัญหาที่ฝั่งเครื่องมือของเรา
 */
final class AiAnswerQualityAudit extends BaseAudit
{
    public function __construct(private readonly AnswerQualityJudge $judge) {}

    public function id(): string
    {
        return 'ai-answer-quality';
    }

    public function title(): string
    {
        return 'คุณภาพคำตอบตามการประเมินของ Claude';
    }

    public function category(): Category
    {
        return Category::Aeo;
    }

    public function weight(): float
    {
        return 2.5;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        if (! $this->judge->enabled()) {
            return $this->na('ปิดโหมดตรวจด้วย AI อยู่');
        }

        $pairs = [];
        foreach ($ctx->document->sections() as $section) {
            if (! $section instanceof Section || $section->heading === null) {
                continue;
            }

            $answer = $section->firstParagraph();
            if (Text::wordCount($answer) < 12) {
                continue;
            }

            $pairs[] = [
                'heading' => $section->title(),
                'answer' => Text::truncate($answer, 900),
            ];
        }

        if ($pairs === []) {
            return $this->na('ไม่มีคู่หัวข้อและย่อหน้าที่ยาวพอจะประเมิน');
        }

        $verdict = $this->judge->judge($pairs, $ctx->document->title());

        if ($verdict['error'] !== null) {
            return $this->na('ประเมินด้วย AI ไม่สำเร็จ: ' . $verdict['error']);
        }

        $details = [];
        $weak = 0;

        foreach ($verdict['items'] as $item) {
            $flags = [];
            if (! $item['answers_directly']) {
                $flags[] = 'ไม่ได้ตอบตรงคำถาม';
            }
            if (! $item['self_contained']) {
                $flags[] = 'อ่านเดี่ยว ๆ ไม่เข้าใจ';
            }

            if ($flags !== [] || $item['score'] < 0.7) {
                $weak++;
                $line = Text::truncate($item['heading'], 45) . ' (' . number_format($item['score'], 2) . ')';
                if ($flags !== []) {
                    $line .= ' - ' . implode(', ', $flags);
                }
                if ($item['issue'] !== '') {
                    $line .= ' - ' . $item['issue'];
                }
                $details[] = $line;
            }
        }

        $total = count($verdict['items']);
        array_unshift($details, "ประเมินโดย Claude: {$total} หัวข้อ · ที่ยังอ่อน {$weak} หัวข้อ");
        $details[] = 'หมายเหตุ: ข้อนี้เป็นการตัดสินโดยโมเดลภาษา จึงมีความผันผวนระหว่างครั้ง ให้ใช้เป็นแนวทาง ไม่ใช่คำตัดสินเด็ดขาด';

        $score = $verdict['overall'];

        if ($score >= 0.9) {
            return $this->result($score, "คะแนนเฉลี่ย " . number_format($score, 2), $details, '', true);
        }

        return $this->result(
            $score,
            'คะแนนเฉลี่ย ' . number_format($score, 2) . " · อ่อน {$weak}/{$total} หัวข้อ",
            $details,
            'แก้หัวข้อที่ระบุด้านบนให้ประโยคแรกตอบคำถามตรง ๆ และแทนคำอ้างอิงย้อนด้วยชื่อสิ่งที่พูดถึงจริง',
            true
        );
    }
}
