<?php

namespace App\Audit\Ai;

use Anthropic\Client;
use Anthropic\Core\Exceptions\APIStatusException;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * ให้ Claude อ่านคู่ "หัวข้อคำถาม + ย่อหน้าคำตอบ" แล้วให้คะแนนตามเกณฑ์
 *
 * ทำไมต้องมีชั้นนี้ทั้งที่มี audit แบบกฎอยู่แล้ว:
 * กฎบอกได้แค่ว่าย่อหน้ายาวเท่าไรและขึ้นต้นด้วยคำเกริ่นหรือไม่
 * แต่บอกไม่ได้ว่า "ย่อหน้านี้ตอบคำถามในหัวข้อจริงหรือเปล่า"
 * ซึ่งเป็นสิ่งเดียวที่สำคัญจริงในการถูกหยิบไปอ้างอิง
 *
 * ชั้นนี้เป็นทางเลือก ปิดไว้เป็นค่าเริ่มต้น เพราะมีค่าใช้จ่ายต่อการเรียกและช้ากว่า
 */
final class AnswerQualityJudge
{
    /** ตัดจำนวนคู่ที่ส่งไป เพื่อให้ต้นทุนต่อหน้าคาดเดาได้ */
    private const MAX_PAIRS = 8;

    public function __construct(
        private readonly ?string $apiKey,
        private readonly string $model = 'claude-opus-5',
    ) {}

    public static function fromConfig(): self
    {
        return new self(
            apiKey: config('geoaudit.anthropic_key'),
            model: config('geoaudit.anthropic_model', 'claude-opus-5'),
        );
    }

    public function enabled(): bool
    {
        return is_string($this->apiKey) && trim($this->apiKey) !== '';
    }

    /**
     * @param  list<array{heading:string, answer:string}>  $pairs
     * @return array{
     *     overall: float,
     *     items: list<array{heading:string, answers_directly:bool, self_contained:bool, score:float, issue:string}>,
     *     error: ?string
     * }
     */
    public function judge(array $pairs, string $pageTitle): array
    {
        if (! $this->enabled()) {
            return ['overall' => 0.0, 'items' => [], 'error' => 'ยังไม่ได้ตั้งค่า ANTHROPIC_API_KEY'];
        }

        $pairs = array_slice($pairs, 0, self::MAX_PAIRS);

        if ($pairs === []) {
            return ['overall' => 0.0, 'items' => [], 'error' => 'ไม่มีคู่หัวข้อ-คำตอบให้ประเมิน'];
        }

        try {
            $client = new Client(apiKey: $this->apiKey);

            $message = $client->messages->create(
                model: $this->model,
                maxTokens: 8000,
                system: [
                    ['type' => 'text', 'text' => $this->systemPrompt(), 'cacheControl' => ['type' => 'ephemeral']],
                ],
                messages: [
                    ['role' => 'user', 'content' => $this->userPrompt($pairs, $pageTitle)],
                ],
                outputConfig: [
                    'effort' => 'low',
                    'format' => [
                        'type' => 'json_schema',
                        'schema' => $this->schema(),
                    ],
                ],
            );
        } catch (APIStatusException $e) {
            Log::warning('AnswerQualityJudge failed', ['type' => $e->type?->value, 'message' => $e->getMessage()]);

            return ['overall' => 0.0, 'items' => [], 'error' => 'เรียก Claude API ไม่สำเร็จ: ' . ($e->type?->value ?? $e->getMessage())];
        } catch (Throwable $e) {
            Log::warning('AnswerQualityJudge failed', ['message' => $e->getMessage()]);

            return ['overall' => 0.0, 'items' => [], 'error' => 'เรียก Claude API ไม่สำเร็จ'];
        }

        if ($message->stopReason === 'refusal') {
            return ['overall' => 0.0, 'items' => [], 'error' => 'โมเดลปฏิเสธคำขอนี้'];
        }

        $json = null;
        foreach ($message->content as $block) {
            if ($block->type === 'text') {
                $json = json_decode($block->text, true);
                break;
            }
        }

        if (! is_array($json) || ! isset($json['items']) || ! is_array($json['items'])) {
            return ['overall' => 0.0, 'items' => [], 'error' => 'ผลลัพธ์จากโมเดลไม่อยู่ในรูปแบบที่คาดไว้'];
        }

        $items = [];
        $scores = [];

        foreach ($json['items'] as $index => $item) {
            if (! is_array($item)) {
                continue;
            }

            $score = (float) ($item['score'] ?? 0);
            $score = max(0.0, min(1.0, $score));
            $scores[] = $score;

            $items[] = [
                'heading' => (string) ($pairs[$index]['heading'] ?? ($item['heading'] ?? '')),
                'answers_directly' => (bool) ($item['answers_directly'] ?? false),
                'self_contained' => (bool) ($item['self_contained'] ?? false),
                'score' => $score,
                'issue' => (string) ($item['issue'] ?? ''),
            ];
        }

        return [
            'overall' => $scores === [] ? 0.0 : array_sum($scores) / count($scores),
            'items' => $items,
            'error' => null,
        ];
    }

    private function systemPrompt(): string
    {
        return <<<'PROMPT'
        คุณกำลังประเมินเนื้อหาเว็บในมุมของระบบที่ไปหยิบข้อความมาตอบคำถามผู้ใช้ (AI Search / RAG)

        ระบบนั้นจะตัดหน้าเว็บเป็นชิ้น ๆ ตามหัวข้อ แล้วเลือกมาแค่ไม่กี่ชิ้นไปประกอบคำตอบ
        โดยชิ้นที่ถูกเลือกจะถูกอ่านแบบเดี่ยว ๆ ไม่มีบริบทของหน้าอื่นหรือหัวข้ออื่นติดไปด้วย

        ให้ประเมินแต่ละคู่ (หัวข้อ, ย่อหน้าแรกใต้หัวข้อ) ด้วยเกณฑ์นี้:

        answers_directly - ย่อหน้านี้ตอบคำถามหรือประเด็นในหัวข้อได้จริงหรือไม่
          true  เมื่อผู้อ่านได้คำตอบจากย่อหน้านี้โดยไม่ต้องอ่านต่อ
          false เมื่อเป็นการเกริ่นนำ เล่าที่มา สัญญาว่าจะอธิบายทีหลัง หรือพูดกว้าง ๆ ไม่ตรงคำถาม

        self_contained - อ่านย่อหน้านี้เดี่ยว ๆ แล้วเข้าใจได้หรือไม่
          false เมื่อมีคำแทนที่ไม่รู้ว่าแทนอะไร ("สิ่งนี้", "เครื่องมือดังกล่าว")
                หรืออ้างถึงเนื้อหาที่อยู่นอกย่อหน้า ("ตามที่กล่าวข้างต้น", "ในตารางด้านบน")

        score - ค่าระหว่าง 0.0 ถึง 1.0 ว่าถ้าระบบหยิบชิ้นนี้ไปตอบคำถามของผู้ใช้ มันจะใช้ได้ดีแค่ไหน
          1.0 ตอบตรง จบในตัว มีรายละเอียดที่เจาะจงพอจะอ้างอิงได้
          0.5 พอใช้ได้แต่ต้องอ่านเพิ่มหรือคลุมเครือบางจุด
          0.0 ใช้ตอบไม่ได้เลย

        issue - ปัญหาหลักหนึ่งข้อเป็นภาษาไทย สั้น ๆ ไม่เกิน 20 คำ ถ้าไม่มีปัญหาให้ใส่สตริงว่าง

        ตอบกลับตามลำดับเดียวกับที่ได้รับ และให้จำนวนรายการเท่ากับที่ได้รับเสมอ
        ประเมินเฉพาะสิ่งที่อยู่ในข้อความ อย่าเดาเนื้อหาส่วนที่ไม่ได้ให้มา
        PROMPT;
    }

    /** @param list<array{heading:string, answer:string}> $pairs */
    private function userPrompt(array $pairs, string $pageTitle): string
    {
        $lines = ["ชื่อหน้า: {$pageTitle}", '', 'คู่หัวข้อและย่อหน้าที่ต้องประเมิน:'];

        foreach ($pairs as $index => $pair) {
            $number = $index + 1;
            $lines[] = '';
            $lines[] = "[{$number}] หัวข้อ: {$pair['heading']}";
            $lines[] = "ย่อหน้า: {$pair['answer']}";
        }

        $lines[] = '';
        $lines[] = 'ประเมินให้ครบทั้ง ' . count($pairs) . ' รายการ ตามลำดับเดิม';

        return implode("\n", $lines);
    }

    private function schema(): array
    {
        return [
            'type' => 'object',
            'properties' => [
                'items' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                            'heading' => ['type' => 'string'],
                            'answers_directly' => ['type' => 'boolean'],
                            'self_contained' => ['type' => 'boolean'],
                            'score' => ['type' => 'number'],
                            'issue' => ['type' => 'string'],
                        ],
                        'required' => ['heading', 'answers_directly', 'self_contained', 'score', 'issue'],
                        'additionalProperties' => false,
                    ],
                ],
            ],
            'required' => ['items'],
            'additionalProperties' => false,
        ];
    }
}
