<?php

namespace App\Audit\Audits\Seo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\Text;

/**
 * meta description มีอยู่ ยาวพอดี และเป็นบทสรุปจริง ไม่ใช่คำโปรย
 *
 * ในบริบท AI Search คำอธิบายนี้ทำหน้าที่เป็น "บทคัดย่อ" ของหน้า
 * ที่ถูกอ่านก่อนตัดสินใจว่าจะเปิดเนื้อหาเต็มหรือไม่ จึงควรเป็นสรุปที่ให้ข้อมูลจริง
 */
final class MetaDescriptionAudit extends BaseAudit
{
    public function id(): string
    {
        return 'meta-description';
    }

    public function title(): string
    {
        return 'meta description เป็นบทสรุปที่ใช้ได้';
    }

    public function category(): Category
    {
        return Category::Seo;
    }

    public function weight(): float
    {
        return 2.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $description = $ctx->document->metaContent('description');

        if ($description === null) {
            return $this->fail(
                'ไม่มี meta description',
                'เขียนคำอธิบาย 120-165 ตัวอักษรที่สรุปว่าหน้านี้ตอบอะไร โดยดึงจากย่อหน้าแรกของเนื้อหาจริง อย่าปล่อยให้ระบบตัดคำอัตโนมัติ',
                []
            );
        }

        $length = Text::length($description);
        $details = [
            'description: ' . Text::truncate($description, 180),
            "ความยาว: {$length} ตัวอักษร (ช่วงที่เหมาะ 120-165)",
        ];

        $score = 1.0;
        $issues = [];

        if ($length < 60) {
            $score -= 0.45;
            $issues[] = 'สั้นเกินไป';
        } elseif ($length < 120) {
            $score -= 0.15;
            $issues[] = 'สั้นกว่าช่วงที่ใช้พื้นที่ได้เต็ม';
        } elseif ($length > 200) {
            $score -= 0.25;
            $issues[] = 'ยาวเกินจนถูกตัด';
        }

        if (str_ends_with(trim($description), '...') || str_ends_with(trim($description), '…')) {
            $score -= 0.25;
            $issues[] = 'ลงท้ายด้วยจุดไข่ปลา (น่าจะเกิดจากการตัดคำอัตโนมัติ)';
        }

        $ogDescription = $ctx->document->propertyContent('og:description');
        if ($ogDescription === null) {
            $details[] = 'ไม่มี og:description';
        }

        if ($issues === []) {
            return $this->pass("{$length} ตัวอักษร", $details);
        }

        return $this->partial(
            max(0.0, $score),
            implode(' · ', $issues),
            'เขียนคำอธิบายด้วยมือหรือดึงจากช่องสรุปที่บรรณาธิการกรอกเอง ให้เป็นประโยคสมบูรณ์ที่บอกได้ว่าหน้านี้ตอบคำถามอะไร',
            $details
        );
    }
}
