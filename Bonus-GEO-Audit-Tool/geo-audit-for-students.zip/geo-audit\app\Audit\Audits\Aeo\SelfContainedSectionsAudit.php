<?php

namespace App\Audit\Audits\Aeo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Content\Section;
use App\Audit\Support\Text;

/**
 * แต่ละหัวข้อเข้าใจได้ด้วยตัวเอง หรือต้องอ่านย้อนขึ้นไปก่อน
 *
 * เวลา AI หยิบเนื้อหาไปตอบ มันหยิบไปแค่ชิ้นเดียว ไม่ได้เอาทั้งหน้าไปด้วย
 * ประโยคอย่าง "จากที่กล่าวไปข้างต้น เครื่องมือนี้จึงเหมาะกับ..." พอถูกตัดออกมาเดี่ยว ๆ
 * จะกลายเป็นข้อความที่ไม่รู้ว่าพูดถึงอะไร และมักถูกทิ้งไปเลย
 *
 * ทางแก้คือพูดชื่อสิ่งที่อ้างถึงซ้ำ แทนการใช้คำแทน
 */
final class SelfContainedSectionsAudit extends BaseAudit
{
    /** คำที่ชี้ย้อนไปหาบริบทนอกชิ้นเนื้อหา */
    private const BACK_REFERENCES = [
        'ที่กล่าวไปข้างต้น', 'ตามที่กล่าวมา', 'ดังที่กล่าวไป', 'ข้างต้น', 'ด้านบน',
        'ในหัวข้อก่อนหน้า', 'ที่พูดถึงไปแล้ว', 'จากตัวอย่างข้างบน', 'ดังกล่าว',
        'as mentioned above', 'as discussed earlier', 'the above', 'previously mentioned',
        'in the previous section', 'as we saw',
    ];

    /** คำแทนที่ขึ้นต้นย่อหน้าแล้วไม่รู้ว่าแทนอะไร */
    private const OPENING_PRONOUNS = [
        'สิ่งนี้', 'อันนี้', 'มันจึง', 'เขาจึง', 'ตัวนี้', 'แบบนี้จึง',
        'this is', 'it is also', 'they are', 'these are', 'that is why',
    ];

    public function id(): string
    {
        return 'self-contained-sections';
    }

    public function title(): string
    {
        return 'แต่ละหัวข้อเข้าใจได้โดยไม่ต้องอ่านย้อน';
    }

    public function category(): Category
    {
        return Category::Aeo;
    }

    public function weight(): float
    {
        return 1.5;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $sections = array_values(array_filter(
            $ctx->document->sections(),
            fn (Section $s) => $s->heading !== null && Text::wordCount($s->text()) >= 20
        ));

        if (count($sections) < 2) {
            return $this->na('มีหัวข้อย่อยน้อยเกินกว่าจะประเมิน');
        }

        $offenders = [];

        foreach ($sections as $section) {
            $text = mb_strtolower($section->text(), 'UTF-8');
            $opening = mb_strtolower(mb_substr($section->firstParagraph(), 0, 40, 'UTF-8'), 'UTF-8');
            $found = [];

            foreach (self::BACK_REFERENCES as $phrase) {
                if (str_contains($text, mb_strtolower($phrase, 'UTF-8'))) {
                    $found[] = $phrase;
                }
            }

            foreach (self::OPENING_PRONOUNS as $pronoun) {
                if (str_starts_with($opening, mb_strtolower($pronoun, 'UTF-8'))) {
                    $found[] = 'ขึ้นต้นด้วย "' . $pronoun . '"';
                }
            }

            if ($found !== []) {
                $offenders[] = [
                    'title' => Text::truncate($section->title(), 45),
                    'phrases' => array_slice(array_unique($found), 0, 2),
                ];
            }
        }

        $total = count($sections);
        $bad = count($offenders);
        $details = ["หัวข้อที่ตรวจ: {$total} · พบการอ้างย้อน {$bad} หัวข้อ"];

        foreach (array_slice($offenders, 0, 5) as $offender) {
            $details[] = "{$offender['title']} - " . implode(', ', $offender['phrases']);
        }

        if ($bad === 0) {
            return $this->pass("ทั้ง {$total} หัวข้อจบในตัว", $details);
        }

        $score = max(0.0, 1.0 - ($bad / $total) * 1.4);

        return $this->partial(
            $score,
            "{$bad}/{$total} หัวข้ออ้างย้อนไปหาบริบทนอกตัวเอง",
            'เขียนชื่อสิ่งที่อ้างถึงซ้ำแทนการใช้คำแทน เช่น เปลี่ยน "เครื่องมือนี้" เป็น "Rank Math" - ให้ลองอ่านทีละหัวข้อโดยปิดส่วนที่เหลือ ถ้ายังเข้าใจได้ก็ผ่าน',
            $details
        );
    }
}
