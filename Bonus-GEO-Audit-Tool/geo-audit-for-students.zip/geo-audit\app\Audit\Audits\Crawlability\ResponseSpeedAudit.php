<?php

namespace App\Audit\Audits\Crawlability;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;

/**
 * เซิร์ฟเวอร์ตอบเร็วพอและ HTML ไม่บวมเกินไป
 *
 * ตั้งใจให้เป็นการวัดแบบหยาบ ไม่ใช่การแทน Lighthouse
 * เราสนใจแค่มุมของบอท: บอทที่วิ่งมาตอนมีคนถามมี timeout สั้น
 * และ HTML ที่มีโค้ดมากกว่าข้อความ ทำให้สัดส่วนเนื้อหาต่อ token ต่ำ
 */
final class ResponseSpeedAudit extends BaseAudit
{
    public function id(): string
    {
        return 'response-speed';
    }

    public function title(): string
    {
        return 'ตอบเร็วและ HTML ไม่บวม';
    }

    public function category(): Category
    {
        return Category::Crawlability;
    }

    public function weight(): float
    {
        return 1.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        if ($ctx->offline) {
            return $this->na('โหมดตรวจไฟล์ในเครื่อง ไม่มีเวลาตอบสนองให้วัด');
        }

        $ms = $ctx->response->elapsedMs;
        $kb = $ctx->response->bytes() / 1024;
        $textLength = mb_strlen($ctx->document->bodyText(), 'UTF-8');
        $htmlLength = max(1, mb_strlen($ctx->response->body, 'UTF-8'));
        $textRatio = $textLength / $htmlLength;

        $details = [
            'เวลาตอบกลับทั้งหมด: ' . round($ms) . ' ms',
            'ขนาด HTML: ' . round($kb, 1) . ' KB',
            'สัดส่วนข้อความต่อ HTML: ' . round($textRatio * 100, 1) . '%',
        ];

        if ($ctx->response->truncated) {
            $details[] = 'หน้าใหญ่เกิน 3 MB จึงถูกตัดตอนอ่าน';
        }

        $score = 1.0;
        $issues = [];

        if ($ms > 3000) {
            $score -= 0.45;
            $issues[] = 'ตอบช้ากว่า 3 วินาที';
        } elseif ($ms > 1500) {
            $score -= 0.2;
            $issues[] = 'ตอบช้ากว่า 1.5 วินาที';
        }

        if ($kb > 800) {
            $score -= 0.3;
            $issues[] = 'HTML ใหญ่กว่า 800 KB';
        } elseif ($kb > 300) {
            $score -= 0.15;
            $issues[] = 'HTML ใหญ่กว่า 300 KB';
        }

        if ($textRatio < 0.03) {
            $score -= 0.25;
            $issues[] = 'ข้อความจริงน้อยกว่า 3% ของ HTML';
        }

        if ($issues === []) {
            return $this->pass(round($ms) . ' ms · ' . round($kb) . ' KB', $details);
        }

        return $this->partial(
            $score,
            implode(' · ', $issues),
            'เปิด gzip/brotli, ลด inline script และ CSS ที่ไม่ใช้, และแคช HTML ที่ขอบ - บอทที่วิ่งตอนผู้ใช้ถามคำถามมักรอไม่เกิน 2-3 วินาทีก่อนตัดทิ้ง',
            $details
        );
    }
}
