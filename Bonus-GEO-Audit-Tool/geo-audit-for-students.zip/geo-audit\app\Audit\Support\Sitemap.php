<?php

namespace App\Audit\Support;

use XMLReader;

/**
 * อ่าน sitemap.xml แบบสตรีม
 *
 * sitemap ของเว็บจริงใหญ่ได้ถึง 50 MB (ตามสเปกคือ 50,000 URL)
 * การโหลดทั้งไฟล์เข้า simplexml แล้วเก็บทุก entry ไว้ในหน่วยความจำ
 * ทำให้ทั้งช้าและเสี่ยงเกิน memory_limit บนโฮสต์ที่ใช้ร่วมกับคนอื่น
 *
 * ที่นี่จึงอ่านทีละ node แล้วเก็บเฉพาะสิ่งที่ audit ต้องใช้จริง:
 *   - จำนวน URL ทั้งหมด
 *   - entry ของหน้าที่กำลังตรวจ (ถ้าเจอ)
 *   - entry ชุดแรกไว้ใช้เป็นจุดตั้งต้นตอน crawl
 *   - การกระจายของ lastmod รายวัน ไว้ดูว่าเป็นวันที่ build หรือวันที่แก้จริง
 */
final class Sitemap
{
    private const MAX_KEPT_ENTRIES = 500;

    /**
     * @param  list<array{loc:string, lastmod:?string}>  $entries
     * @param  array<string, int>  $lastmodByDay
     */
    private function __construct(
        public readonly bool $valid,
        public readonly bool $isIndex,
        public readonly int $totalUrls,
        public readonly array $entries,
        public readonly ?array $matchedEntry,
        public readonly array $lastmodByDay,
        public readonly int $withLastmod,
    ) {}

    public static function invalid(): self
    {
        return new self(false, false, 0, [], null, [], 0);
    }

    /**
     * @param  string|null  $lookFor  URL ที่อยากได้ entry ของมันโดยเฉพาะ
     */
    public static function parse(string $xml, ?string $lookFor = null): self
    {
        if (trim($xml) === '') {
            return self::invalid();
        }

        // sitemap.xml.gz ส่งมาเป็นไบต์ gzip ตรง ๆ ไม่ได้ผ่าน Content-Encoding
        if (str_starts_with($xml, "\x1f\x8b")) {
            $inflated = @gzdecode($xml);
            if (is_string($inflated) && $inflated !== '') {
                $xml = $inflated;
            }
        }

        $parsed = self::parseStrict($xml, $lookFor);

        /*
         * XMLReader ปฏิเสธเอกสารที่ไม่ well-formed ทั้งฉบับ อ่านได้ 0 node
         * ซึ่งเกิดทุกครั้งที่ sitemap ถูกตัดเพราะใหญ่เกินเพดาน
         * กรณีนั้นค่อยถอยไปกวาดหา <loc> แบบดิบ ๆ ดีกว่ารายงานว่า "ไม่มี sitemap"
         */
        if (! $parsed->valid && str_contains($xml, '<loc')) {
            return self::scanLoose($xml, $lookFor);
        }

        return $parsed;
    }

    private static function parseStrict(string $xml, ?string $lookFor): self
    {
        $reader = new XMLReader;

        $previous = libxml_use_internal_errors(true);
        $opened = @$reader->XML($xml, 'UTF-8', LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);

        if (! $opened) {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);

            return self::invalid();
        }

        $needle = $lookFor === null ? null : self::normalize($lookFor);

        $isIndex = false;
        $total = 0;
        $withLastmod = 0;
        $entries = [];
        $matched = null;
        $byDay = [];

        $currentLoc = null;
        $currentLastmod = null;
        $field = null;

        // อ่านจนจบหรือจนเจอ XML พังกลางทาง (เช่นไฟล์ถูกตัด) - ที่อ่านได้ก่อนหน้านั้นยังใช้ได้
        while (@$reader->read()) {
            if ($reader->nodeType === XMLReader::ELEMENT) {
                $name = self::localName($reader->name);

                if ($name === 'sitemapindex') {
                    $isIndex = true;
                }

                if ($name === 'url' || $name === 'sitemap') {
                    $currentLoc = null;
                    $currentLastmod = null;
                }

                $field = in_array($name, ['loc', 'lastmod'], true) ? $name : null;

                continue;
            }

            if ($field !== null && ($reader->nodeType === XMLReader::TEXT || $reader->nodeType === XMLReader::CDATA)) {
                $value = trim($reader->value);
                if ($field === 'loc') {
                    $currentLoc = $value;
                } else {
                    $currentLastmod = $value === '' ? null : $value;
                }

                continue;
            }

            if ($reader->nodeType === XMLReader::END_ELEMENT) {
                $name = self::localName($reader->name);

                if ($name === 'loc' || $name === 'lastmod') {
                    $field = null;

                    continue;
                }

                if (($name !== 'url' && $name !== 'sitemap') || $currentLoc === null || $currentLoc === '') {
                    continue;
                }

                $total++;
                $entry = ['loc' => $currentLoc, 'lastmod' => $currentLastmod];

                if ($currentLastmod !== null) {
                    $withLastmod++;
                    $day = substr($currentLastmod, 0, 10);
                    $byDay[$day] = ($byDay[$day] ?? 0) + 1;
                }

                if (count($entries) < self::MAX_KEPT_ENTRIES) {
                    $entries[] = $entry;
                }

                if ($needle !== null && $matched === null && self::normalize($currentLoc) === $needle) {
                    $matched = $entry;
                }

                $currentLoc = null;
                $currentLastmod = null;
            }
        }

        $reader->close();
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        return new self(
            valid: $total > 0,
            isIndex: $isIndex,
            totalUrls: $total,
            entries: $entries,
            matchedEntry: $matched,
            lastmodByDay: $byDay,
            withLastmod: $withLastmod,
        );
    }

    /**
     * กวาดหา <loc> และ <lastmod> โดยไม่สนใจความถูกต้องของ XML
     *
     * ใช้ strpos ไล่ทีละตัวแทน preg_match_all เพราะไฟล์อาจใหญ่หลายสิบเมกะไบต์
     * การสร้างอาร์เรย์ผลลัพธ์ทั้งก้อนพร้อมกันจะกินหน่วยความจำเกินจำเป็น
     */
    private static function scanLoose(string $xml, ?string $lookFor): self
    {
        $needle = $lookFor === null ? null : self::normalize($lookFor);

        $total = 0;
        $withLastmod = 0;
        $entries = [];
        $matched = null;
        $byDay = [];

        $offset = 0;
        while (($start = strpos($xml, '<loc', $offset)) !== false) {
            $open = strpos($xml, '>', $start);
            $end = $open === false ? false : strpos($xml, '</loc>', $open);

            if ($open === false || $end === false) {
                break;
            }

            $loc = trim(html_entity_decode(substr($xml, $open + 1, $end - $open - 1), ENT_QUOTES | ENT_XML1, 'UTF-8'));
            $loc = trim(str_replace(['<![CDATA[', ']]>'], '', $loc));
            $offset = $end + 6;

            if ($loc === '') {
                continue;
            }

            // lastmod ของ entry เดียวกันต้องอยู่ก่อนจุดเริ่มของ <loc> ถัดไป
            $lastmod = null;
            $nextLoc = strpos($xml, '<loc', $offset);
            $lastmodPos = strpos($xml, '<lastmod', $offset);
            if ($lastmodPos !== false && ($nextLoc === false || $lastmodPos < $nextLoc)) {
                $lmOpen = strpos($xml, '>', $lastmodPos);
                $lmEnd = $lmOpen === false ? false : strpos($xml, '</lastmod>', $lmOpen);
                if ($lmOpen !== false && $lmEnd !== false) {
                    $value = trim(substr($xml, $lmOpen + 1, $lmEnd - $lmOpen - 1));
                    $lastmod = $value === '' ? null : $value;
                }
            }

            $total++;
            $entry = ['loc' => $loc, 'lastmod' => $lastmod];

            if ($lastmod !== null) {
                $withLastmod++;
                $day = substr($lastmod, 0, 10);
                $byDay[$day] = ($byDay[$day] ?? 0) + 1;
            }

            if (count($entries) < self::MAX_KEPT_ENTRIES) {
                $entries[] = $entry;
            }

            if ($needle !== null && $matched === null && self::normalize($loc) === $needle) {
                $matched = $entry;
            }
        }

        return new self(
            valid: $total > 0,
            isIndex: str_contains($xml, '<sitemapindex'),
            totalUrls: $total,
            entries: $entries,
            matchedEntry: $matched,
            lastmodByDay: $byDay,
            withLastmod: $withLastmod,
        );
    }

    /** lastmod ของทุกหน้าเป็นวันเดียวกันเกือบหมด = น่าจะใส่วันที่ build ไม่ใช่วันที่แก้เนื้อหา */
    public function lastmodLooksLikeBuildStamp(): bool
    {
        if ($this->withLastmod < 5 || $this->lastmodByDay === []) {
            return false;
        }

        return max($this->lastmodByDay) / $this->withLastmod > 0.8;
    }

    public static function normalize(string $url): string
    {
        return Url::normalize($url);
    }

    private static function localName(string $name): string
    {
        $pos = strpos($name, ':');

        return $pos === false ? $name : substr($name, $pos + 1);
    }
}
