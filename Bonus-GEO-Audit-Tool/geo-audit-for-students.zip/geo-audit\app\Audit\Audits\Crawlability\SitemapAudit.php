<?php

namespace App\Audit\Audits\Crawlability;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;

/**
 * มี sitemap.xml ที่ประกาศไว้ใน robots.txt และมีหน้านี้อยู่ในนั้น พร้อม lastmod ที่เชื่อถือได้
 *
 * lastmod ที่เป็นวันที่ build ทุกหน้าเท่ากันหมด แย่กว่าไม่มี lastmod เลย
 * เพราะมันบอกว่า "ทุกหน้าเพิ่งแก้พร้อมกัน" ซึ่งไม่จริง และทำให้บอทเลิกเชื่อค่านี้
 */
final class SitemapAudit extends BaseAudit
{
    public function id(): string
    {
        return 'sitemap';
    }

    public function title(): string
    {
        return 'อยู่ใน sitemap.xml พร้อม lastmod ที่ถูกต้อง';
    }

    public function category(): Category
    {
        return Category::Crawlability;
    }

    public function weight(): float
    {
        return 1.5;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        if ($ctx->offline) {
            return $this->na('โหมดตรวจไฟล์ในเครื่อง ไม่มี sitemap ให้ตรวจ');
        }

        $site = $ctx->site;

        if (! $site->hasSitemap()) {
            $status = $site->sitemapResponse?->status;
            $truncated = $site->sitemapResponse?->truncated ?? false;

            return $this->fail(
                'ไม่พบ sitemap.xml ที่ใช้งานได้',
                'สร้าง sitemap.xml ที่รวมทุกหน้าที่ต้องการให้ค้นเจอ แล้วประกาศไว้ใน robots.txt ด้วยบรรทัด Sitemap: https://.../sitemap.xml',
                array_filter([
                    $status !== null ? "สถานะที่ได้จากที่อยู่ sitemap: {$status}" : 'ยิงหา sitemap ไม่สำเร็จ',
                    $truncated ? 'sitemap ใหญ่เกินเพดานที่เครื่องมือนี้อ่านได้' : '',
                    $site->declaredSitemapInRobots()
                        ? 'robots.txt ประกาศ Sitemap ไว้: ' . implode(', ', $site->robots->sitemaps)
                        : 'robots.txt ไม่ได้ประกาศบรรทัด Sitemap',
                ])
            );
        }

        $sitemap = $site->sitemap;
        $entry = $site->sitemapEntryForAuditedUrl();
        $declaredInRobots = $site->declaredSitemapInRobots();

        $details = [
            'ที่อยู่ sitemap ที่ใช้ได้: ' . ($site->sitemapUrl ?? '-'),
            "จำนวน URL ที่อ่านได้: {$sitemap->totalUrls}",
            'ประกาศไว้ใน robots.txt: ' . ($declaredInRobots ? 'ใช่' : 'ไม่ (บอทต้องเดาว่าอยู่ที่ /sitemap.xml)'),
        ];

        $score = 1.0;
        $issues = [];

        if (! $declaredInRobots) {
            $score -= 0.2;
            $issues[] = 'ไม่ได้ประกาศ Sitemap ใน robots.txt';
        }

        if ($entry === null) {
            $score -= 0.45;
            $issues[] = 'ไม่พบหน้านี้ใน sitemap';
        } else {
            $details[] = 'lastmod ของหน้านี้: ' . ($entry['lastmod'] ?? 'ไม่ระบุ');

            if ($entry['lastmod'] === null) {
                $score -= 0.2;
                $issues[] = 'ไม่มี lastmod';
            } elseif (! $this->isValidW3cDate($entry['lastmod'])) {
                $score -= 0.25;
                $issues[] = 'lastmod ไม่ใช่รูปแบบ W3C Datetime';
            } elseif ($sitemap->lastmodLooksLikeBuildStamp()) {
                $score -= 0.3;
                $issues[] = 'lastmod เหมือนกันแทบทุกหน้า (น่าจะใส่วันที่ build แทนวันที่แก้เนื้อหาจริง)';
                $details[] = 'มี lastmod ' . $sitemap->withLastmod . ' หน้า แต่กระจุกอยู่วันเดียวถึง ' . max($sitemap->lastmodByDay) . ' หน้า';
            }
        }

        if ($issues === []) {
            return $this->pass("อยู่ใน sitemap ({$sitemap->totalUrls} URL) พร้อม lastmod ที่ใช้ได้", $details);
        }

        return $this->partial(
            $score,
            implode(' · ', $issues),
            'sitemap ควรมีทุกหน้าที่ต้องการให้ค้นเจอ และ lastmod ต้องมาจากวันที่แก้เนื้อหาจริงของหน้านั้น (เช่น updated_at ในฐานข้อมูล) ไม่ใช่เวลาที่รัน build',
            $details
        );
    }

    private function isValidW3cDate(string $value): bool
    {
        return (bool) preg_match(
            '/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2}))?$/',
            trim($value)
        );
    }
}
