<?php

namespace App\Audit\Audits\StructuredData;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;

/**
 * มี JSON-LD และ parse ได้จริง
 *
 * ข้อผิดพลาดที่เจอบ่อยที่สุดคือ JSON พังเงียบ ๆ เพราะ CMS แทรกเครื่องหมายคำพูด
 * หรือขึ้นบรรทัดใหม่ในค่า string ผลคือหน้าดูเหมือนมี schema แต่เครื่องอ่านไม่ได้เลย
 */
final class JsonLdPresentAudit extends BaseAudit
{
    public function id(): string
    {
        return 'jsonld-present';
    }

    public function title(): string
    {
        return 'มี JSON-LD ที่อ่านได้';
    }

    public function category(): Category
    {
        return Category::StructuredData;
    }

    public function weight(): float
    {
        return 3.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $jsonLd = $ctx->jsonLd();
        $rawBlocks = preg_match_all('#<script\b[^>]*application/ld\+json#i', $ctx->response->body);

        if ($rawBlocks === 0) {
            $microdata = $ctx->document->has('//*[@itemscope]');
            $rdfa = $ctx->document->has('//*[@vocab or @typeof]');

            return $this->fail(
                'ไม่มี JSON-LD เลย',
                'เพิ่ม <script type="application/ld+json"> ที่บอกอย่างน้อยว่าหน้านี้เป็นอะไร ใครเผยแพร่ และแก้ล่าสุดเมื่อไร - JSON-LD คือรูปแบบที่ทั้ง Google และผู้ให้บริการ AI แนะนำ',
                array_filter([
                    $microdata ? 'พบ Microdata (itemscope) แทน - ใช้ได้แต่ครอบคลุมน้อยกว่าและแก้ยากกว่า' : '',
                    $rdfa ? 'พบ RDFa แทน' : '',
                ])
            );
        }

        if ($jsonLd->parseErrors !== []) {
            $broken = count($jsonLd->parseErrors);

            return $this->partial(
                $jsonLd->isEmpty() ? 0.0 : 0.35,
                "JSON-LD {$broken} จาก {$rawBlocks} บล็อกอ่านไม่ได้",
                'แก้ JSON ให้ถูกไวยากรณ์ - สาเหตุที่พบบ่อยคือเครื่องหมายคำพูดในเนื้อหาไม่ได้ escape, มีจุลภาคเกินท้ายรายการ, หรือ CMS ตัดข้อความกลางคัน ควร encode ด้วย json_encode ไม่ใช่ประกอบ string เอง',
                array_map(fn ($e) => "ข้อผิดพลาด: {$e}", $jsonLd->parseErrors)
            );
        }

        $types = $jsonLd->types();

        if ($types === []) {
            return $this->partial(
                0.4,
                'JSON-LD อ่านได้แต่ไม่มี @type',
                'ทุก node ต้องมี @type ไม่งั้นเครื่องไม่รู้ว่ากำลังอธิบายอะไรอยู่',
                []
            );
        }

        return $this->pass(
            count($jsonLd->nodes) . ' node · ' . count($types) . ' ชนิด',
            ['ชนิดที่พบ: ' . implode(', ', $types)]
        );
    }
}
