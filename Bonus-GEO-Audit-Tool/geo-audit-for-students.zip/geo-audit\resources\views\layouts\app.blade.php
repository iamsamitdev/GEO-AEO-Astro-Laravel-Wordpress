<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'GEO Audit - ตรวจความพร้อม SEO/GEO/AEO')</title>
    <meta name="description" content="@yield('description', 'ตรวจว่าหน้าเว็บของคุณพร้อมให้ ChatGPT, Gemini, Perplexity และ Claude ค้นเจอและอ้างอิงหรือยัง ให้คะแนน 6 หมวดพร้อมบอกว่าต้องแก้อะไรก่อน')">
    <meta name="robots" content="@yield('robots', 'index, follow')">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    {{--
        Inter สำหรับอักษรละติน + Anuphan สำหรับภาษาไทย
        เบราว์เซอร์เลือกฟอนต์ทีละตัวอักษรตามลำดับใน font-family
        Inter ไม่มีสระและพยัญชนะไทย ตัวอักษรไทยจึงตกไปที่ Anuphan เองโดยอัตโนมัติ
    --}}
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Anuphan:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap">
    <link rel="stylesheet" href="{{ \App\Support\Asset::url('css/app.css') }}">
</head>
<body>
    <header class="site-header">
        <div class="wrap-wide">
            <a href="{{ route('home') }}" class="brand-mark">GEO<span>Audit</span></a>
            <nav>
                <a href="{{ route('home') }}">ตรวจเว็บ</a>
                <a href="{{ route('about') }}">เกณฑ์การให้คะแนน</a>
            </nav>
        </div>
    </header>

    <main>
        @yield('content')
    </main>

    <div class="wrap-wide">
        <footer class="site-footer">
            คะแนนที่แสดงเป็นเกณฑ์ประเมินของเครื่องมือนี้เอง ไม่ใช่ตัวเลขที่ผู้ให้บริการ AI ประกาศ
            อ่านที่มาของน้ำหนักแต่ละหมวดได้ที่ <a href="{{ route('about') }}">หน้าเกณฑ์การให้คะแนน</a>
        </footer>
    </div>

    @stack('scripts')
</body>
</html>
