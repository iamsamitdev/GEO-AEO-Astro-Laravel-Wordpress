<?php

namespace App\Audit\Audits\Crawlability;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\Text;

/**
 * เนื้อหาอยู่ใน HTML ที่เซิร์ฟเวอร์ส่งมา หรือรอ JavaScript สร้าง
 *
 * นี่คือข้อที่ Lighthouse ไม่ตรวจให้ แต่เป็นข้อที่ฆ่า GEO ได้เงียบที่สุด
 * Googlebot มีคิว render ให้ แต่ GPTBot, ClaudeBot, PerplexityBot ส่วนใหญ่ไม่รัน JS
 * เว็บ SPA ที่ดูสมบูรณ์ในเบราว์เซอร์ จึงเป็นหน้าว่างเปล่าในสายตา AI
 *
 * เราตรวจโดยดู HTML ดิบล้วน ๆ เพราะนั่นคือสิ่งที่บอทเหล่านั้นได้รับจริง
 */
final class NoJsDependencyAudit extends BaseAudit
{
    private const MIN_WORDS = 120;

    public function id(): string
    {
        return 'no-js-dependency';
    }

    public function title(): string
    {
        return 'เนื้อหาอ่านได้โดยไม่ต้องรัน JavaScript';
    }

    public function category(): Category
    {
        return Category::Crawlability;
    }

    public function weight(): float
    {
        return 3.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $doc = $ctx->document;
        $text = $doc->bodyText();
        $words = Text::wordCount($text);
        $scripts = $doc->externalScriptCount();
        $headings = count($doc->headings());

        $details = [
            "คำที่อ่านได้จาก HTML ดิบ: {$words} คำ",
            "หัวข้อ (h1-h6) ที่พบใน HTML ดิบ: {$headings}",
            "สคริปต์ภายนอก: {$scripts} ไฟล์",
        ];

        // ร่องรอยคลาสสิกของ SPA ที่ยังไม่ render: กล่องรากว่างเปล่า
        $emptyRoots = $doc->query('//div[@id="root" or @id="app" or @id="__next" or @id="___gatsby"][not(normalize-space(.))]');
        if ($emptyRoots !== []) {
            $details[] = 'พบกล่องราก (#root/#app/#__next) ที่ยังว่างเปล่าใน HTML ดิบ';
        }

        if ($words < 30) {
            return $this->fail(
                "HTML ดิบแทบไม่มีเนื้อหาเลย ({$words} คำ)",
                'หน้านี้สร้างเนื้อหาด้วย JavaScript ฝั่งเบราว์เซอร์ AI crawler ส่วนใหญ่จะเห็นหน้าว่าง ต้องเปลี่ยนไปใช้ SSR หรือ SSG (Astro, Next.js SSG, Nuxt generate) หรือทำ prerender ให้ bot',
                $details
            );
        }

        if ($emptyRoots !== [] && $words < 300) {
            return $this->partial(
                0.35,
                "เนื้อหาบางส่วนน่าจะมาจาก JavaScript ({$words} คำใน HTML ดิบ)",
                'ย้ายเนื้อหาหลักไปเรนเดอร์ฝั่งเซิร์ฟเวอร์ ให้ HTML ที่ส่งออกมามีข้อความครบตั้งแต่แรก',
                $details
            );
        }

        if ($words < self::MIN_WORDS) {
            return $this->partial(
                0.6,
                "HTML ดิบมีเนื้อหาน้อย ({$words} คำ)",
                'หน้าที่จะถูกอ้างอิงได้ควรมีเนื้อหาอย่างน้อยราว ' . self::MIN_WORDS . ' คำใน HTML ที่ส่งมาจากเซิร์ฟเวอร์ ถ้านี่เป็นหน้ารวมรายการโดยเจตนา ให้เพิ่มคำอธิบายประกอบหมวด',
                $details
            );
        }

        if ($headings === 0) {
            return $this->partial(
                0.7,
                "มีเนื้อหา {$words} คำ แต่ไม่มีหัวข้อเลยใน HTML ดิบ",
                'ใส่ h1-h3 ลงใน HTML ที่เรนเดอร์จากเซิร์ฟเวอร์ ระบบ retrieval ใช้หัวข้อในการตัดชิ้นเนื้อหา',
                $details
            );
        }

        return $this->pass("อ่านได้ {$words} คำโดยไม่ต้องรัน JS", $details);
    }
}
