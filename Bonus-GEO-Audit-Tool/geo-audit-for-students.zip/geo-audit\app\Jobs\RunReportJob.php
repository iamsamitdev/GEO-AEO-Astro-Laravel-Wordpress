<?php

namespace App\Jobs;

use App\Audit\Ai\AnswerQualityJudge;
use App\Audit\AuditRunner;
use App\Audit\Http\Fetcher;
use App\Audit\PageReport;
use App\Audit\SiteContext;
use App\Models\PageResult;
use App\Models\Report;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Storage;
use Throwable;
use ZipArchive;

/**
 * รันรายงานหนึ่งฉบับ - หน้าเดียว, ทั้งเว็บ, หรือไฟล์ที่อัปโหลด
 *
 * ทำงานในคิวเสมอ ไม่ใช่ในรอบ request เพราะการตรวจทั้งเว็บใช้เวลาเป็นนาที
 * และหน้าเดียวก็ยังต้องยิง HTTP หลายครั้ง (หน้า + robots + sitemap + llms.txt)
 * ซึ่งเกิน max_execution_time ของโฮสต์ที่ใช้ร่วมกับคนอื่นได้ง่าย
 */
class RunReportJob implements ShouldQueue
{
    use Queueable;

    public int $timeout = 1800;

    public int $tries = 1;

    public function __construct(public readonly int $reportId) {}

    public function handle(): void
    {
        $report = Report::find($this->reportId);

        if ($report === null || $report->status !== 'queued') {
            return;
        }

        $report->update(['status' => 'running', 'started_at' => now()]);

        try {
            match ($report->mode) {
                'url' => $this->runSinglePage($report),
                'site' => $this->runSite($report),
                'upload' => $this->runUpload($report),
                'files' => $this->runFiles($report),
                default => throw new \RuntimeException("โหมด {$report->mode} ไม่รองรับ"),
            };
        } catch (Throwable $e) {
            report($e);
            $report->update([
                'status' => 'failed',
                'error' => $e->getMessage(),
                'finished_at' => now(),
            ]);

            return;
        }

        $this->finish($report);
    }

    public function failed(Throwable $e): void
    {
        Report::where('id', $this->reportId)->update([
            'status' => 'failed',
            'error' => 'งานล้มเหลว: ' . $e->getMessage(),
            'finished_at' => now(),
        ]);
    }

    private function runner(Report $report): AuditRunner
    {
        return new AuditRunner(
            judge: $report->use_ai ? AnswerQualityJudge::fromConfig() : null,
        );
    }

    private function runSinglePage(Report $report): void
    {
        $report->update(['pages_total' => 1]);

        $page = $this->runner($report)->auditUrl($report->target);
        $this->store($report, $page, 0);
    }

    private function runSite(Report $report): void
    {
        $fetcher = new Fetcher;
        $runner = $this->runner($report);

        $site = SiteContext::forUrl($report->target, $fetcher, $report->target);
        $limit = max(1, (int) config('geoaudit.crawl_limit'));
        $delay = max(0, (int) config('geoaudit.crawl_delay_ms')) * 1000;

        $urls = $site->crawlSeeds($limit);

        // หน้าที่ผู้ใช้ใส่มาต้องอยู่ในรายการเสมอ แม้ sitemap จะไม่มีมัน
        if (! in_array($report->target, $urls, true)) {
            array_unshift($urls, $report->target);
            $urls = array_slice($urls, 0, $limit);
        }

        $report->update(['pages_total' => count($urls)]);

        foreach ($urls as $position => $url) {
            // robots.txt ห้ามหน้าไหน เราก็ไม่ไปดึงหน้านั้น เครื่องมือตรวจต้องเคารพกฎเอง
            if (! $site->robots->allows(Fetcher::userAgent(), parse_url($url, PHP_URL_PATH) ?: '/')) {
                continue;
            }

            $this->store($report, $runner->auditWithSite($url, $site), $position);

            if ($delay > 0 && $position < count($urls) - 1) {
                usleep($delay);
            }
        }
    }

    private function runUpload(Report $report): void
    {
        $zipPath = Storage::disk('local')->path('uploads/' . $report->ulid . '.zip');

        if (! is_file($zipPath)) {
            throw new \RuntimeException('ไม่พบไฟล์ที่อัปโหลด');
        }

        $extractTo = Storage::disk('local')->path('uploads/' . $report->ulid);
        $this->extract($zipPath, $extractTo);

        // ไม่ได้กรอกโดเมนจริงมา ต้องสมมติขึ้นเพื่อให้ URL ประกอบได้
        // แล้วบอก audit ว่าค่านี้เชื่อถือไม่ได้ ห้ามเอาไปเทียบกับ canonical
        $syntheticBase = blank($report->label);
        $baseUrl = rtrim($report->label ?: 'https://uploaded.local', '/');
        $files = $this->htmlFiles($extractTo);
        $limit = max(1, (int) config('geoaudit.crawl_limit'));
        $files = array_slice($files, 0, $limit);

        $report->update(['pages_total' => count($files)]);

        if ($files === []) {
            throw new \RuntimeException('ไม่พบไฟล์ .html ในไฟล์ zip ที่อัปโหลด');
        }

        $runner = $this->runner($report);

        foreach ($files as $position => $file) {
            $url = $baseUrl . $this->pathToUrl($extractTo, $file);
            $html = file_get_contents($file) ?: '';
            $this->store($report, $runner->auditHtml($url, $html, $syntheticBase), $position);
        }

        // ลบไฟล์ที่แตกออกและ zip ต้นฉบับทันทีที่ตรวจเสร็จ ไม่เก็บโค้ดของผู้ใช้ไว้บนเซิร์ฟเวอร์
        $this->deleteTree($extractTo);
        @unlink($zipPath);
    }

    /**
     * ตรวจไฟล์ .html ที่อัปโหลดมาทีละไฟล์ (ไม่ผ่าน zip)
     *
     * ต่างจากโหมด zip ตรงที่ไม่มีโครงโฟลเดอร์ให้ใช้เดา path
     * เรามีแค่ชื่อไฟล์ ผู้ใช้จึงระบุประเภทหน้าเองได้ผ่าน forced_page_type
     */
    private function runFiles(Report $report): void
    {
        $directory = 'uploads/' . $report->ulid;
        $files = collect(Storage::disk('local')->files($directory))
            ->filter(fn (string $path) => preg_match('/\.html?$/i', $path) === 1)
            ->sort()
            ->values();

        if ($files->isEmpty()) {
            throw new \RuntimeException('ไม่พบไฟล์ที่อัปโหลด');
        }

        $syntheticBase = blank($report->label);
        $baseUrl = rtrim($report->label ?: 'https://uploaded.local', '/');
        $forcedType = $report->forcedPageType();

        $report->update(['pages_total' => $files->count()]);

        $runner = $this->runner($report);

        foreach ($files as $position => $path) {
            $html = Storage::disk('local')->get($path) ?? '';
            $url = $baseUrl . $this->fileNameToUrl(basename($path));

            $this->store($report, $runner->auditHtml($url, $html, $syntheticBase, $forcedType), $position);
        }

        Storage::disk('local')->deleteDirectory($directory);
    }

    /**
     * about.html -> /about   ·   index.html -> /   ·   hello-world.html -> /hello-world
     *
     * ตัดนามสกุลออกเพื่อให้สัญญาณใน path อ่านได้ตามปกติ
     * ถ้าเหลือ .html ติดไว้ ตัวเดาประเภทหน้าจะเห็น path เป็น "hello-world.html"
     * ซึ่งไม่ตรงกับรูปแบบ URL จริงที่มันถูกออกแบบมาให้อ่าน
     */
    private function fileNameToUrl(string $fileName): string
    {
        $name = preg_replace('/\.html?$/i', '', $fileName) ?? $fileName;
        // ตัดเลขลำดับที่ controller เติมไว้กันชื่อซ้ำ (001_about -> about)
        $name = preg_replace('/^\d{3}_/', '', $name) ?? $name;

        return $name === '' || strtolower($name) === 'index' ? '/' : '/' . $name;
    }

    private function store(Report $report, PageReport $page, int $position): void
    {
        PageResult::fromPageReport($report, $page, $position)->save();
        $report->increment('pages_done');
    }

    private function finish(Report $report): void
    {
        $scores = $report->pages()->whereNotNull('score')->pluck('score');

        $report->update([
            'status' => 'done',
            'score' => $scores->isEmpty() ? null : (int) round($scores->avg()),
            'finished_at' => now(),
        ]);
    }

    private function extract(string $zipPath, string $destination): void
    {
        $zip = new ZipArchive;

        if ($zip->open($zipPath) !== true) {
            throw new \RuntimeException('เปิดไฟล์ zip ไม่ได้');
        }

        @mkdir($destination, 0755, true);

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if ($name === false || str_ends_with($name, '/')) {
                continue;
            }

            // zip slip: ชื่อไฟล์ในอาร์ไคฟ์ที่มี ../ เขียนทับไฟล์นอกโฟลเดอร์ปลายทางได้
            $target = $destination . DIRECTORY_SEPARATOR . $name;
            $realBase = realpath($destination);
            $targetDir = dirname($target);
            @mkdir($targetDir, 0755, true);
            $realDir = realpath($targetDir);

            if ($realBase === false || $realDir === false || ! str_starts_with($realDir, $realBase)) {
                continue;
            }

            // สนใจเฉพาะ .html - ไม่แตกรูป สคริปต์ หรือไฟล์อื่นออกมาบนเซิร์ฟเวอร์เลย
            if (! preg_match('/\.html?$/i', $name)) {
                continue;
            }

            $stream = $zip->getStream($name);
            if ($stream === false) {
                continue;
            }
            file_put_contents($target, stream_get_contents($stream));
            fclose($stream);
        }

        $zip->close();
    }

    /** @return list<string> */
    private function htmlFiles(string $root): array
    {
        if (! is_dir($root)) {
            return [];
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS)
        );

        $files = [];
        foreach ($iterator as $file) {
            if ($file->isFile() && preg_match('/\.html?$/i', $file->getFilename())) {
                $files[] = $file->getPathname();
            }
        }

        sort($files);

        return $files;
    }

    /** dist/blog/post/index.html -> /blog/post/ */
    private function pathToUrl(string $root, string $file): string
    {
        $relative = str_replace('\\', '/', substr($file, strlen($root)));
        $relative = '/' . ltrim($relative, '/');
        $relative = preg_replace('~/index\.html?$~i', '/', $relative) ?? $relative;

        return $relative;
    }

    private function deleteTree(string $path): void
    {
        if (! is_dir($path)) {
            return;
        }

        $items = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($items as $item) {
            $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
        }

        @rmdir($path);
    }
}
