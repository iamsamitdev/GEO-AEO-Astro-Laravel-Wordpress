<?php

namespace App\Audit\Audits\StructuredData;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\JsonLd;

/**
 * schema ที่มีอยู่ กรอกครบพอที่จะใช้งานได้จริงหรือเปล่า
 *
 * @type ที่ว่างเปล่าคือปัญหาที่ตรวจยากที่สุดด้วยตาเปล่า
 * เพราะ validator ทั่วไปบอกว่า "ถูกต้อง" ตราบใดที่ไวยากรณ์ผ่าน
 * แต่ Article ที่ไม่มี author และ dateModified ไม่ให้ข้อมูลอะไรกับ AI เลย
 */
final class RequiredPropertiesAudit extends BaseAudit
{
    /**
     * คุณสมบัติที่ต้องมีจริงเพื่อให้ schema นั้นมีประโยชน์
     *
     * @var array<string, array{required: list<string>, recommended: list<string>}>
     */
    private const RULES = [
        'Article' => [
            'required' => ['headline', 'datePublished', 'author'],
            'recommended' => ['dateModified', 'image', 'publisher', 'description'],
        ],
        'Organization' => [
            'required' => ['name', 'url'],
            'recommended' => ['logo', 'sameAs', 'description'],
        ],
        'WebSite' => [
            'required' => ['name', 'url'],
            'recommended' => ['publisher', 'inLanguage'],
        ],
        'Person' => [
            'required' => ['name'],
            'recommended' => ['sameAs', 'jobTitle', 'url'],
        ],
        'Service' => [
            'required' => ['name', 'description'],
            'recommended' => ['provider', 'areaServed', 'serviceType'],
        ],
        'Product' => [
            'required' => ['name'],
            'recommended' => ['description', 'image', 'brand'],
        ],
        'FAQPage' => [
            'required' => ['mainEntity'],
            'recommended' => [],
        ],
        'BreadcrumbList' => [
            'required' => ['itemListElement'],
            'recommended' => [],
        ],
        'WebPage' => [
            'required' => ['name'],
            'recommended' => ['description', 'inLanguage'],
        ],
    ];

    public function id(): string
    {
        return 'required-properties';
    }

    public function title(): string
    {
        return 'schema กรอกคุณสมบัติที่จำเป็นครบ';
    }

    public function category(): Category
    {
        return Category::StructuredData;
    }

    public function weight(): float
    {
        return 3.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $jsonLd = $ctx->jsonLd();

        if ($jsonLd->isEmpty()) {
            return $this->na('ยังไม่มี JSON-LD ที่อ่านได้');
        }

        $checked = 0;
        $missingRequired = [];
        $missingRecommended = [];
        $details = [];

        foreach ($jsonLd->nodes as $node) {
            foreach (JsonLd::typesOf($node) as $type) {
                $rule = self::RULES[$type] ?? $this->ruleForFamily($type);
                if ($rule === null) {
                    continue;
                }

                $checked++;

                foreach ($rule['required'] as $property) {
                    if (! $this->filled($node, $property)) {
                        $missingRequired[] = "{$type}.{$property}";
                    }
                }

                foreach ($rule['recommended'] as $property) {
                    if (! $this->filled($node, $property)) {
                        $missingRecommended[] = "{$type}.{$property}";
                    }
                }
            }
        }

        if ($checked === 0) {
            return $this->na('ไม่มี schema ชนิดที่เครื่องมือนี้มีกฎให้ตรวจ');
        }

        $missingRequired = array_values(array_unique($missingRequired));
        $missingRecommended = array_values(array_unique($missingRecommended));

        $details[] = "ตรวจ node ที่มีกฎ: {$checked} รายการ";
        if ($missingRequired !== []) {
            $details[] = 'ขาดคุณสมบัติที่จำเป็น: ' . implode(', ', $missingRequired);
        }
        if ($missingRecommended !== []) {
            $details[] = 'ขาดคุณสมบัติที่แนะนำ: ' . implode(', ', $missingRecommended);
        }

        if ($missingRequired === [] && $missingRecommended === []) {
            return $this->pass('ครบทุก node ที่ตรวจได้', $details);
        }

        $score = 1.0
            - min(0.8, count($missingRequired) * 0.25)
            - min(0.2, count($missingRecommended) * 0.05);

        return $this->partial(
            max(0.0, $score),
            $missingRequired !== []
                ? 'ขาดที่จำเป็น ' . count($missingRequired) . ' ช่อง'
                : 'ขาดที่แนะนำ ' . count($missingRecommended) . ' ช่อง',
            'เติมค่าจากข้อมูลจริงในฐานข้อมูล ไม่ใช่ค่าคงที่ - โดยเฉพาะ dateModified ที่ต้องผูกกับเวลาที่แก้เนื้อหาจริง และ author ที่ควรเป็น object Person ไม่ใช่แค่ string',
            $details
        );
    }

    /** @return array{required: list<string>, recommended: list<string>}|null */
    private function ruleForFamily(string $type): ?array
    {
        if (in_array($type, ['BlogPosting', 'NewsArticle', 'TechArticle', 'ScholarlyArticle'], true)) {
            return self::RULES['Article'];
        }

        if (in_array($type, ['Corporation', 'LocalBusiness', 'EducationalOrganization', 'NGO', 'OnlineBusiness'], true)) {
            return self::RULES['Organization'];
        }

        if (in_array($type, ['AboutPage', 'ContactPage', 'CollectionPage', 'ItemPage', 'ProfilePage'], true)) {
            return self::RULES['WebPage'];
        }

        return null;
    }

    private function filled(array $node, string $property): bool
    {
        $value = $node[$property] ?? null;

        if ($value === null) {
            return false;
        }

        if (is_string($value)) {
            return trim($value) !== '';
        }

        if (is_array($value)) {
            // {"@id": "..."} อย่างเดียวถือว่ากรอกแล้ว เพราะเป็นการอ้างถึง entity อื่นที่ถูกต้อง
            return $value !== [];
        }

        return true;
    }
}
