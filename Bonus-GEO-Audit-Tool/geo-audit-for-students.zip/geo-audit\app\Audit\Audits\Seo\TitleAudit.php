<?php

namespace App\Audit\Audits\Seo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\Text;

/**
 * title มีอยู่ ยาวพอดี และไม่ซ้ำกับ h1 แบบคำต่อคำ
 *
 * ความยาวที่แนะนำวัดเป็นตัวอักษร ซึ่งกับภาษาไทยจะกินพื้นที่แสดงผลน้อยกว่าอังกฤษ
 * เลยยืดเพดานให้หน่อยเมื่อหัวข้อเป็นภาษาไทย
 */
final class TitleAudit extends BaseAudit
{
    public function id(): string
    {
        return 'title';
    }

    public function title(): string
    {
        return 'title ยาวพอดีและสื่อความ';
    }

    public function category(): Category
    {
        return Category::Seo;
    }

    public function weight(): float
    {
        return 2.5;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $title = $ctx->document->title();

        if ($title === '') {
            return $this->fail(
                'ไม่มี <title>',
                'ทุกหน้าต้องมี <title> ที่ไม่ซ้ำกัน - นี่คือป้ายชื่อที่ทั้งผลค้นหาและคำตอบของ AI ใช้เรียกหน้านี้',
                []
            );
        }

        $length = Text::length($title);
        $isThai = Text::hasThai($title);
        $min = 25;
        $max = $isThai ? 70 : 60;

        $details = [
            "title: {$title}",
            "ความยาว: {$length} ตัวอักษร (ช่วงที่เหมาะ {$min}-{$max})",
        ];

        $score = 1.0;
        $issues = [];

        if ($length < 15) {
            $score -= 0.5;
            $issues[] = 'สั้นเกินไป';
        } elseif ($length < $min) {
            $score -= 0.2;
            $issues[] = 'ค่อนข้างสั้น';
        } elseif ($length > $max + 20) {
            $score -= 0.35;
            $issues[] = 'ยาวเกินจนถูกตัดในผลค้นหา';
        } elseif ($length > $max) {
            $score -= 0.15;
            $issues[] = 'ยาวกว่าช่วงที่แสดงได้ครบ';
        }

        $h1 = $ctx->document->h1Texts()[0] ?? '';
        if ($h1 !== '' && mb_strtolower($h1, 'UTF-8') === mb_strtolower($title, 'UTF-8')) {
            $score -= 0.1;
            $issues[] = 'เหมือน h1 ทุกตัวอักษร';
            $details[] = 'ข้อเสนอแนะ: ให้ title มีชื่อแบรนด์หรือมุมที่ต่างจาก h1 เล็กน้อย';
        }

        if (preg_match('/(untitled|new page|home\s*[-|]\s*home|document)/i', $title)) {
            $score -= 0.4;
            $issues[] = 'เป็นค่าเริ่มต้นของเทมเพลต';
        }

        if ($issues === []) {
            return $this->pass("{$length} ตัวอักษร", $details);
        }

        return $this->partial(
            max(0.0, $score),
            implode(' · ', $issues),
            "เขียน title ให้อยู่ในช่วง {$min}-{$max} ตัวอักษร ใส่คำหลักไว้ต้นประโยค และปิดท้ายด้วยชื่อแบรนด์",
            $details
        );
    }
}
