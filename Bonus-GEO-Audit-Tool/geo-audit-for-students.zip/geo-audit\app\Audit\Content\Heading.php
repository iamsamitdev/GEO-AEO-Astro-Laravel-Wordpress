<?php

namespace App\Audit\Content;

final class Heading
{
    public function __construct(
        public readonly int $level,
        public readonly string $text,
        public readonly int $order,
    ) {}
}
