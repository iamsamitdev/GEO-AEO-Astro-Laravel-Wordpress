<?php

namespace Tests\Feature;

use App\Audit\Content\PageType;
use App\Jobs\RunReportJob;
use App\Models\Report;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

/**
 * อัปโหลดไฟล์ .html ทีละไฟล์
 *
 * จุดที่ต้องคุมคือชื่อไฟล์ที่มาจากผู้ใช้ (ห้ามเชื่อ) และการที่ผู้ใช้ระบุประเภทหน้าเองได้
 * อย่างหลังไม่ใช่ของประดับ - มันเปลี่ยนว่าข้อไหนถูกตรวจจริงหรือถูกข้ามไปเป็น "ไม่เกี่ยวข้อง"
 */
class UploadHtmlFilesTest extends TestCase
{
    use RefreshDatabase;

    public function test_อัปโหลดหลายไฟล์แล้วสร้างรายงานโหมด_files(): void
    {
        Queue::fake();

        $response = $this->post(route('reports.files'), [
            'documents' => [
                UploadedFile::fake()->createWithContent('index.html', $this->html('หน้าแรก')),
                UploadedFile::fake()->createWithContent('about.html', $this->html('เกี่ยวกับเรา')),
            ],
            'base_url' => 'https://example.com',
            'page_type' => 'auto',
        ]);

        $report = Report::latest()->first();

        $response->assertRedirect(route('reports.show', $report));
        $this->assertSame('files', $report->mode);
        $this->assertSame('https://example.com', $report->label);
        $this->assertNull($report->forced_page_type, '"auto" ต้องเก็บเป็น null ไม่ใช่สตริง auto');
        $this->assertStringContainsString('และอีก 1 ไฟล์', $report->target);

        Queue::assertPushed(RunReportJob::class);
        $this->assertCount(2, Storage::disk('local')->files('uploads/' . $report->ulid));
    }

    public function test_ปฏิเสธไฟล์ที่ไม่ใช่_html(): void
    {
        $this->post(route('reports.files'), [
            'documents' => [UploadedFile::fake()->create('payload.php', 4)],
        ])->assertSessionHasErrors('documents.0');

        $this->assertSame(0, Report::count());
    }

    public function test_ชื่อไฟล์อันตรายถูกทำให้ปลอดภัยก่อนเก็บ(): void
    {
        Queue::fake();

        $this->post(route('reports.files'), [
            'documents' => [
                UploadedFile::fake()->createWithContent('../../evil.html', $this->html('x')),
            ],
        ]);

        $report = Report::latest()->first();
        $stored = Storage::disk('local')->files('uploads/' . $report->ulid);

        $this->assertCount(1, $stored);
        $this->assertStringNotContainsString('..', $stored[0]);
        $this->assertStringEndsWith('.html', $stored[0]);
    }

    public function test_ประเภทหน้าที่ผู้ใช้ระบุถูกใช้แทนการเดา(): void
    {
        // หน้าบทความที่ไม่ประกาศตัวเอง: ไม่มี og:type ไม่มี <article> ไม่มี <time>
        // ถ้าปล่อยให้เดา จะได้ "หน้าทั่วไป" แล้วข้อเรื่องวันที่กับผู้เขียนจะกลายเป็น N/A
        $report = $this->runWithPageType('article');
        $page = $report->pages->first();

        $this->assertSame(PageType::Article->value, $page->page_type);
        $this->assertTrue($page->pageTypeDeclared());

        $verdicts = $this->verdictsOf($page, ['iso-dates', 'authorship', 'freshness']);
        foreach ($verdicts as $id => $verdict) {
            $this->assertSame('fail', $verdict, "ข้อ {$id} ต้องถูกตรวจจริง ไม่ใช่ข้ามเป็น N/A");
        }
    }

    public function test_ถ้าไม่ระบุประเภทหน้าข้อของบทความจะถูกข้ามไป(): void
    {
        $report = $this->runWithPageType(null);
        $page = $report->pages->first();

        $this->assertFalse($page->pageTypeDeclared());

        // นี่คือข้อจำกัดที่ยอมรับไว้ ไม่ใช่บั๊ก - บันทึกไว้ให้ชัดว่าเป็นพฤติกรรมที่ตั้งใจ
        $verdicts = $this->verdictsOf($page, ['iso-dates', 'authorship', 'freshness']);
        $this->assertSame(['iso-dates' => 'na', 'authorship' => 'na', 'freshness' => 'na'], $verdicts);
    }

    public function test_index_html_กลายเป็น_path_รากของเว็บ(): void
    {
        Queue::fake();

        $this->post(route('reports.files'), [
            'documents' => [
                UploadedFile::fake()->createWithContent('index.html', $this->html('หน้าแรก')),
                UploadedFile::fake()->createWithContent('hello-world.html', $this->html('บทความ')),
            ],
            'base_url' => 'https://example.com',
        ]);

        $report = Report::latest()->first();
        (new RunReportJob($report->id))->handle();

        $urls = $report->fresh()->pages->pluck('url')->all();

        $this->assertContains('https://example.com/', $urls);
        $this->assertContains('https://example.com/hello-world', $urls, 'ต้องตัดนามสกุลและเลขลำดับออกจาก path');
    }

    private function runWithPageType(?string $pageType): Report
    {
        Queue::fake();

        $this->post(route('reports.files'), array_filter([
            'documents' => [UploadedFile::fake()->createWithContent('how-to-geo.html', $this->article())],
            'base_url' => 'https://example.com',
            'page_type' => $pageType,
        ]));

        $report = Report::latest()->first();
        (new RunReportJob($report->id))->handle();

        return $report->fresh();
    }

    /** @return array<string, string> */
    private function verdictsOf($page, array $ids): array
    {
        $out = [];
        foreach ($page->audits() as $audit) {
            if (in_array($audit['id'], $ids, true)) {
                $out[$audit['id']] = $audit['verdict'];
            }
        }

        return $out;
    }

    private function html(string $heading): string
    {
        return '<html lang="th"><head><title>' . $heading . ' ของเว็บทดสอบระบบตรวจความพร้อม</title>'
            . '<meta name="description" content="' . str_repeat('คำอธิบายสำหรับการทดสอบระบบ ', 6) . '"></head>'
            . '<body><main><h1>' . $heading . '</h1><p>' . str_repeat('เนื้อหาทดสอบ ', 20) . '</p></main></body></html>';
    }

    private function article(): string
    {
        return '<html lang="th"><head><title>วิธีทำ GEO ให้ได้ผลจริงฉบับเริ่มต้น</title>'
            . '<meta name="description" content="' . str_repeat('คู่มือเริ่มต้นทำ GEO สำหรับทีมการตลาด ', 4) . '"></head>'
            . '<body><div class="content"><h1>วิธีทำ GEO</h1>'
            . '<h2>GEO คืออะไร</h2><p>' . str_repeat('GEO คือการทำให้เนื้อหาถูกหยิบไปตอบคำถาม ', 12) . '</p>'
            . '<a href="/about">เกี่ยวกับเรา</a><a href="/contact">ติดต่อ</a><a href="/">หน้าแรก</a>'
            . '</div></body></html>';
    }
}
