<?php

namespace App\Audit;

/**
 * ผลของ audit หนึ่งตัวบนหน้าหนึ่งหน้า
 *
 * score เป็น 0..1 แบบต่อเนื่อง (ไม่ใช่ผ่าน/ไม่ผ่าน) เพื่อให้รวมเป็นคะแนนหมวดได้
 * score = null แปลว่า "ไม่เกี่ยวกับหน้านี้" (N/A) จะถูกตัดออกจากการถัวน้ำหนัก ไม่ใช่ให้ 0
 */
final class AuditResult
{
    /**
     * @param  list<string>  $details  บรรทัดหลักฐานที่ทำให้ได้คะแนนนี้ แสดงในรายงาน
     */
    public function __construct(
        public readonly string $id,
        public readonly string $title,
        public readonly Category $category,
        public readonly float $weight,
        public readonly ?float $score,
        public readonly string $displayValue = '',
        public readonly array $details = [],
        public readonly string $fix = '',
        public readonly bool $byAi = false,
    ) {}

    public function isNotApplicable(): bool
    {
        return $this->score === null;
    }

    /** pass = เขียว, average = เหลือง, fail = แดง (เกณฑ์เดียวกับ Lighthouse) */
    public function verdict(): string
    {
        return match (true) {
            $this->score === null => 'na',
            $this->score >= 0.9   => 'pass',
            $this->score >= 0.5   => 'average',
            default               => 'fail',
        };
    }

    /** ระยะห่างจากเต็ม คูณน้ำหนัก - ใช้จัดอันดับ "แก้อันไหนคุ้มที่สุด" */
    public function impact(): float
    {
        return $this->score === null ? 0.0 : (1 - $this->score) * $this->weight;
    }

    public function toArray(): array
    {
        return [
            'id'           => $this->id,
            'title'        => $this->title,
            'category'     => $this->category->value,
            'weight'       => $this->weight,
            'score'        => $this->score,
            'verdict'      => $this->verdict(),
            'displayValue' => $this->displayValue,
            'details'      => $this->details,
            'fix'          => $this->fix,
            'byAi'         => $this->byAi,
        ];
    }
}
