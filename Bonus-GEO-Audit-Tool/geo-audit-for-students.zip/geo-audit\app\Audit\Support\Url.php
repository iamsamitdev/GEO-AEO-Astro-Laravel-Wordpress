<?php

namespace App\Audit\Support;

/**
 * เทียบ URL สองอันว่าเป็นหน้าเดียวกันหรือไม่
 *
 * เว็บไทยเจอปัญหานี้ตลอด: sitemap เก็บ path เป็น percent-encoded
 * (/article/ai-%E0%B8%84...) แต่ canonical ในหน้าเขียนเป็น UTF-8 ดิบ
 * (/article/ai-คืออะไร...) ทั้งสองชี้หน้าเดียวกันเป๊ะ
 *
 * ถ้าเทียบเป็นสตริงตรง ๆ เครื่องมือจะรายงานผิดว่า "canonical ชี้ไปหน้าอื่น"
 * กับทุกหน้าที่มีภาษาไทยใน URL ซึ่งเป็นคำเตือนลวงที่ทำให้คนเลิกเชื่อรายงาน
 */
final class Url
{
    /** รูปแบบมาตรฐานสำหรับใช้เปรียบเทียบ - ไม่ใช่สำหรับแสดงผลหรือยิงซ้ำ */
    public static function normalize(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        $parts = parse_url($url);
        if ($parts === false) {
            return rtrim(mb_strtolower($url, 'UTF-8'), '/');
        }

        $scheme = strtolower($parts['scheme'] ?? 'https');
        $host = strtolower($parts['host'] ?? '');
        $port = isset($parts['port']) ? (int) $parts['port'] : null;

        // พอร์ตมาตรฐานเขียนหรือไม่เขียนก็หน้าเดียวกัน
        if (($scheme === 'https' && $port === 443) || ($scheme === 'http' && $port === 80)) {
            $port = null;
        }

        $path = $parts['path'] ?? '/';
        // ถอด percent-encoding ให้ทั้งสองฝั่งมาอยู่รูปเดียวกัน
        $decoded = rawurldecode($path);
        $path = rtrim(mb_strtolower($decoded, 'UTF-8'), '/');

        return $scheme . '://' . $host . ($port !== null ? ':' . $port : '') . $path;
    }

    /**
     * URL สำหรับให้คนอ่าน - ถอด percent-encoding ให้ภาษาไทยกลับมาเป็นตัวอักษร
     *
     * URL ภาษาไทยที่เข้ารหัสแล้วยาวเกือบ 9 เท่าของตัวจริง (ตัวอักษรไทยหนึ่งตัว = %E0%B8%xx)
     * ทั้งอ่านไม่ออกและดันเลย์เอาต์ล้นการ์ด ใช้เฉพาะตอนแสดงผลเท่านั้น
     * ส่วน href และค่าที่ใช้ยิง HTTP ต้องใช้ URL เดิมเสมอ
     *
     * ถ้าถอดแล้วได้ไบต์ที่ไม่ใช่ UTF-8 หรือมีอักขระควบคุม (เช่น %0A) คืนค่าเดิม
     * เพื่อไม่ให้แสดงตัวอักษรเพี้ยนหรือขึ้นบรรทัดแปลก ๆ บนหน้าเว็บ
     */
    public static function forDisplay(string $url): string
    {
        if (! str_contains($url, '%')) {
            return $url;
        }

        $decoded = rawurldecode($url);

        if (! mb_check_encoding($decoded, 'UTF-8') || preg_match('/[\x00-\x1F\x7F]/', $decoded)) {
            return $url;
        }

        return $decoded;
    }

    /** ชี้ไปหน้าเดียวกันหรือไม่ (ไม่สนใจ query, fragment, การ encode และ / ท้าย) */
    public static function sameDocument(string $a, string $b): bool
    {
        $normalizedA = self::normalize($a);

        return $normalizedA !== '' && $normalizedA === self::normalize($b);
    }

    public static function sameHost(string $a, string $b): bool
    {
        $hostA = strtolower((string) parse_url($a, PHP_URL_HOST));
        $hostB = strtolower((string) parse_url($b, PHP_URL_HOST));

        return $hostA !== '' && $hostA === $hostB;
    }
}
