<?php

namespace App\Audit;

/**
 * หมวดคะแนนของ GEO Audit และน้ำหนักที่ใช้รวมเป็นคะแนนรวม 100
 *
 * น้ำหนักเป็น heuristic ที่มาจากแนวปฏิบัติ GEO/AEO ไม่ใช่สูตรที่ผู้ให้บริการ AI ประกาศ
 * ถ้าจะปรับ ให้ปรับที่นี่ที่เดียว แล้วคะแนนทั้งระบบจะขยับตาม
 */
enum Category: string
{
    case Crawlability    = 'crawlability';
    case StructuredData  = 'structured_data';
    case Aeo             = 'aeo';
    case Seo             = 'seo';
    case Eeat            = 'eeat';
    case AiFiles         = 'ai_files';

    public function weight(): float
    {
        return match ($this) {
            self::Crawlability   => 20,
            self::StructuredData => 25,
            self::Aeo            => 20,
            self::Seo            => 20,
            self::Eeat           => 10,
            self::AiFiles        => 5,
        };
    }

    public function label(): string
    {
        return match ($this) {
            self::Crawlability   => 'Crawlability & Delivery',
            self::StructuredData => 'Structured Data',
            self::Aeo            => 'AEO / Answer-Ready',
            self::Seo            => 'On-Page SEO',
            self::Eeat           => 'E-E-A-T & Trust',
            self::AiFiles        => 'AI-Native Files',
        };
    }

    public function description(): string
    {
        return match ($this) {
            self::Crawlability   => 'AI crawler เข้าถึงหน้านี้ได้จริงไหม และเห็นเนื้อหาโดยไม่ต้องรัน JavaScript หรือเปล่า',
            self::StructuredData => 'JSON-LD ที่บอกเครื่องจักรว่าหน้านี้คืออะไร ใครเขียน เมื่อไร เชื่อมกับอะไร',
            self::Aeo            => 'เนื้อหาถูกตัดเป็นชิ้นและตอบคำถามตรง ๆ จนหยิบไปอ้างอิงได้ทันทีหรือไม่',
            self::Seo            => 'พื้นฐาน on-page ที่ search engine เดิมและ AI ใช้ร่วมกัน',
            self::Eeat           => 'สัญญาณว่าใครเป็นคนพูด และเชื่อถือได้เพราะอะไร',
            self::AiFiles        => 'ไฟล์ที่เขียนขึ้นเพื่อ AI โดยเฉพาะ เช่น llms.txt',
        };
    }

    /** @return list<self> */
    public static function ordered(): array
    {
        return [self::Crawlability, self::StructuredData, self::Aeo, self::Seo, self::Eeat, self::AiFiles];
    }
}
