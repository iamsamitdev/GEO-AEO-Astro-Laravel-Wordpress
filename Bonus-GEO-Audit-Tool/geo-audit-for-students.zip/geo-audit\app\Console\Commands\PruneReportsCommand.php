<?php

namespace App\Console\Commands;

use App\Models\Report;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

/**
 * ลบรายงานเก่าและไฟล์ที่อัปโหลดค้างไว้
 *
 * เครื่องมือเปิดสาธารณะ ถ้าไม่ลบ ตารางจะโตไปเรื่อย ๆ
 * และที่สำคัญกว่าคือ URL ที่คนอื่นสั่งตรวจจะค้างอยู่บนเซิร์ฟเวอร์ตลอดกาลโดยไม่จำเป็น
 */
class PruneReportsCommand extends Command
{
    protected $signature = 'geo:prune {--days= : เก็บย้อนหลังกี่วัน (ค่าเริ่มต้นจาก config)}';

    protected $description = 'ลบรายงานที่เก่ากว่าระยะเวลาที่กำหนด พร้อมไฟล์อัปโหลดที่ค้าง';

    public function handle(): int
    {
        $days = (int) ($this->option('days') ?: config('geoaudit.retention_days'));

        if ($days <= 0) {
            $this->info('ปิดการลบอัตโนมัติไว้ (retention_days <= 0)');

            return self::SUCCESS;
        }

        $cutoff = now()->subDays($days);

        $stale = Report::where('created_at', '<', $cutoff)->get(['id', 'ulid']);

        foreach ($stale as $report) {
            Storage::disk('local')->delete('uploads/' . $report->ulid . '.zip');
            Storage::disk('local')->deleteDirectory('uploads/' . $report->ulid);
        }

        // page_results ถูกลบตามด้วย cascade ที่กำหนดไว้ใน migration
        $deleted = Report::whereIn('id', $stale->pluck('id'))->delete();

        // งานที่ค้างสถานะ running เกินหนึ่งชั่วโมง แปลว่า worker ตายกลางทาง
        $stuck = Report::where('status', 'running')
            ->where('started_at', '<', now()->subHour())
            ->update(['status' => 'failed', 'error' => 'งานค้างเกินเวลาที่กำหนด', 'finished_at' => now()]);

        $this->info("ลบรายงานเก่า {$deleted} ฉบับ · ปิดงานที่ค้าง {$stuck} รายการ");

        return self::SUCCESS;
    }
}
