<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('reports', function (Blueprint $table) {
            /*
             * ประเภทหน้าที่ผู้ใช้ระบุเอง แทนการให้ระบบเดา
             *
             * จำเป็นเฉพาะตอนอัปโหลดไฟล์ .html เดี่ยว ๆ เพราะเรามีแค่ชื่อไฟล์
             * ไม่มี path จริงให้ดู หน้าบทความที่ไม่ประกาศ og:type จึงถูกเดาเป็น
             * "หน้าทั่วไป" แล้วข้อเรื่องผู้เขียน วันที่ และความสด จะกลายเป็น
             * "ไม่เกี่ยวข้อง" หายไปจากรายงาน ทั้งที่เป็นปัญหาจริงที่ต้องแก้
             *
             * null = ให้ระบบเดาเอง
             */
            $table->string('forced_page_type', 32)->nullable()->after('label');
        });
    }

    public function down(): void
    {
        Schema::table('reports', function (Blueprint $table) {
            $table->dropColumn('forced_page_type');
        });
    }
};
