<?php

namespace App\Models;

use App\Audit\Category;
use App\Audit\PageReport;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PageResult extends Model
{
    protected $fillable = [
        'report_id', 'position', 'url', 'page_type', 'score',
        'http_status', 'load_ms', 'bytes', 'error', 'payload',
    ];

    protected function casts(): array
    {
        return ['payload' => 'array'];
    }

    public function report(): BelongsTo
    {
        return $this->belongsTo(Report::class);
    }

    public static function fromPageReport(Report $report, PageReport $page, int $position): self
    {
        $payload = $page->toArray();

        return new self([
            'report_id' => $report->id,
            'position' => $position,
            'url' => $page->url,
            'page_type' => $page->pageType->value,
            'score' => $page->failed() ? null : $page->score(),
            'http_status' => $page->httpStatus ?: null,
            'load_ms' => (int) round($page->loadMs),
            'bytes' => $page->bytes,
            'error' => $page->error,
            'payload' => $payload,
        ]);
    }

    public function failed(): bool
    {
        return $this->error !== null;
    }

    /** @return list<array<string, mixed>> */
    public function audits(): array
    {
        return $this->payload['audits'] ?? [];
    }

    /** @return list<array<string, mixed>> */
    public function auditsIn(Category $category): array
    {
        return array_values(array_filter(
            $this->audits(),
            fn (array $audit) => ($audit['category'] ?? null) === $category->value
        ));
    }

    /** @return array<string, int|null> */
    public function categoryScores(): array
    {
        $out = [];
        foreach ($this->payload['categories'] ?? [] as $key => $data) {
            $out[$key] = $data['score'] ?? null;
        }

        return $out;
    }

    public function pageTypeLabel(): string
    {
        return $this->payload['pageTypeLabel'] ?? '';
    }

    /** ประเภทหน้ามาจากที่ผู้ใช้ระบุ ไม่ใช่จากการเดาของระบบ */
    public function pageTypeDeclared(): bool
    {
        return (bool) ($this->payload['pageTypeDeclared'] ?? false);
    }

    public function grade(): string
    {
        return PageReport::grade((int) $this->score);
    }

    /**
     * ข้อที่ควรแก้ก่อน เรียงตามคะแนนที่จะได้คืน
     *
     * @return list<array<string, mixed>>
     */
    public function opportunities(int $limit = 8): array
    {
        $weights = [];
        foreach (Category::ordered() as $category) {
            $weights[$category->value] = $category->weight();
        }

        $failing = array_filter(
            $this->audits(),
            fn (array $audit) => ($audit['score'] ?? null) !== null && $audit['score'] < 0.9
        );

        usort($failing, function (array $a, array $b) use ($weights) {
            $impactA = (1 - $a['score']) * $a['weight'] * ($weights[$a['category']] ?? 1);
            $impactB = (1 - $b['score']) * $b['weight'] * ($weights[$b['category']] ?? 1);

            return $impactB <=> $impactA;
        });

        return array_slice(array_values($failing), 0, $limit);
    }

    public function countVerdict(string $verdict): int
    {
        return count(array_filter($this->audits(), fn (array $a) => ($a['verdict'] ?? '') === $verdict));
    }
}
