/*
 * ฉลองคะแนนเต็ม 100 ด้วยพลุเต็มจอ
 *
 * เขียนด้วย canvas ล้วน ไม่มีไลบรารีภายนอก เพราะเซิร์ฟเวอร์ไม่มีขั้นตอน build
 * และไฟล์นี้โหลดเฉพาะหน้ารายงานที่ได้ 100 เท่านั้น หน้าอื่นไม่เสียอะไรเลย
 *
 * ลำดับการแสดง (มิลลิวินาทีนับจากเริ่ม)
 *   0          ยิงพร้อมกันสามลูกเปิดฉาก ระเบิดลูกแรกราววินาทีที่ 1
 *   0 - 2600   ยิงต่อเนื่องหลายแบบ: ดอกโบตั๋น วงแหวน หลิวทอง ประกาย แตกกิ่ง
 *   2600       ลูกใหญ่กลางจอ ระเบิดราว 3.5 วิ แล้วเรียงตัวเป็นเลข "100" เสร็จราว 4.2 วิ
 *   4300       ข้อความ "คะแนนเต็ม" ขึ้นด้านล่าง (หลังเลข 100 เรียงเสร็จ ไม่ใช่ก่อน)
 *   3300-6100  ระหว่างเลข 100 ค้างกลางจอ ยิงเฉพาะริมสองข้าง ไม่ให้บังตัวเลข (มือถืองดยิง)
 *   6100-8600  ไคลแม็กซ์ ยิงถี่เต็มจอ
 *   หลังจากนั้น รอประกายตกหมดแล้วปิดเอง
 *
 * ผู้ใช้ที่ตั้งค่าระบบให้ลดการเคลื่อนไหว (prefers-reduced-motion) จะเห็นแค่ข้อความ ไม่มีพลุ
 * ปิดได้ทุกเมื่อด้วยการแตะที่ใดก็ได้ กด Esc หรือปุ่มปิด
 */
(function () {
  'use strict';

  var trigger = document.querySelector('[data-celebrate]');
  if (!trigger) {
    return;
  }

  var PALETTE = ['#ffd166', '#ef476f', '#4cc9f0', '#06d6a0', '#b388ff', '#ff9f1c', '#ffffff'];
  var GOLD = ['#ffd166', '#ffe9a8', '#ffb703', '#fff6d6'];
  // ทองเข้มสำหรับเลข 100 - โทนอ่อนในชุด GOLD บนพื้นมืดดูเป็นสีขาวจนไม่เหลือความเป็นทอง
  var DEEP_GOLD = ['#ffd166', '#ffb703', '#ffc84a', '#ffa62b'];
  // แรงโน้มถ่วงของจรวด ยิ่งมากยิ่งขึ้นเร็ว - 0.32 ทำให้ระเบิดลูกแรกได้ในราวหนึ่งวินาที
  var ROCKET_GRAVITY = 0.32;
  // สัดส่วนภาพที่เหลือจากเฟรมก่อน ยิ่งมากหางประกายยิ่งยาว
  var TRAIL_KEEP = 0.84;
  var FADE_OUT_MS = 650;

  var reduceMotion = window.matchMedia
    && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var show = null;

  function rand(min, max) {
    return min + Math.random() * (max - min);
  }

  function pick(list) {
    return list[Math.floor(Math.random() * list.length)];
  }

  function easeOutCubic(t) {
    return 1 - Math.pow(1 - t, 3);
  }

  // ---------- โครงหน้าจอ ----------

  function buildOverlay() {
    var overlay = document.createElement('div');
    overlay.className = 'celebrate';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', 'ฉลองคะแนนเต็ม 100');

    var canvas = document.createElement('canvas');
    canvas.className = 'celebrate-canvas';
    canvas.setAttribute('aria-hidden', 'true');

    // จรวดวาดบนอีกชั้นที่ล้างทุกเฟรม ชั้นประกายเก็บภาพเฟรมก่อนไว้ทำหาง
    // ถ้าวาดจรวดบนชั้นเดียวกัน หัวจรวดทุกเฟรมจะค้างเรียงกันเป็นจุดไข่ปลา
    var rocketCanvas = document.createElement('canvas');
    rocketCanvas.className = 'celebrate-canvas';
    rocketCanvas.setAttribute('aria-hidden', 'true');

    var banner = document.createElement('div');
    banner.className = 'celebrate-banner';
    banner.innerHTML =
      '<p class="celebrate-title">คะแนนเต็ม 100</p>' +
      '<p class="celebrate-sub">ผ่านครบทุกข้อที่เกี่ยวข้องกับหน้านี้</p>' +
      '<button type="button" class="celebrate-close">ปิด</button>' +
      '<p class="celebrate-hint">แตะที่ใดก็ได้หรือกด Esc เพื่อปิด</p>';

    overlay.appendChild(canvas);
    overlay.appendChild(rocketCanvas);
    overlay.appendChild(banner);

    return { overlay: overlay, canvas: canvas, rocketCanvas: rocketCanvas, banner: banner };
  }

  function onKey(event) {
    if (event.key === 'Escape') {
      stop();
    }
  }

  function play() {
    if (show) {
      return;
    }

    var ui = buildOverlay();
    document.body.appendChild(ui.overlay);

    show = {
      ui: ui,
      previousFocus: document.activeElement,
      raf: 0,
      timer: 0,
      closing: false,
      onResize: null
    };

    ui.overlay.addEventListener('click', stop);
    ui.banner.querySelector('.celebrate-close').addEventListener('click', function (event) {
      event.stopPropagation();
      stop();
    });
    document.addEventListener('keydown', onKey);

    // อ่านค่า layout หนึ่งครั้งก่อนเติมคลาส ไม่งั้นเบราว์เซอร์รวบเป็นเฟรมเดียวแล้ว transition ไม่เล่น
    void ui.overlay.offsetWidth;
    ui.overlay.classList.add('is-visible');
    ui.banner.querySelector('.celebrate-close').focus({ preventScroll: true });

    if (reduceMotion) {
      ui.overlay.classList.add('is-static');
      ui.banner.classList.add('is-visible');
      show.timer = window.setTimeout(stop, 6000);
      return;
    }

    runFireworks(ui);
  }

  function stop() {
    if (!show || show.closing) {
      return;
    }

    var current = show;
    current.closing = true;
    current.ui.overlay.classList.remove('is-visible');
    document.removeEventListener('keydown', onKey);
    window.clearTimeout(current.timer);

    // ปล่อยให้พลุเล่นต่อระหว่างที่ฉากค่อย ๆ จางหาย แล้วค่อยเก็บกวาด
    window.setTimeout(function () {
      window.cancelAnimationFrame(current.raf);
      if (current.onResize) {
        window.removeEventListener('resize', current.onResize);
      }
      current.ui.overlay.remove();
      if (current.previousFocus && typeof current.previousFocus.focus === 'function') {
        current.previousFocus.focus({ preventScroll: true });
      }
      show = null;
    }, FADE_OUT_MS);
  }

  // ---------- เครื่องยนต์พลุ ----------

  function runFireworks(ui) {
    // ผูกลูปเฟรมไว้กับโชว์รอบนี้โดยเฉพาะ ไม่อ้างตัวแปร show ของโมดูลตรง ๆ
    // ถ้าลูปของรอบก่อนหลุดรอดมาทำงานระหว่างรอบใหม่ มันต้องหยุดตัวเอง
    // ไม่ใช่ไปอ่านสถานะหรือสั่งปิดโชว์ของรอบใหม่แทน
    var current = show;
    var canvas = ui.canvas;
    var ctx = canvas.getContext('2d');
    var rocketCtx = ui.rocketCanvas.getContext('2d');
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var W = 0;
    var H = 0;
    var small = false;

    function resize() {
      W = window.innerWidth;
      H = window.innerHeight;
      small = W < 640;

      [canvas, ui.rocketCanvas].forEach(function (layer) {
        layer.width = Math.round(W * dpr);
        layer.height = Math.round(H * dpr);
      });

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.lineCap = 'round';
      rocketCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
      rocketCtx.lineCap = 'round';
    }

    resize();
    current.onResize = resize;
    window.addEventListener('resize', resize);

    // จำกัดจำนวนประกาย เครื่องช้าและมือถือจะได้ไม่กระตุก
    var maxParticles = small ? 1100 : 2600;
    var rockets = [];
    var particles = [];
    var textPoints = sampleText('100');

    var start = performance.now();
    var last = start;
    var nextLaunch = 0;
    var opened = false;
    var shapeLaunched = false;
    var bannerShown = false;

    function add(particle) {
      if (particles.length < maxParticles) {
        particles.push(particle);
      }
    }

    function spark(x, y, vx, vy, color, extra) {
      var p = {
        x: x, y: y, px: x, py: y,
        vx: vx, vy: vy,
        alpha: 1,
        decay: rand(0.011, 0.019),
        color: color,
        size: small ? 1.8 : 2.3,
        gravity: 0.045,
        drag: 0.965,
        twinkle: false,
        split: 0,
        mode: 'free'
      };

      if (extra) {
        for (var key in extra) {
          if (Object.prototype.hasOwnProperty.call(extra, key)) {
            p[key] = extra[key];
          }
        }
      }

      add(p);
    }

    /*
     * เปลี่ยนข้อความเป็นชุดจุด โดยวาดลง canvas ที่มองไม่เห็นแล้วอ่านพิกเซลกลับมา
     * แต่ละจุดจะกลายเป็นเป้าหมายของประกายหนึ่งดวงตอนพลุลูกใหญ่ระเบิด
     */
    function sampleText(text) {
      var size = Math.min(W * (small ? 0.42 : 0.3), 300);
      var font = '800 ' + size + 'px Inter, system-ui, sans-serif';
      var off = document.createElement('canvas');
      var o = off.getContext('2d');

      o.font = font;
      var width = Math.ceil(o.measureText(text).width + size * 0.2);

      // กำหนดขนาดใหม่แล้ว context จะถูกล้างค่าทั้งหมด จึงต้องตั้งฟอนต์ซ้ำ
      off.width = width;
      off.height = Math.ceil(size * 1.2);
      o.font = font;
      o.fillStyle = '#fff';
      o.textAlign = 'center';
      o.textBaseline = 'middle';
      o.fillText(text, off.width / 2, off.height / 2);

      var data = o.getImageData(0, 0, off.width, off.height).data;
      var step = Math.max(4, Math.round(size / (small ? 20 : 26)));
      var points = [];

      for (var y = 0; y < off.height; y += step) {
        for (var x = 0; x < off.width; x += step) {
          if (data[(y * off.width + x) * 4 + 3] > 140) {
            // เขย่าตำแหน่งแต่ละจุดเล็กน้อย ถ้าเรียงตามตารางเป๊ะ ตัวเลขจะดูเป็นป้าย LED ไม่ใช่ประกายไฟ
            points.push({
              x: x - off.width / 2 + rand(-0.4, 0.4) * step,
              y: y - off.height / 2 + rand(-0.4, 0.4) * step
            });
          }
        }
      }

      return points;
    }

    function launch(opts) {
      opts = opts || {};

      var targetY = opts.targetY != null ? opts.targetY : rand(H * 0.12, H * 0.42);
      var height = H + 10 - targetY;

      rockets.push({
        x: opts.x != null ? opts.x : rand(W * 0.1, W * 0.9),
        y: H + 10,
        vx: opts.x != null ? 0 : rand(-0.5, 0.5),
        // ความเร็วต้นที่พอดีจะหยุดที่ความสูงเป้าหมายพอดีภายใต้แรงโน้มถ่วงคงที่
        vy: -Math.sqrt(2 * ROCKET_GRAVITY * height),
        color: opts.color || pick(PALETTE),
        type: opts.type || pick(['peony', 'peony', 'ring', 'willow', 'glitter', 'crossette'])
      });
    }

    function flash(x, y, radius) {
      // แสงวาบสั้น ๆ ตอนระเบิด - ถ้าสว่างหรือค้างนานเกิน จะเห็นเป็นลูกบอลขาวทึบลอยอยู่
      add({
        x: x, y: y, px: x, py: y, vx: 0, vy: 0,
        alpha: 0.55, decay: 0.12, color: '#ffffff',
        size: radius, gravity: 0, drag: 1, twinkle: false, split: 0, mode: 'flash'
      });
    }

    function burst(x, y, colors, count, speed, extra) {
      for (var i = 0; i < count; i++) {
        var angle = rand(0, Math.PI * 2);
        var velocity = speed * (0.3 + Math.random() * 0.7);
        spark(x, y, Math.cos(angle) * velocity, Math.sin(angle) * velocity, pick(colors), extra);
      }
    }

    function ring(x, y, colors, count, speed, extra) {
      var offset = rand(0, Math.PI * 2);
      for (var i = 0; i < count; i++) {
        var angle = offset + (i / count) * Math.PI * 2;
        spark(x, y, Math.cos(angle) * speed, Math.sin(angle) * speed, pick(colors), extra);
      }
    }

    function explode(rocket) {
      var x = rocket.x;
      var y = rocket.y;
      var scale = small ? 0.7 : 1;
      var second = pick(PALETTE);

      switch (rocket.type) {
        case 'ring':
          ring(x, y, [rocket.color], Math.round(72 * scale), 5.2 * (small ? 0.85 : 1));
          ring(x, y, [second], Math.round(40 * scale), 2.6);
          break;

        case 'willow':
          burst(x, y, GOLD, Math.round(100 * scale), 3.4, {
            decay: rand(0.006, 0.009), drag: 0.978, gravity: 0.032, size: small ? 1.4 : 1.7
          });
          break;

        case 'glitter':
          burst(x, y, [rocket.color, '#ffffff'], Math.round(120 * scale), 4.6, {
            twinkle: true, decay: rand(0.009, 0.014)
          });
          break;

        case 'crossette':
          // ดาวดวงใหญ่ไม่กี่ดวง พอวิ่งไปได้ครึ่งทางจะแตกเป็นสี่แฉก
          ring(x, y, [rocket.color], 14, 4.4, { split: 26, size: small ? 2.2 : 2.8, decay: 0.012 });
          break;

        case 'shape':
          shape(x, y);
          break;

        default:
          burst(x, y, [rocket.color, second], Math.round(150 * scale), 6.2 * (small ? 0.85 : 1));
      }

      flash(x, y, rocket.type === 'shape' ? 70 : 34);
    }

    function shape(x, y) {
      // ม่านทองด้านหลังให้เลข 100 ดูมีน้ำหนัก
      burst(x, y, GOLD, small ? 90 : 160, 7.5, { decay: rand(0.01, 0.014) });
      ring(x, y, ['#ffffff'], small ? 48 : 80, 8.5, { decay: 0.02 });

      var baseSize = small ? 2.4 : 3.1;

      for (var i = 0; i < textPoints.length; i++) {
        var point = textPoints[i];
        add({
          x: x, y: y, px: x, py: y,
          sx: x, sy: y,
          tx: x + point.x, ty: y + point.y,
          vx: 0, vy: 0,
          alpha: 1, decay: 0.012,
          color: Math.random() < 0.85 ? pick(DEEP_GOLD) : '#ffffff',
          size: baseSize * rand(0.7, 1.3),
          gravity: 0.03, drag: 0.985,
          twinkle: false, split: 0,
          glow: true,
          mode: 'seek', t: 0, hold: 110
        });
      }
    }

    function updateParticle(p, dt) {
      p.px = p.x;
      p.py = p.y;

      if (p.mode === 'seek') {
        // เคลื่อนจากจุดระเบิดไปหาตำแหน่งของตัวเลข แล้วค้างไว้ให้อ่านทัน
        p.t = Math.min(1, p.t + dt / 42);
        var e = easeOutCubic(p.t);
        p.x = p.sx + (p.tx - p.sx) * e;
        p.y = p.sy + (p.ty - p.sy) * e;

        if (p.t >= 1) {
          p.hold -= dt;
          if (p.hold <= 0) {
            p.mode = 'free';
            p.vx = rand(-0.7, 0.7);
            p.vy = rand(-1, 0.3);
            p.twinkle = true;
          }
        }

        return true;
      }

      if (p.mode === 'flash') {
        p.alpha -= p.decay * dt;
        return p.alpha > 0;
      }

      var drag = Math.pow(p.drag, dt);
      p.vx *= drag;
      p.vy = p.vy * drag + p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.alpha -= p.decay * dt;

      if (p.split > 0) {
        p.split -= dt;
        if (p.split <= 0) {
          var base = Math.atan2(p.vy, p.vx);
          for (var k = 0; k < 4; k++) {
            var angle = base + Math.PI / 4 + (k * Math.PI) / 2;
            spark(p.x, p.y, Math.cos(angle) * 2.6, Math.sin(angle) * 2.6, pick([p.color, '#ffffff']), {
              decay: rand(0.02, 0.03), size: small ? 1.3 : 1.6
            });
          }
          return false;
        }
      }

      return p.alpha > 0 && p.y < H + 40;
    }

    function drawParticle(p) {
      if (p.mode === 'flash') {
        var glow = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size);
        glow.addColorStop(0, 'rgba(255,244,220,' + p.alpha + ')');
        glow.addColorStop(0.35, 'rgba(255,230,190,' + (p.alpha * 0.35) + ')');
        glow.addColorStop(1, 'rgba(255,220,170,0)');
        ctx.globalAlpha = 1;
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        return;
      }

      var alpha = Math.max(0, Math.min(1, p.alpha));
      if (p.twinkle && Math.random() < 0.45) {
        alpha *= 0.25;
      } else if (p.mode === 'seek' && Math.random() < 0.12) {
        // ระหว่างเลข 100 ค้างอยู่ ให้กะพริบเบา ๆ เป็นประกาย ไม่ใช่จุดนิ่งสนิท
        alpha *= 0.35;
      }

      ctx.strokeStyle = p.color;

      if (p.glow) {
        // วาดซ้ำเป็นวงกว้างจาง ๆ อีกชั้น ให้จุดมีรัศมีเรืองแสงรอบตัว
        ctx.globalAlpha = alpha * 0.22;
        ctx.lineWidth = p.size * 3.2;
        ctx.beginPath();
        ctx.moveTo(p.px, p.py);
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
      }

      ctx.globalAlpha = alpha;
      ctx.lineWidth = p.size;
      ctx.beginPath();
      ctx.moveTo(p.px, p.py);
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
    }

    function schedule(elapsed) {
      if (current.closing) {
        return;
      }

      if (!opened) {
        // เปิดฉากด้วยสามลูกพร้อมกัน ไม่ปล่อยให้ช่วงแรกมีแต่จรวดเส้นบาง ๆ วิ่งขึ้นเงียบ ๆ
        opened = true;
        launch({ x: W * 0.22, targetY: H * 0.3 });
        launch({ x: W * 0.5, targetY: H * 0.2 });
        launch({ x: W * 0.78, targetY: H * 0.3 });
        nextLaunch = elapsed + 380;
      }

      if (elapsed < 2600 && elapsed >= nextLaunch) {
        launch();
        nextLaunch = elapsed + rand(small ? 320 : 200, small ? 480 : 320);
      }

      if (!shapeLaunched && elapsed >= 2600) {
        shapeLaunched = true;
        launch({ x: W / 2, targetY: H * 0.34, type: 'shape', color: '#ffd166' });
        nextLaunch = elapsed + 700;
      }

      // ระหว่างเลข 100 ค้างอยู่กลางจอ ยิงเฉพาะริมสองข้าง ให้ตัวเลขอ่านได้ชัด
      // จอมือถือไม่ยิงเลย เพราะตัวเลขกินเกือบเต็มความกว้าง ไม่มีริมให้ยิงโดยไม่ทับตัวเลข
      if (!small && elapsed >= 3300 && elapsed < 6100 && elapsed >= nextLaunch) {
        var left = Math.random() < 0.5;
        launch({ x: left ? rand(W * 0.03, W * 0.16) : rand(W * 0.84, W * 0.97) });
        nextLaunch = elapsed + rand(small ? 380 : 260, small ? 560 : 380);
      }

      if (!bannerShown && elapsed >= 4300) {
        bannerShown = true;
        ui.banner.classList.add('is-visible');
      }

      if (elapsed >= 6100 && elapsed < 8600 && elapsed >= nextLaunch) {
        // ไคลแม็กซ์: เลข 100 สลายไปแล้ว ยิงถี่เต็มจอ
        launch({ x: rand(W * 0.06, W * 0.4) });
        launch({ x: rand(W * 0.6, W * 0.94) });
        if (Math.random() < (small ? 0.3 : 0.55)) {
          launch({ x: rand(W * 0.35, W * 0.65), type: pick(['willow', 'peony', 'ring']) });
        }
        nextLaunch = elapsed + rand(small ? 220 : 120, small ? 360 : 200);
      }
    }

    function frame(now) {
      if (current !== show) {
        return;
      }

      // dt เป็นหน่วย "เฟรมที่ 60fps" จอ 120Hz กับจอ 60Hz จึงได้ความเร็วเท่ากัน
      // จำกัดไว้ที่ 3 กันการกระโดดเมื่อแท็บถูกพักไว้แล้วกลับมา
      var dt = Math.min((now - last) / 16.667, 3);
      var elapsed = now - start;
      last = now;

      schedule(elapsed);

      // ลบภาพเฟรมก่อนออกทีละนิดแทนการล้างทั้งจอ ประกายจึงทิ้งหางเป็นเส้น
      // ใช้ destination-out เพื่อให้จางกลับเป็นโปร่งใส ไม่ใช่ถมสีดำทับฉากหลัง
      ctx.globalCompositeOperation = 'destination-out';
      ctx.globalAlpha = 1;
      ctx.fillStyle = 'rgba(0,0,0,' + (1 - Math.pow(TRAIL_KEEP, dt)) + ')';
      ctx.fillRect(0, 0, W, H);
      ctx.globalCompositeOperation = 'lighter';

      rocketCtx.clearRect(0, 0, W, H);
      rocketCtx.globalCompositeOperation = 'lighter';

      var flying = 0;
      for (var i = 0; i < rockets.length; i++) {
        var r = rockets[i];

        r.vy += ROCKET_GRAVITY * dt;
        r.x += r.vx * dt;
        r.y += r.vy * dt;

        // หางไล่ระดับจากโปร่งใสไปหาหัวที่สว่าง ยาวตามความเร็ว วาดใหม่ทุกเฟรมจึงไม่ทิ้งรอย
        var tail = Math.min(70, Math.abs(r.vy) * 4.5);
        var gradient = rocketCtx.createLinearGradient(r.x, r.y + tail, r.x, r.y);
        gradient.addColorStop(0, 'rgba(255,200,120,0)');
        gradient.addColorStop(1, 'rgba(255,244,214,0.9)');
        rocketCtx.strokeStyle = gradient;
        rocketCtx.lineWidth = small ? 1.8 : 2.2;
        rocketCtx.beginPath();
        rocketCtx.moveTo(r.x - r.vx * 4, r.y + tail);
        rocketCtx.lineTo(r.x, r.y);
        rocketCtx.stroke();

        rocketCtx.fillStyle = '#fffaf0';
        rocketCtx.beginPath();
        rocketCtx.arc(r.x, r.y, small ? 1.8 : 2.2, 0, Math.PI * 2);
        rocketCtx.fill();

        // ประกายที่หลุดออกจากจรวดไปอยู่ชั้นประกาย จะได้มีหางระยิบระยับตามทาง
        if (Math.random() < 0.6) {
          spark(r.x, r.y, rand(-0.4, 0.4), rand(0.6, 1.6), '#ffc76b', {
            decay: rand(0.03, 0.05), size: 1.2, gravity: 0.02
          });
        }

        if (r.vy >= 0) {
          explode(r);
        } else {
          rockets[flying++] = r;
        }
      }
      rockets.length = flying;

      // ลบประกายที่ดับแล้วด้วยการบีบ array ในรอบเดียว - O(n)
      // เดิมใช้ splice ทีละตัว ซึ่งเป็น O(n^2) ตอนประกายดับพร้อมกันหลายร้อยดวง
      // (เช่นตอนเลข 100 สลาย) ทำให้เฟรมกระตุกได้ถึงร้อยกว่ามิลลิวินาที
      // ประกายที่เกิดใหม่ระหว่างรอบ (ดาวแตกกิ่ง) ต่อท้าย array และถูกประมวลผลในรอบเดียวกันนี้เลย
      var alive = 0;
      for (var j = 0; j < particles.length; j++) {
        var p = particles[j];
        if (updateParticle(p, dt)) {
          drawParticle(p);
          particles[alive++] = p;
        }
      }
      particles.length = alive;

      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'source-over';

      var finished = elapsed > 8600 && rockets.length === 0 && particles.length === 0;
      if ((finished || elapsed > 15000) && !current.closing) {
        stop();
      }

      current.raf = window.requestAnimationFrame(frame);
    }

    current.raf = window.requestAnimationFrame(frame);
  }

  // ---------- เริ่มทำงาน ----------

  function startWhenVisible() {
    // เปิดหน้าไว้ในแท็บพื้นหลัง: รอจนผู้ใช้สลับมาดูก่อนค่อยจุด ไม่งั้นพลาดทั้งโชว์
    if (!document.hidden) {
      window.setTimeout(play, 450);
      return;
    }

    var onVisible = function () {
      if (!document.hidden) {
        document.removeEventListener('visibilitychange', onVisible);
        window.setTimeout(play, 450);
      }
    };
    document.addEventListener('visibilitychange', onVisible);
  }

  document.querySelectorAll('[data-celebrate-replay]').forEach(function (button) {
    button.addEventListener('click', play);
  });

  // รอฟอนต์ Inter โหลดเสร็จก่อน เลข 100 ที่สร้างจากพิกเซลจะได้เป็นทรงเดียวกับตัวอักษรบนหน้า
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(startWhenVisible);
  } else {
    startWhenVisible();
  }
})();
