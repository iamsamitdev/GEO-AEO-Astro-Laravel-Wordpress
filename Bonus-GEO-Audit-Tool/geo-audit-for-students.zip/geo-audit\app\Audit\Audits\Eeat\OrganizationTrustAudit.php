<?php

namespace App\Audit\Audits\Eeat;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\JsonLd;

/**
 * มีองค์กรที่ระบุตัวตนได้อยู่เบื้องหลังเว็บนี้หรือเปล่า
 *
 * ที่อยู่จริง เบอร์โทรจริง และโปรไฟล์ภายนอกที่ยืนยันได้
 * เป็นสิ่งที่แยกเว็บที่มีคนรับผิดชอบ ออกจากเว็บที่ผลิตเนื้อหาจำนวนมากโดยไม่มีที่มา
 */
final class OrganizationTrustAudit extends BaseAudit
{
    public function id(): string
    {
        return 'organization-trust';
    }

    public function title(): string
    {
        return 'ระบุองค์กรเจ้าของเว็บที่ตรวจสอบได้';
    }

    public function category(): Category
    {
        return Category::Eeat;
    }

    public function weight(): float
    {
        return 2.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $jsonLd = $ctx->jsonLd();

        $organization = null;
        foreach (['Organization', 'Corporation', 'LocalBusiness', 'EducationalOrganization', 'OnlineBusiness', 'NGO'] as $type) {
            $organization = $jsonLd->firstOfType($type);
            if ($organization !== null) {
                break;
            }
        }

        $hasAbout = $ctx->document->has('//a[contains(@href,"/about") or contains(@href,"เกี่ยวกับ")]');
        $hasContact = $ctx->document->has('//a[contains(@href,"/contact") or contains(@href,"ติดต่อ") or starts-with(@href,"tel:")]');

        $details = [
            'ลิงก์หน้าเกี่ยวกับเรา: ' . ($hasAbout ? 'มี' : 'ไม่มี'),
            'ลิงก์ติดต่อ: ' . ($hasContact ? 'มี' : 'ไม่มี'),
        ];

        if ($organization === null) {
            $details[] = 'ไม่มี Organization schema';

            $score = ($hasAbout ? 0.2 : 0.0) + ($hasContact ? 0.2 : 0.0);

            return $this->partial(
                $score,
                'ไม่มี Organization schema',
                'ใส่ Organization schema ครั้งเดียวในเลย์เอาต์กลาง พร้อม name, url, logo, sameAs และถ้ามีหน้าร้านจริงให้ใส่ address กับ telephone ด้วย แล้วให้ทุกหน้าอ้างถึงด้วย @id เดียวกัน',
                $details
            );
        }

        $signals = [
            'name' => JsonLd::scalar($organization, 'name') !== null,
            'url' => JsonLd::scalar($organization, 'url') !== null,
            'logo' => isset($organization['logo']),
            'sameAs' => ! empty($organization['sameAs']),
            'address' => isset($organization['address']),
            'telephone' => JsonLd::scalar($organization, 'telephone') !== null,
        ];

        foreach ($signals as $key => $present) {
            $details[] = "{$key}: " . ($present ? 'มี' : 'ไม่มี');
        }

        $core = ['name', 'url', 'logo', 'sameAs'];
        $coreScore = count(array_filter(array_intersect_key($signals, array_flip($core)))) / count($core);
        $extraScore = ($signals['address'] ? 0.5 : 0.0) + ($signals['telephone'] ? 0.5 : 0.0);
        $navScore = ($hasAbout ? 0.5 : 0.0) + ($hasContact ? 0.5 : 0.0);

        $score = $coreScore * 0.6 + $extraScore * 0.2 + $navScore * 0.2;

        if ($score >= 0.9) {
            return $this->pass('ข้อมูลองค์กรครบถ้วน', $details);
        }

        $missing = array_keys(array_filter($signals, fn ($v) => ! $v));

        return $this->partial(
            $score,
            'ข้อมูลองค์กรยังไม่ครบ: ' . implode(', ', $missing),
            'เติมช่องที่ขาดใน Organization schema โดยเฉพาะ sameAs ที่ควรชี้ไปเพจ Facebook, LinkedIn หรือทะเบียนนิติบุคคล - นี่คือจุดที่ระบบใช้เชื่อมเว็บของคุณกับตัวตนที่มีอยู่จริงในโลก',
            $details
        );
    }
}
