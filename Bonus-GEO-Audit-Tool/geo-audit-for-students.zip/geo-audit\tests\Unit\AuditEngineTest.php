<?php

namespace Tests\Unit;

use App\Audit\AuditContext;
use App\Audit\Audits\Aeo\AnswerFirstAudit;
use App\Audit\Audits\Crawlability\CanonicalAudit;
use App\Audit\Audits\Crawlability\RobotsAllowsAiAudit;
use App\Audit\Audits\Seo\HeadingStructureAudit;
use App\Audit\Audits\StructuredData\SchemaMatchesContentAudit;
use App\Audit\Content\PageDocument;
use App\Audit\Content\PageType;
use App\Audit\Http\FetchedResponse;
use App\Audit\SiteContext;
use App\Audit\Support\RobotsTxt;
use App\Audit\Support\Sitemap;
use App\Audit\Support\Text;
use App\Audit\Support\Url;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

/**
 * ครอบคลุมส่วนที่พังเงียบที่สุดของ engine
 *
 * เน้นตรงที่เคยพังจริงตอนทดสอบกับเว็บจริง คือการเทียบ URL ภาษาไทย
 * และการอ่าน sitemap ที่ถูกตัดกลางคัน สองอันนี้ให้ผลลวงที่ดูน่าเชื่อ
 */
class AuditEngineTest extends TestCase
{
    // ---------- robots.txt ----------

    public function test_disallow_เปล่าไม่ได้แปลว่าห้ามทุกอย่าง(): void
    {
        $robots = RobotsTxt::parse("User-agent: *\nDisallow:\n");

        $this->assertTrue($robots->allows('GPTBot', '/any/path'));
    }

    public function test_รูปแบบที่ยาวกว่าชนะและ_allow_ชนะเมื่อยาวเท่ากัน(): void
    {
        $robots = RobotsTxt::parse("User-agent: *\nDisallow: /private/\nAllow: /private/public/\n");

        $this->assertFalse($robots->allows('GPTBot', '/private/secret'));
        $this->assertTrue($robots->allows('GPTBot', '/private/public/page'));
    }

    public function test_กลุ่มเจาะจงชนะกลุ่มดาว(): void
    {
        $robots = RobotsTxt::parse("User-agent: *\nDisallow: /\n\nUser-agent: OAI-SearchBot\nAllow: /\n");

        $this->assertFalse($robots->allows('SomeOtherBot', '/page'));
        $this->assertTrue($robots->allows('OAI-SearchBot', '/page'));
    }

    public function test_รองรับ_wildcard_และ_เครื่องหมายจบ(): void
    {
        $robots = RobotsTxt::parse("User-agent: *\nDisallow: /*.pdf$\n");

        $this->assertFalse($robots->allows('GPTBot', '/files/report.pdf'));
        $this->assertTrue($robots->allows('GPTBot', '/files/report.pdf.html'));
    }

    // ---------- การเทียบ URL ----------

    #[DataProvider('urlPairs')]
    public function test_เทียบ_url_ว่าเป็นหน้าเดียวกัน(string $a, string $b, bool $same): void
    {
        $this->assertSame($same, Url::sameDocument($a, $b));
    }

    public static function urlPairs(): array
    {
        return [
            'percent-encoded ไทย เท่ากับ utf-8 ดิบ' => [
                'https://e.com/article/ai-%E0%B8%84%E0%B8%B7%E0%B8%AD%E0%B8%AD%E0%B8%B0%E0%B9%84%E0%B8%A3',
                'https://e.com/article/ai-คืออะไร',
                true,
            ],
            'มี / ท้ายกับไม่มี' => ['https://e.com/page/', 'https://e.com/page', true],
            'พอร์ตมาตรฐาน' => ['https://e.com:443/page', 'https://e.com/page', true],
            'ข้าม query' => ['https://e.com/page?utm_source=x', 'https://e.com/page', true],
            'www ต่างกันคือคนละหน้า' => ['https://www.e.com/page', 'https://e.com/page', false],
            'คนละ path' => ['https://e.com/a', 'https://e.com/b', false],
        ];
    }

    // ---------- sitemap ----------

    public function test_อ่าน_sitemap_ได้พร้อมหา_entry_ที่ต้องการ(): void
    {
        $xml = <<<'XML'
        <?xml version="1.0" encoding="UTF-8"?>
        <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
          <url><loc>https://e.com/</loc><lastmod>2026-01-02T10:00:00+07:00</lastmod></url>
          <url><loc>https://e.com/blog/หนึ่ง</loc><lastmod>2026-03-04</lastmod></url>
        </urlset>
        XML;

        $sitemap = Sitemap::parse($xml, 'https://e.com/blog/%E0%B8%AB%E0%B8%99%E0%B8%B6%E0%B9%88%E0%B8%87');

        $this->assertTrue($sitemap->valid);
        $this->assertSame(2, $sitemap->totalUrls);
        $this->assertNotNull($sitemap->matchedEntry);
        $this->assertSame('2026-03-04', $sitemap->matchedEntry['lastmod']);
    }

    public function test_sitemap_ที่ถูกตัดกลางคันยังอ่านส่วนที่ได้มา(): void
    {
        $xml = '<?xml version="1.0"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
            . '<url><loc>https://e.com/a</loc></url>'
            . '<url><loc>https://e.com/b</loc></url>'
            . '<url><loc>https://e.com/c'; // ตัดกลางคันแบบที่เกิดเมื่อไฟล์ใหญ่เกินเพดาน

        $sitemap = Sitemap::parse($xml);

        $this->assertTrue($sitemap->valid, 'ต้องไม่ทิ้งทั้งไฟล์เพียงเพราะท้ายไฟล์ขาด');
        $this->assertSame(2, $sitemap->totalUrls);
    }

    public function test_ตรวจจับ_lastmod_ที่เป็นวันที่_build(): void
    {
        $entries = '';
        for ($i = 0; $i < 20; $i++) {
            $entries .= "<url><loc>https://e.com/p{$i}</loc><lastmod>2026-05-01T03:00:00+00:00</lastmod></url>";
        }

        $sitemap = Sitemap::parse('<urlset>' . $entries . '</urlset>');

        $this->assertTrue($sitemap->lastmodLooksLikeBuildStamp());
    }

    // ---------- ข้อความภาษาไทย ----------

    public function test_นับคำภาษาไทยได้ใกล้เคียงความจริง(): void
    {
        // ไทยไม่เว้นวรรค ถ้านับด้วยช่องว่างจะได้ 1 ซึ่งทำให้ทุก audit ที่วัดความยาวพัง
        $words = Text::wordCount('การทำเว็บให้ปรากฏในคำตอบของปัญญาประดิษฐ์ต้องอาศัยข้อมูลโครงสร้างที่ถูกต้อง');

        $this->assertGreaterThan(5, $words);
        $this->assertLessThan(40, $words);
    }

    /**
     * ต้องได้ผลใกล้เคียงกันไม่ว่า ICU บนเครื่องนั้นจะตัดคำไทยได้หรือไม่
     *
     * เจอจริงบนเซิร์ฟเวอร์: CentOS 7 มี ICU 50.2 ที่เรียก IntlBreakIterator ได้ปกติ
     * แต่ไม่มีพจนานุกรมไทย จึงคืนทั้งประโยคเป็นคำเดียว ทำให้คะแนนหมวด AEO
     * ร่วงจาก 35 เหลือ 4 บนหน้าเดียวกัน โดยไม่มี error ให้เห็นเลย
     */
    public function test_นับคำไทยได้ผลใกล้เคียงกันแม้_icu_ตัดคำไม่ได้(): void
    {
        $text = str_repeat('การทำเว็บให้ปรากฏในคำตอบของปัญญาประดิษฐ์ต้องอาศัยข้อมูลโครงสร้างที่ถูกต้อง ', 4);

        $actual = Text::wordCount($text);

        // ค่าที่ได้จากทางถอย (ประมาณจากจำนวนตัวอักษร) เมื่อ ICU ใช้ไม่ได้
        $thaiChars = preg_match_all('/\p{Thai}/u', $text);
        $fallback = (int) round($thaiChars / 3.5);

        $this->assertGreaterThan(20, $actual, 'ต้องไม่คืนค่าน้อยผิดปกติแบบที่ ICU 50 ทำ');
        $this->assertGreaterThan(20, $fallback, 'ทางถอยเองก็ต้องให้ค่าที่ใช้งานได้');

        // สองทางต้องไม่ต่างกันเกินเท่าตัว ไม่งั้นคะแนนจะขึ้นกับเครื่องที่รัน
        $ratio = max($actual, $fallback) / max(1, min($actual, $fallback));
        $this->assertLessThan(2.0, $ratio, "ผลต่างระหว่าง ICU ({$actual}) กับทางถอย ({$fallback}) มากเกินไป");
    }

    public function test_รู้จักคำถามภาษาไทยที่ไม่มีเครื่องหมายคำถาม(): void
    {
        $this->assertTrue(Text::isQuestion('GEO คืออะไร'));
        $this->assertTrue(Text::isQuestion('ต่างจาก SEO อย่างไร'));
        $this->assertTrue(Text::isQuestion('ราคาเท่าไหร่'));
        $this->assertFalse(Text::isQuestion('บริการของเรา'));
    }

    // ---------- การเดาประเภทหน้า ----------

    #[DataProvider('pageTypeCases')]
    public function test_เดาประเภทหน้าจาก_url(string $url, PageType $expected): void
    {
        $doc = PageDocument::parse('<html><body><p>เนื้อหา</p></body></html>');

        $this->assertSame($expected, PageType::infer($url, $doc));
    }

    public static function pageTypeCases(): array
    {
        return [
            ['https://e.com/', PageType::Home],
            ['https://e.com/blog/my-post', PageType::Article],
            ['https://e.com/blog', PageType::Collection],
            ['https://e.com/article/all', PageType::Collection],
            ['https://e.com/blog/page/2', PageType::Collection],
            ['https://e.com/contact', PageType::Contact],
            ['https://e.com/faq', PageType::Faq],
            ['https://e.com/services/seo', PageType::Service],
        ];
    }

    /**
     * og:type ต้องชนะการเดาจากความลึกของ path
     *
     * เคยผิดตรงนี้: permalink แบบ /%postname%/ ของ WordPress ให้ path ชั้นเดียว
     * บทความจึงถูกตัดสินเป็นหน้ารวมรายการ แล้วโดนเรียกหา CollectionPage schema
     * ผลคือหน้าที่ทำถูกทุกอย่างได้ 0.05 คะแนนในข้อที่หนักที่สุดของหมวด Structured Data
     */
    #[DataProvider('ogTypeCases')]
    public function test_og_type_มีน้ำหนักเหนือความลึกของ_path(string $url, string $ogType, PageType $expected): void
    {
        $doc = PageDocument::parse(
            '<html><head><meta property="og:type" content="' . $ogType . '"></head>'
            . '<body><article><h1>หัวเรื่อง</h1><p>เนื้อหา</p></article></body></html>'
        );

        $this->assertSame($expected, PageType::infer($url, $doc));
    }

    public static function ogTypeCases(): array
    {
        return [
            'permalink แบน' => ['https://e.com/hello-world', 'article', PageType::Article],
            'permalink มีโฟลเดอร์' => ['https://e.com/blog/hello-world', 'article', PageType::Article],
            'permalink แบบวันที่' => ['https://e.com/2026/01/hello-world', 'article', PageType::Article],
            'สินค้า permalink แบน' => ['https://e.com/my-product', 'product', PageType::Product],
            // path ที่บอกชัดว่าเป็นหน้าติดต่อ ยังชนะ og:type ที่ธีมใส่มาแบบเหมารวม
            'หน้าติดต่อยังเป็นหน้าติดต่อ' => ['https://e.com/contact', 'article', PageType::Contact],
        ];
    }

    // ---------- audit บน HTML จำลอง ----------

    public function test_canonical_ที่เข้ารหัสต่างกันยังนับว่าชี้ตัวเอง(): void
    {
        $html = '<html><head><link rel="canonical" href="https://e.com/บทความ/ทดสอบ"></head><body></body></html>';
        $ctx = $this->context('https://e.com/%E0%B8%9A%E0%B8%97%E0%B8%84%E0%B8%A7%E0%B8%B2%E0%B8%A1/%E0%B8%97%E0%B8%94%E0%B8%AA%E0%B8%AD%E0%B8%9A', $html);

        $result = (new CanonicalAudit)->run($ctx);

        $this->assertSame(1.0, $result->score);
    }

    public function test_บล็อกบอทที่ใช้อ้างอิงถูกหักคะแนนหนักกว่าบล็อกบอทเทรนโมเดล(): void
    {
        $blockRetrieval = $this->context('https://e.com/page', '<html></html>', "User-agent: OAI-SearchBot\nDisallow: /\n");
        $blockTraining = $this->context('https://e.com/page', '<html></html>', "User-agent: GPTBot\nDisallow: /\n");

        $audit = new RobotsAllowsAiAudit;

        $this->assertLessThan(0.7, $audit->run($blockRetrieval)->score);
        $this->assertGreaterThan(0.9, $audit->run($blockTraining)->score);
    }

    public function test_จับ_h1_ซ้ำและการข้ามระดับหัวข้อ(): void
    {
        $html = '<html><body><main><h1>หนึ่ง</h1><h1>สอง</h1><h2>สาม</h2><h4>ข้ามไป h4</h4></main></body></html>';

        $result = (new HeadingStructureAudit)->run($this->context('https://e.com/p', $html));

        $this->assertLessThan(0.7, $result->score);
        $this->assertStringContainsString('h1 2 ตัว', $result->displayValue);
    }

    public function test_จับ_faq_schema_ที่ไม่มีคำถามอยู่บนหน้าจริง(): void
    {
        $html = '<html><head><script type="application/ld+json">'
            . json_encode([
                '@context' => 'https://schema.org',
                '@type' => 'FAQPage',
                'mainEntity' => [
                    ['@type' => 'Question', 'name' => 'คำถามที่ไม่ได้แสดงบนหน้าเลยแม้แต่นิดเดียว'],
                ],
            ], JSON_UNESCAPED_UNICODE)
            . '</script></head><body><main><p>เนื้อหาที่ไม่เกี่ยวกับคำถามนั้น</p></main></body></html>';

        $result = (new SchemaMatchesContentAudit)->run($this->context('https://e.com/faq', $html));

        $this->assertNotNull($result->score);
        $this->assertLessThan(0.5, $result->score);
    }

    public function test_คำเกริ่นนำใต้หัวข้อคำถามถูกหักคะแนน(): void
    {
        $answer = str_repeat('รายละเอียดเพิ่มเติมของเรื่องนี้ ', 12);

        $direct = '<html><body><main><h2>GEO คืออะไร</h2><p>GEO คือการทำให้เนื้อหาเว็บถูกหยิบไปใช้ตอบคำถามในเครื่องมือค้นหาที่ขับเคลื่อนด้วยปัญญาประดิษฐ์ ' . $answer . '</p></main></body></html>';
        $preamble = '<html><body><main><h2>GEO คืออะไร</h2><p>ก่อนอื่นเรามาทำความเข้าใจกันก่อนว่าโลกของการค้นหาเปลี่ยนไปมากแค่ไหน ' . $answer . '</p></main></body></html>';

        $audit = new AnswerFirstAudit;
        $directScore = $audit->run($this->context('https://e.com/p', $direct))->score;
        $preambleScore = $audit->run($this->context('https://e.com/p', $preamble))->score;

        $this->assertGreaterThan($preambleScore, $directScore);
    }

    private function context(string $url, string $html, ?string $robots = null): AuditContext
    {
        $response = new FetchedResponse(
            requestedUrl: $url,
            finalUrl: $url,
            status: 200,
            headers: ['Content-Type' => ['text/html']],
            body: $html,
            elapsedMs: 120.0,
        );

        $site = $robots === null
            ? SiteContext::offline('https://e.com')
            : $this->siteWithRobots($robots);

        return AuditContext::make($url, $response, $site, offline: $robots === null);
    }

    private function siteWithRobots(string $robotsBody): SiteContext
    {
        // SiteContext::forUrl ยิงเน็ตจริง จึงประกอบขึ้นเองผ่าน reflection สำหรับการทดสอบ
        $reflection = new \ReflectionClass(SiteContext::class);
        $instance = $reflection->newInstanceWithoutConstructor();

        $set = function (string $property, mixed $value) use ($reflection, $instance) {
            $prop = $reflection->getProperty($property);
            $prop->setValue($instance, $value);
        };

        $set('origin', 'https://e.com');
        $set('robots', RobotsTxt::parse($robotsBody));
        $set('sitemapResponse', null);
        $set('sitemap', Sitemap::invalid());
        $set('sitemapUrl', null);
        $set('llmsTxt', null);
        $set('llmsFullTxt', null);

        return $instance;
    }
}
