<?php

use App\Http\Controllers\ReportController;
use Illuminate\Support\Facades\Route;

Route::get('/', [ReportController::class, 'index'])->name('home');

Route::post('/audit', [ReportController::class, 'store'])->name('reports.store');
Route::post('/audit/upload', [ReportController::class, 'upload'])->name('reports.upload');
Route::post('/audit/files', [ReportController::class, 'uploadFiles'])->name('reports.files');

Route::get('/r/{report}', [ReportController::class, 'show'])->name('reports.show');
Route::get('/r/{report}/status', [ReportController::class, 'status'])->name('reports.status');
Route::get('/r/{report}/json', [ReportController::class, 'json'])->name('reports.json');

Route::view('/about', 'about')->name('about');
