<?php

namespace App\Audit\Support;

/**
 * ตัวอ่าน robots.txt ตาม RFC 9309
 *
 * กติกาที่คนมักเข้าใจผิดและทำให้ตรวจผิด:
 * - จับกลุ่มตาม User-agent ที่ตรงที่สุด ถ้าไม่มีค่อยตกไป "*"
 * - ในกลุ่มเดียวกัน รูปแบบที่ยาวที่สุดชนะ ถ้ายาวเท่ากัน Allow ชนะ Disallow
 * - "Disallow:" ที่ว่างเปล่า = อนุญาตทุกอย่าง ไม่ใช่ห้ามทุกอย่าง
 */
final class RobotsTxt
{
    /**
     * @param  array<string, list<array{allow:bool, path:string}>>  $groups
     * @param  list<string>  $sitemaps
     */
    private function __construct(
        private readonly array $groups,
        public readonly array $sitemaps,
        public readonly bool $exists,
        public readonly string $raw,
    ) {}

    public static function missing(): self
    {
        return new self([], [], false, '');
    }

    public static function parse(string $content): self
    {
        $groups   = [];
        $sitemaps = [];

        $currentAgents = [];
        $expectAgent   = true;

        foreach (preg_split('/\R/', $content) ?: [] as $line) {
            $line = trim(strtok($line, '#') ?: '');
            if ($line === '' || ! str_contains($line, ':')) {
                continue;
            }

            [$field, $value] = array_map('trim', explode(':', $line, 2));
            $field           = strtolower($field);

            if ($field === 'sitemap') {
                if ($value !== '') {
                    $sitemaps[] = $value;
                }

                continue;
            }

            if ($field === 'user-agent') {
                if (! $expectAgent) {
                    $currentAgents = [];
                    $expectAgent   = true;
                }
                $agent = strtolower($value);
                if ($agent !== '') {
                    $currentAgents[] = $agent;
                    $groups[$agent] ??= [];
                }

                continue;
            }

            if (in_array($field, ['allow', 'disallow'], true)) {
                $expectAgent = false;
                foreach ($currentAgents as $agent) {
                    // "Disallow:" เปล่า = ไม่ห้ามอะไรเลย จึงข้ามไป ไม่ใช่บันทึกเป็นห้าม /
                    if ($field === 'disallow' && $value === '') {
                        continue;
                    }
                    $groups[$agent][] = ['allow' => $field === 'allow', 'path' => $value];
                }
            }
        }

        return new self($groups, $sitemaps, true, $content);
    }

    public function knowsAgent(string $agent): bool
    {
        return isset($this->groups[strtolower($agent)]);
    }

    /** @return list<string> ชื่อ user-agent ทั้งหมดที่ประกาศไว้ในไฟล์ */
    public function agents(): array
    {
        return array_keys($this->groups);
    }

    /** บอทตัวนี้เข้า path นี้ได้ไหม - ไม่มี robots.txt ถือว่าเข้าได้ */
    public function allows(string $agent, string $path): bool
    {
        if (! $this->exists) {
            return true;
        }

        $rules = $this->rulesFor($agent);
        if ($rules === []) {
            return true;
        }

        $best = null;
        foreach ($rules as $rule) {
            if (! $this->matches($rule['path'], $path)) {
                continue;
            }
            $len = strlen(rtrim($rule['path'], '$'));
            if ($best === null || $len > $best['len'] || ($len === $best['len'] && $rule['allow'])) {
                $best = ['len' => $len, 'allow' => $rule['allow']];
            }
        }

        return $best === null ? true : $best['allow'];
    }

    /** กลุ่มกฎที่ใช้กับบอทนี้ (เจาะจงก่อน แล้วค่อย *) */
    private function rulesFor(string $agent): array
    {
        $agent = strtolower($agent);

        if (isset($this->groups[$agent])) {
            return $this->groups[$agent];
        }

        // RFC: จับคู่แบบ prefix ของ product token เช่น "claudebot" ตรงกับกลุ่ม "claude"
        foreach ($this->groups as $name => $rules) {
            if ($name !== '*' && str_starts_with($agent, $name)) {
                return $rules;
            }
        }

        return $this->groups['*'] ?? [];
    }

    /** จับคู่ path แบบ robots: * = อะไรก็ได้, $ = จบพอดี */
    private function matches(string $pattern, string $path): bool
    {
        if ($pattern === '') {
            return false;
        }

        $anchored = str_ends_with($pattern, '$');
        $pattern  = $anchored ? substr($pattern, 0, -1) : $pattern;

        $regex = preg_quote($pattern, '#');
        $regex = str_replace('\*', '.*', $regex);

        return (bool) preg_match('#^'.$regex.($anchored ? '$' : '').'#', $path);
    }
}
