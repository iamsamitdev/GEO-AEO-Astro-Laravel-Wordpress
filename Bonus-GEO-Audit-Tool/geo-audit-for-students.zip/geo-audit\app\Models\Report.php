<?php

namespace App\Models;

use App\Audit\Category;
use App\Audit\Content\PageType;
use Illuminate\Database\Eloquent\Concerns\HasUlids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Carbon;

class Report extends Model
{
    use HasUlids;

    protected $fillable = [
        'ulid', 'mode', 'target', 'label', 'forced_page_type', 'status', 'use_ai',
        'score', 'pages_done', 'pages_total', 'error', 'requester_hash',
        'started_at', 'finished_at',
    ];

    protected function casts(): array
    {
        return [
            'use_ai' => 'boolean',
            'started_at' => 'datetime',
            'finished_at' => 'datetime',
        ];
    }

    public function uniqueIds(): array
    {
        return ['ulid'];
    }

    public function getRouteKeyName(): string
    {
        return 'ulid';
    }

    public function pages(): HasMany
    {
        return $this->hasMany(PageResult::class)->orderBy('position');
    }

    public function isFinished(): bool
    {
        return in_array($this->status, ['done', 'failed'], true);
    }

    /** ได้คะแนนเต็ม - ใช้ตัดสินว่าจะจุดพลุฉลองหรือไม่ */
    public function isPerfect(): bool
    {
        return $this->status === 'done' && (int) $this->score === 100;
    }

    public function statusLabel(): string
    {
        return match ($this->status) {
            'queued' => 'รอคิว',
            'running' => 'กำลังตรวจ',
            'done' => 'เสร็จแล้ว',
            'failed' => 'ล้มเหลว',
            default => $this->status,
        };
    }

    public function modeLabel(): string
    {
        return match ($this->mode) {
            'url' => 'หน้าเดียว',
            'site' => 'ทั้งเว็บ',
            'upload' => 'โฟลเดอร์ dist/ ที่อัปโหลด',
            'files' => 'ไฟล์ HTML ที่อัปโหลด',
            default => $this->mode,
        };
    }

    /**
     * เวลาที่สั่งตรวจ ในเขตเวลาที่ผู้ใช้อ่าน
     *
     * ฐานข้อมูลเก็บเป็น UTC (app.timezone) ห้าม format created_at ตรง ๆ ในหน้าเว็บ
     * ไม่งั้นจะได้เวลาช้ากว่าเวลาไทยจริง 7 ชั่วโมง
     */
    public function createdAtLocal(): ?Carbon
    {
        return $this->created_at?->copy()->setTimezone(config('geoaudit.display_timezone'));
    }

    /** ประเภทหน้าที่ผู้ใช้ระบุ - null คือให้ระบบเดาเอง */
    public function forcedPageType(): ?PageType
    {
        return $this->forced_page_type === null
            ? null
            : PageType::tryFrom($this->forced_page_type);
    }

    /**
     * คะแนนเฉลี่ยรายหมวดของทั้งรายงาน
     *
     * @return array<string, int|null>
     */
    public function categoryAverages(): array
    {
        $sums = [];
        $counts = [];

        foreach ($this->pages as $page) {
            foreach ($page->categoryScores() as $key => $value) {
                if ($value === null) {
                    continue;
                }
                $sums[$key] = ($sums[$key] ?? 0) + $value;
                $counts[$key] = ($counts[$key] ?? 0) + 1;
            }
        }

        $out = [];
        foreach (Category::ordered() as $category) {
            $key = $category->value;
            $out[$key] = isset($counts[$key]) && $counts[$key] > 0
                ? (int) round($sums[$key] / $counts[$key])
                : null;
        }

        return $out;
    }

    /**
     * ปัญหาที่พบซ้ำหลายหน้า เรียงตามจำนวนหน้าที่ตก
     *
     * @return list<array{id:string, title:string, category:string, pages:int, fix:string, worst:float}>
     */
    public function recurringIssues(int $limit = 10): array
    {
        $grouped = [];

        foreach ($this->pages as $page) {
            foreach ($page->audits() as $audit) {
                if (($audit['score'] ?? null) === null || $audit['score'] >= 0.9) {
                    continue;
                }

                $id = $audit['id'];
                $grouped[$id] ??= [
                    'id' => $id,
                    'title' => $audit['title'],
                    'category' => $audit['category'],
                    'pages' => 0,
                    'fix' => $audit['fix'] ?? '',
                    'worst' => 1.0,
                ];
                $grouped[$id]['pages']++;
                $grouped[$id]['worst'] = min($grouped[$id]['worst'], (float) $audit['score']);
                if ($grouped[$id]['fix'] === '' && ($audit['fix'] ?? '') !== '') {
                    $grouped[$id]['fix'] = $audit['fix'];
                }
            }
        }

        $issues = array_values($grouped);
        usort($issues, function (array $a, array $b) {
            return [$b['pages'], $a['worst']] <=> [$a['pages'], $b['worst']];
        });

        return array_slice($issues, 0, $limit);
    }
}
