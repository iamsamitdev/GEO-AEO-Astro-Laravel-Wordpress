<?php

namespace App\Audit\Audits\Aeo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Content\Section;
use App\Audit\Support\Text;

/**
 * หัวข้อที่เป็นคำถาม ตามด้วยคำตอบตรง ๆ ทันทีหรือเปล่า
 *
 * รูปแบบที่ระบบ retrieval หยิบไปใช้ได้ทันทีคือ:
 *   หัวข้อ = คำถาม, ย่อหน้าแรกใต้หัวข้อ = คำตอบที่จบในตัว ยาวประมาณ 40-120 คำ
 *
 * สิ่งที่ทำลายรูปแบบนี้คือการเกริ่นนำ - "ก่อนจะตอบคำถามนี้ เรามาทำความเข้าใจกันก่อนว่า..."
 * ย่อหน้าแบบนั้นถูกตัดไปเป็น chunk แล้วไม่มีคำตอบอยู่ในนั้นเลย
 *
 * ข้อนี้ตรวจด้วยกฎ ถ้าเปิดโหมด AI จะมีอีกข้อที่ให้ Claude อ่านว่า "ตอบตรงจริงไหม"
 */
final class AnswerFirstAudit extends BaseAudit
{
    private const MIN_ANSWER_WORDS = 25;

    private const IDEAL_MIN = 40;

    private const IDEAL_MAX = 140;

    /** วลีเกริ่นนำที่ผลักคำตอบให้ไปอยู่ท้ายย่อหน้า */
    private const PREAMBLE = [
        'ก่อนอื่น', 'ก่อนที่จะ', 'ก่อนจะ', 'ในบทความนี้', 'บทความนี้จะ', 'เรามาดูกัน',
        'มาทำความเข้าใจ', 'หลายคนสงสัย', 'เชื่อว่าหลายคน', 'ในยุคปัจจุบัน', 'ในปัจจุบัน',
        'ปฏิเสธไม่ได้ว่า', 'ต้องยอมรับว่า', 'อย่างที่ทราบกันดี',
        'in this article', 'before we', 'let us first', 'nowadays', 'in today',
    ];

    public function id(): string
    {
        return 'answer-first';
    }

    public function title(): string
    {
        return 'หัวข้อคำถามตามด้วยคำตอบทันที';
    }

    public function category(): Category
    {
        return Category::Aeo;
    }

    public function weight(): float
    {
        return 3.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $questionSections = array_values(array_filter(
            $ctx->document->sections(),
            fn (Section $s) => $s->heading !== null && Text::isQuestion($s->title())
        ));

        if ($questionSections === []) {
            return $this->na('หน้านี้ไม่มีหัวข้อที่เป็นคำถาม (ดูข้อ "หัวข้อในรูปคำถาม")');
        }

        $scores = [];
        $details = [];

        foreach ($questionSections as $section) {
            $first = $section->firstParagraph();
            $words = Text::wordCount($first);
            $title = Text::truncate($section->title(), 55);

            if ($first === '') {
                $scores[] = 0.0;
                $details[] = "ไม่มีย่อหน้าใต้หัวข้อ: {$title}";

                continue;
            }

            $score = 1.0;
            $notes = [];

            if ($words < self::MIN_ANSWER_WORDS) {
                $score -= 0.45;
                $notes[] = "สั้นเกิน ({$words} คำ)";
            } elseif ($words < self::IDEAL_MIN) {
                $score -= 0.15;
                $notes[] = "ค่อนข้างสั้น ({$words} คำ)";
            } elseif ($words > self::IDEAL_MAX * 2) {
                $score -= 0.35;
                $notes[] = "ยาวเกินกว่าจะเป็นคำตอบเดียว ({$words} คำ)";
            } elseif ($words > self::IDEAL_MAX) {
                $score -= 0.15;
                $notes[] = "ยาวกว่าช่วงที่เหมาะ ({$words} คำ)";
            }

            if ($this->startsWithPreamble($first)) {
                $score -= 0.4;
                $notes[] = 'ขึ้นต้นด้วยการเกริ่น ไม่ใช่คำตอบ';
            }

            $scores[] = max(0.0, $score);

            if ($notes !== []) {
                $details[] = "{$title} - " . implode(', ', $notes);
            }
        }

        $average = array_sum($scores) / count($scores);
        $good = count(array_filter($scores, fn ($s) => $s >= 0.9));
        $total = count($scores);

        array_unshift($details, "หัวข้อคำถามทั้งหมด {$total} ข้อ · ตอบตรงดี {$good} ข้อ");

        if ($average >= 0.9) {
            return $this->pass("{$good}/{$total} หัวข้อตอบตรง", $details);
        }

        return $this->partial(
            $average,
            "{$good}/{$total} หัวข้อตอบตรง",
            'ใต้หัวข้อที่เป็นคำถาม ให้ประโยคแรกเป็นคำตอบเลย แล้วค่อยขยายในย่อหน้าถัดไป ความยาวที่หยิบไปใช้ง่ายที่สุดคือ ' . self::IDEAL_MIN . '-' . self::IDEAL_MAX . ' คำ และตัดคำเกริ่นนำทิ้ง',
            $details
        );
    }

    private function startsWithPreamble(string $paragraph): bool
    {
        $opening = mb_strtolower(mb_substr(Text::normalizeWhitespace($paragraph), 0, 60, 'UTF-8'), 'UTF-8');

        foreach (self::PREAMBLE as $phrase) {
            if (str_contains($opening, mb_strtolower($phrase, 'UTF-8'))) {
                return true;
            }
        }

        return false;
    }
}
