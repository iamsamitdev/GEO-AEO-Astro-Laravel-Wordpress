<?php

namespace App\Audit\Audits\Seo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\Text;

/**
 * รูปมีคำบรรยายที่บอกเนื้อหาจริง
 *
 * นอกจากเรื่องการเข้าถึง alt ยังเป็นทางเดียวที่โมเดลข้อความล้วนจะรู้ว่าในรูปมีอะไร
 * ค่า alt ที่เป็นชื่อไฟล์ (IMG_2913.jpg) แย่พอ ๆ กับไม่มี
 *
 * alt="" ที่ตั้งใจใส่ให้รูปประดับถือว่าถูกต้อง ไม่หักคะแนน
 */
final class ImageAltAudit extends BaseAudit
{
    public function id(): string
    {
        return 'image-alt';
    }

    public function title(): string
    {
        return 'รูปมี alt ที่สื่อความ';
    }

    public function category(): Category
    {
        return Category::Seo;
    }

    public function weight(): float
    {
        return 1.5;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $images = $ctx->document->images();

        if ($images === []) {
            return $this->na('หน้านี้ไม่มีรูป <img>');
        }

        $missing = [];
        $filenameAlt = [];
        $good = 0;
        $decorative = 0;

        foreach ($images as $image) {
            if ($image['decorative']) {
                $decorative++;

                continue;
            }

            if ($image['alt'] === null || trim($image['alt']) === '') {
                $missing[] = basename($image['src'] ?: '(ไม่มี src)');

                continue;
            }

            if ($this->looksLikeFilename($image['alt'])) {
                $filenameAlt[] = $image['alt'];

                continue;
            }

            $good++;
        }

        $meaningful = count($images) - $decorative;

        if ($meaningful === 0) {
            return $this->pass('รูปทั้งหมดตั้ง alt="" ไว้เป็นรูปประดับ', ['จำนวนรูป: ' . count($images)]);
        }

        $details = [
            'รูปทั้งหมด: ' . count($images) . " (ประดับ {$decorative} · ต้องมี alt {$meaningful})",
            "alt ที่สื่อความ: {$good}",
        ];

        foreach (array_slice($missing, 0, 4) as $file) {
            $details[] = 'ไม่มี alt: ' . $file;
        }
        foreach (array_slice($filenameAlt, 0, 3) as $alt) {
            $details[] = 'alt เป็นชื่อไฟล์: ' . Text::truncate($alt, 50);
        }

        $score = $this->ratio($good, $meaningful);

        if ($score >= 0.95) {
            return $this->pass("{$good}/{$meaningful} รูปมี alt ที่ใช้ได้", $details);
        }

        return $this->partial(
            $score,
            "{$good}/{$meaningful} รูปมี alt ที่ใช้ได้",
            'เขียน alt เป็นประโยคที่บอกว่าในรูปมีอะไรและสื่ออะไรในบริบทของหน้า ถ้าเป็นรูปประดับล้วนให้ใส่ alt="" เพื่อบอกว่าตั้งใจข้าม',
            $details
        );
    }

    private function looksLikeFilename(string $alt): bool
    {
        return (bool) preg_match('/^[\w\-. ]+\.(jpe?g|png|gif|webp|avif|svg)$/i', trim($alt))
            || (bool) preg_match('/^(img|image|dsc|photo|pic|screenshot)[\s_-]?\d+$/i', trim($alt));
    }
}
