<?php

namespace App\Audit\Audits\Eeat;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\JsonLd;
use App\Audit\Support\Text;

/**
 * รู้ไหมว่าใครเขียน และคนนั้นเป็นใคร
 *
 * เวลา AI เลือกว่าจะอ้างใครในหัวข้อที่ต้องการความน่าเชื่อถือ
 * มันมองหาว่าเนื้อหามีคนรับผิดชอบที่ระบุตัวตนได้หรือไม่
 *
 * ระดับของสัญญาณ เรียงจากอ่อนไปแข็ง:
 *   1. มีชื่อผู้เขียนบนหน้า
 *   2. ชื่อนั้นลิงก์ไปหน้าประวัติผู้เขียน
 *   3. มี Person schema ที่มี @id ถาวร
 *   4. Person นั้นมี sameAs ชี้ไปโปรไฟล์ภายนอกที่ยืนยันตัวตนได้
 */
final class AuthorshipAudit extends BaseAudit
{
    public function id(): string
    {
        return 'authorship';
    }

    public function title(): string
    {
        return 'ระบุผู้เขียนที่ตรวจสอบตัวตนได้';
    }

    public function category(): Category
    {
        return Category::Eeat;
    }

    public function weight(): float
    {
        return 3.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $needsAuthor = in_array($ctx->pageType->value, ['article'], true);

        $jsonLd = $ctx->jsonLd();
        $person = $jsonLd->firstOfType('Person');
        $article = $jsonLd->firstOfType('Article')
            ?? $jsonLd->firstOfType('BlogPosting')
            ?? $jsonLd->firstOfType('NewsArticle');

        $authorValue = $article !== null ? ($article['author'] ?? null) : null;
        $bylineOnPage = $this->findByline($ctx);

        $details = [];
        $signals = 0;
        $max = 4;

        if ($bylineOnPage !== null) {
            $signals++;
            $details[] = 'ชื่อผู้เขียนบนหน้า: ' . Text::truncate($bylineOnPage, 60);
        } else {
            $details[] = 'ไม่พบชื่อผู้เขียนบนหน้า';
        }

        $authorLink = $ctx->document->has('//a[contains(@href,"/author/") or contains(@href,"/authors/") or contains(@href,"/team/") or @rel="author"]');
        if ($authorLink) {
            $signals++;
            $details[] = 'มีลิงก์ไปหน้าประวัติผู้เขียน';
        }

        if ($authorValue !== null) {
            $isObject = is_array($authorValue);
            $details[] = 'author ใน schema: ' . ($isObject ? 'เป็น object' : 'เป็นข้อความล้วน');
            if ($isObject) {
                $signals++;
            }
        } elseif ($article !== null) {
            $details[] = 'schema ของบทความไม่มี author';
        }

        if ($person !== null) {
            $name = JsonLd::scalar($person, 'name');
            $sameAs = $person['sameAs'] ?? null;
            $hasSameAs = is_array($sameAs) ? $sameAs !== [] : is_string($sameAs) && $sameAs !== '';

            $details[] = 'Person schema: ' . ($name ?? '(ไม่มีชื่อ)')
                . ' · sameAs: ' . ($hasSameAs ? 'มี' : 'ไม่มี')
                . ' · @id: ' . (isset($person['@id']) ? 'มี' : 'ไม่มี');

            if ($hasSameAs) {
                $signals++;
            }
        } else {
            $details[] = 'ไม่มี Person schema';
        }

        if (! $needsAuthor && $signals === 0) {
            return $this->na('หน้าประเภทนี้ไม่จำเป็นต้องระบุผู้เขียนรายบุคคล');
        }

        $score = $signals / $max;

        if ($score >= 0.9) {
            return $this->pass("ครบ {$signals}/{$max} สัญญาณ", $details);
        }

        if ($signals === 0) {
            return $this->fail(
                'ไม่มีสัญญาณผู้เขียนเลย',
                'ใส่ชื่อผู้เขียนพร้อมลิงก์ไปหน้าประวัติ และเพิ่ม Person schema ที่มี @id ถาวรและ sameAs ชี้ไป LinkedIn หรือโปรไฟล์ทางการอื่น - หน้าที่ไม่มีคนรับผิดชอบจะเสียเปรียบในหัวข้อที่ต้องการความเชี่ยวชาญ',
                $details
            );
        }

        return $this->partial(
            $score,
            "มี {$signals}/{$max} สัญญาณ",
            'ยกระดับจาก "ชื่อลอย ๆ" เป็น "ตัวตนที่ตรวจสอบได้": ทำหน้าประวัติผู้เขียน ใส่ Person schema ที่ใช้ @id เดียวกันทุกบทความ แล้วเชื่อม sameAs ไปโปรไฟล์ภายนอก',
            $details
        );
    }

    private function findByline(AuditContext $ctx): ?string
    {
        $selectors = [
            '//*[@rel="author"]',
            '//*[contains(concat(" ", normalize-space(@class), " "), " author ")]',
            '//*[contains(concat(" ", normalize-space(@class), " "), " byline ")]',
            '//*[@itemprop="author"]',
        ];

        foreach ($selectors as $selector) {
            $node = $ctx->document->first($selector);
            if ($node !== null) {
                $text = Text::normalizeWhitespace($node->textContent);
                if ($text !== '' && Text::length($text) < 120) {
                    return $text;
                }
            }
        }

        $bodyText = $ctx->document->bodyText();
        if (preg_match('/(เขียนโดย|ผู้เขียน|โดย)\s*[:：]?\s*([\p{Thai}A-Za-z. ]{3,40})/u', $bodyText, $m)) {
            return trim($m[0]);
        }

        return null;
    }
}
