<?php

namespace App\Audit;

use App\Audit\Content\PageType;

/**
 * ผลรวมของหน้าหนึ่งหน้า
 *
 * วิธีคิดคะแนนแบบเดียวกับ Lighthouse:
 *   คะแนนหมวด = ถัวเฉลี่ยถ่วงน้ำหนักของ audit ในหมวดนั้น (ข้ามตัวที่ N/A ไม่ใช่ให้ 0)
 *   คะแนนรวม  = ถัวเฉลี่ยถ่วงน้ำหนักของหมวด ตามน้ำหนักใน Category
 *
 * การข้าม N/A แทนการให้ 0 สำคัญมาก ไม่งั้นหน้า "ติดต่อเรา" จะโดนหักคะแนน
 * เพราะไม่มี schema ของบทความ ทั้งที่มันไม่ควรมีอยู่แล้ว
 */
final class PageReport
{
    /** @param list<AuditResult> $results */
    public function __construct(
        public readonly string $url,
        public readonly PageType $pageType,
        public readonly array $results,
        public readonly int $httpStatus,
        public readonly float $loadMs,
        public readonly int $bytes,
        public readonly ?string $error = null,
        /** true = ผู้ใช้ระบุประเภทหน้าเอง, false = ระบบเดาให้ */
        public readonly bool $pageTypeDeclared = false,
    ) {}

    public static function unreachable(string $url, string $error): self
    {
        return new self($url, PageType::Other, [], 0, 0.0, 0, $error);
    }

    public function failed(): bool
    {
        return $this->error !== null;
    }

    /** คะแนนรวม 0-100 */
    public function score(): int
    {
        if ($this->failed()) {
            return 0;
        }

        $sum = 0.0;
        $weight = 0.0;

        foreach (Category::ordered() as $category) {
            $categoryScore = $this->rawCategoryScore($category);
            if ($categoryScore === null) {
                continue;
            }
            $sum += $categoryScore * $category->weight();
            $weight += $category->weight();
        }

        return $weight > 0.0 ? (int) round($sum / $weight * 100) : 0;
    }

    /** คะแนนหมวด 0-100 หรือ null ถ้าไม่มี audit ที่ใช้ได้เลย */
    public function categoryScore(Category $category): ?int
    {
        $raw = $this->rawCategoryScore($category);

        return $raw === null ? null : (int) round($raw * 100);
    }

    private function rawCategoryScore(Category $category): ?float
    {
        $sum = 0.0;
        $weight = 0.0;

        foreach ($this->resultsIn($category) as $result) {
            if ($result->isNotApplicable()) {
                continue;
            }
            $sum += $result->score * $result->weight;
            $weight += $result->weight;
        }

        return $weight > 0.0 ? $sum / $weight : null;
    }

    /** @return list<AuditResult> */
    public function resultsIn(Category $category): array
    {
        return array_values(array_filter($this->results, fn (AuditResult $r) => $r->category === $category));
    }

    /**
     * สิ่งที่ควรแก้ก่อน เรียงตาม "ได้คะแนนคืนเยอะสุด"
     *
     * @return list<AuditResult>
     */
    public function opportunities(int $limit = 8): array
    {
        $failing = array_filter(
            $this->results,
            fn (AuditResult $r) => ! $r->isNotApplicable() && $r->score < 0.9
        );

        usort($failing, function (AuditResult $a, AuditResult $b) {
            $byImpact = $b->impact() * $b->category->weight() <=> $a->impact() * $a->category->weight();

            return $byImpact !== 0 ? $byImpact : $a->score <=> $b->score;
        });

        return array_slice(array_values($failing), 0, $limit);
    }

    public function countVerdict(string $verdict): int
    {
        return count(array_filter($this->results, fn (AuditResult $r) => $r->verdict() === $verdict));
    }

    public static function grade(int $score): string
    {
        return match (true) {
            $score >= 90 => 'พร้อมมาก',
            $score >= 75 => 'พร้อม',
            $score >= 50 => 'พอใช้',
            $score >= 25 => 'ต้องแก้',
            default => 'วิกฤต',
        };
    }

    public function toArray(): array
    {
        $categories = [];
        foreach (Category::ordered() as $category) {
            $categories[$category->value] = [
                'label' => $category->label(),
                'weight' => $category->weight(),
                'score' => $this->categoryScore($category),
            ];
        }

        return [
            'url' => $this->url,
            'pageType' => $this->pageType->value,
            'pageTypeLabel' => $this->pageType->label(),
            'pageTypeDeclared' => $this->pageTypeDeclared,
            'httpStatus' => $this->httpStatus,
            'loadMs' => $this->loadMs,
            'bytes' => $this->bytes,
            'error' => $this->error,
            'score' => $this->score(),
            'grade' => self::grade($this->score()),
            'categories' => $categories,
            'audits' => array_map(fn (AuditResult $r) => $r->toArray(), $this->results),
        ];
    }
}
