<?php

namespace App\Audit\Audits\Crawlability;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;

/**
 * meta robots และ X-Robots-Tag ปิดกั้นตัวเองอยู่หรือเปล่า
 *
 * ที่ต้องเน้นเป็นพิเศษคือ nosnippet และ max-snippet:0
 * สองอันนี้ไม่ได้ห้ามจัดทำดัชนี แต่ห้าม "ยกข้อความไปแสดง"
 * ซึ่งเท่ากับห้ามอ้างอิงพอดี คนตั้งมักไม่รู้ว่ามันมีผลกับ AI Overviews ด้วย
 */
final class MetaRobotsAudit extends BaseAudit
{
    public function id(): string
    {
        return 'meta-robots';
    }

    public function title(): string
    {
        return 'ไม่มีคำสั่งห้ามจัดทำดัชนีหรือห้ามยกข้อความ';
    }

    public function category(): Category
    {
        return Category::Crawlability;
    }

    public function weight(): float
    {
        return 2.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $directives = [];

        $meta = $ctx->document->metaRobots();
        if ($meta !== null) {
            $directives[] = ['source' => '<meta name="robots">', 'value' => strtolower($meta)];
        }

        foreach (['googlebot', 'google-extended'] as $name) {
            $value = $ctx->document->metaContent($name);
            if ($value !== null) {
                $directives[] = ['source' => '<meta name="' . $name . '">', 'value' => strtolower($value)];
            }
        }

        $header = $ctx->response->header('X-Robots-Tag');
        if ($header !== null) {
            $directives[] = ['source' => 'X-Robots-Tag header', 'value' => strtolower($header)];
        }

        if ($directives === []) {
            return $this->pass('ไม่มีคำสั่งจำกัด (ค่าเริ่มต้นคือ index, follow)');
        }

        $details = array_map(fn ($d) => "{$d['source']}: {$d['value']}", $directives);
        $all = implode(' ', array_column($directives, 'value'));

        if (str_contains($all, 'noindex')) {
            return $this->fail(
                'หน้านี้ตั้ง noindex',
                'เอา noindex ออกถ้าต้องการให้หน้านี้ถูกค้นเจอและถูกอ้างอิง ถ้าตั้งใจซ่อนหน้านี้จริง ก็ไม่ต้องตรวจ GEO กับมัน',
                $details
            );
        }

        $blocked = [];
        if (str_contains($all, 'nosnippet')) {
            $blocked[] = 'nosnippet';
        }
        if (preg_match('/max-snippet\s*:\s*0/', $all)) {
            $blocked[] = 'max-snippet:0';
        }
        if (str_contains($all, 'noarchive')) {
            $blocked[] = 'noarchive';
        }

        if ($blocked !== []) {
            return $this->partial(
                0.2,
                'ห้ามยกข้อความไปแสดง: ' . implode(', ', $blocked),
                'คำสั่งกลุ่มนี้ห้ามเครื่องมือค้นหาและ AI ยกข้อความจากหน้าไปแสดง เท่ากับตัดโอกาสถูกอ้างอิงทิ้ง ให้เอาออก หรือเปลี่ยนเป็น max-snippet:-1 ถ้าอยากให้ยกได้เต็มที่',
                $details
            );
        }

        if (str_contains($all, 'nofollow')) {
            return $this->partial(
                0.7,
                'ตั้ง nofollow ทั้งหน้า',
                'nofollow ระดับหน้าทำให้บอทไม่ตามลิงก์ภายในต่อ ทำให้หน้าอื่นถูกค้นพบยากขึ้น ควรเอาออกถ้าไม่มีเหตุผลเฉพาะ',
                $details
            );
        }

        return $this->pass('คำสั่งที่ตั้งไว้ไม่ปิดกั้นการอ้างอิง', $details);
    }
}
