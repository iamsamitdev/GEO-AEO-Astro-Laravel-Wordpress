<?php

namespace App\Audit\Audits\Aeo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\Text;

/**
 * ย่อหน้าแรกของหน้าบอกไปเลยหรือเปล่าว่าหน้านี้เกี่ยวกับอะไร
 *
 * ชิ้นเนื้อหาชิ้นแรกคือชิ้นที่ถูกดึงไปประเมินบ่อยที่สุด
 * ถ้ามันเป็นย่อหน้าเกริ่นกว้าง ๆ ระบบจะไม่รู้ว่าหน้านี้ตอบคำถามอะไรได้
 *
 * รูปแบบที่ได้ผลคือประโยคนิยาม: "X คือ ..." / "X is ..."
 * ที่มีคำหลักของหน้าอยู่ในประโยคเดียวกับคำอธิบาย
 */
final class DefinitionUpFrontAudit extends BaseAudit
{
    public function id(): string
    {
        return 'definition-up-front';
    }

    public function title(): string
    {
        return 'ย่อหน้าแรกสรุปว่าหน้านี้ตอบอะไร';
    }

    public function category(): Category
    {
        return Category::Aeo;
    }

    public function weight(): float
    {
        return 2.5;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $sections = $ctx->document->sections();

        if ($sections === []) {
            return $this->na('ไม่พบเนื้อหาที่แยกเป็นย่อหน้าได้');
        }

        $opening = '';
        foreach ($sections as $section) {
            $candidate = $section->firstParagraph();
            if (Text::wordCount($candidate) >= 10) {
                $opening = $candidate;
                break;
            }
        }

        if ($opening === '') {
            return $this->fail(
                'ไม่มีย่อหน้าเปิดที่มีเนื้อหาพอ',
                'เปิดหน้าด้วยย่อหน้า 2-3 ประโยคที่สรุปว่าหน้านี้ตอบคำถามอะไร โดยมีคำหลักอยู่ในประโยคแรก',
                []
            );
        }

        $words = Text::wordCount($opening);
        $h1 = $ctx->document->h1Texts()[0] ?? $ctx->document->title();
        $keyword = $this->keyword($h1);

        $hasDefinition = $this->looksLikeDefinition($opening);
        $mentionsKeyword = $keyword !== '' && $this->mentions($opening, $keyword);
        $stats = Text::countStats($opening);

        $details = [
            'ย่อหน้าเปิด: ' . Text::truncate($opening, 150),
            "ความยาว: {$words} คำ",
            'คำหลักจากหัวข้อ: ' . ($keyword === '' ? '(หาไม่ได้)' : $keyword),
            'มีรูปประโยคนิยาม: ' . ($hasDefinition ? 'ใช่' : 'ไม่'),
            'กล่าวถึงคำหลัก: ' . ($mentionsKeyword ? 'ใช่' : 'ไม่'),
        ];

        $score = 1.0;
        $issues = [];

        if (! $mentionsKeyword && $keyword !== '') {
            $score -= 0.35;
            $issues[] = 'ไม่พูดถึงคำหลักของหน้า';
        }

        if (! $hasDefinition) {
            $score -= 0.25;
            $issues[] = 'ไม่มีประโยคนิยามหรือประโยคสรุปตรง ๆ';
        }

        if ($words < 20) {
            $score -= 0.3;
            $issues[] = "สั้นเกินไป ({$words} คำ)";
        } elseif ($words > 160) {
            $score -= 0.2;
            $issues[] = "ยาวเกินกว่าจะเป็นบทสรุป ({$words} คำ)";
        }

        if ($stats > 0) {
            $score += 0.05;
            $details[] = "มีตัวเลข/สถิติในย่อหน้าเปิด: {$stats} จุด";
        }

        if ($issues === []) {
            return $this->pass("สรุปชัดใน {$words} คำ", $details);
        }

        return $this->partial(
            max(0.0, min(1.0, $score)),
            implode(' · ', $issues),
            'เขียนย่อหน้าแรกให้ตอบคำถามหลักของหน้าใน 40-80 คำ ใช้รูป "[คำหลัก] คือ ..." แล้วตามด้วยประโยคที่บอกว่าใครควรอ่านและจะได้อะไร',
            $details
        );
    }

    private function looksLikeDefinition(string $text): bool
    {
        $first = Text::sentences($text)[0] ?? $text;
        $first = mb_strtolower($first, 'UTF-8');

        $markers = [' คือ ', 'คือการ', 'คือระบบ', 'คือเครื่องมือ', 'หมายถึง', ' เป็นการ ', ' ได้แก่ ', ' is a ', ' is the ', ' refers to ', ' means '];

        foreach ($markers as $marker) {
            if (str_contains($first, mb_strtolower($marker, 'UTF-8'))) {
                return true;
            }
        }

        return false;
    }

    /** คำหลักอย่างหยาบจาก h1: ตัดคำเชื่อมและเครื่องหมายออก เอาช่วงที่ยาวที่สุด */
    private function keyword(string $heading): string
    {
        $heading = Text::normalizeWhitespace($heading);
        if ($heading === '') {
            return '';
        }

        $heading = preg_replace('/\s*[|\-–—:]\s*.*$/u', '', $heading) ?? $heading;

        return Text::truncate(trim($heading), 60);
    }

    private function mentions(string $text, string $keyword): bool
    {
        $normalize = static fn (string $s) => preg_replace('/[\s\p{P}]+/u', '', mb_strtolower($s, 'UTF-8')) ?? $s;

        $haystack = $normalize($text);
        $needle = $normalize($keyword);

        if ($needle === '' || $haystack === '') {
            return false;
        }

        if (str_contains($haystack, $needle)) {
            return true;
        }

        // หัวข้อยาวมักไม่ปรากฏทั้งท่อน เทียบทีละคำแล้วดูว่าเกินครึ่งอยู่ในย่อหน้าไหม
        $tokens = array_filter(
            preg_split('/[\s\p{P}]+/u', mb_strtolower($keyword, 'UTF-8')) ?: [],
            fn ($t) => mb_strlen($t, 'UTF-8') >= 3
        );

        if ($tokens === []) {
            return false;
        }

        $hits = 0;
        foreach ($tokens as $token) {
            if (str_contains($haystack, $normalize($token))) {
                $hits++;
            }
        }

        return $hits / count($tokens) >= 0.5;
    }
}
