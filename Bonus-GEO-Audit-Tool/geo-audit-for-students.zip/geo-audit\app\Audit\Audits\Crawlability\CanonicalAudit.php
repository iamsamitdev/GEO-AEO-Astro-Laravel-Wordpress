<?php

namespace App\Audit\Audits\Crawlability;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\Url;

/**
 * canonical ชี้มาที่ตัวเองแบบ absolute หรือเปล่า
 *
 * canonical ผิดทำให้เครดิตของหน้าไปตกที่ URL อื่น
 * และเมื่อ AI อ้างอิง มันจะอ้างลิงก์ตาม canonical ไม่ใช่ URL ที่มันเปิด
 */
final class CanonicalAudit extends BaseAudit
{
    public function id(): string
    {
        return 'canonical';
    }

    public function title(): string
    {
        return 'canonical ถูกต้องและชี้มาที่หน้านี้';
    }

    public function category(): Category
    {
        return Category::Crawlability;
    }

    public function weight(): float
    {
        return 2.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $canonical = $ctx->document->canonical();

        if ($canonical === null) {
            return $this->fail(
                'ไม่มี <link rel="canonical">',
                'ใส่ canonical แบบ URL เต็ม (https://...) ในทุกหน้า ให้ชี้มาที่ตัวเอง เพื่อรวมสัญญาณจาก URL ที่มีพารามิเตอร์ต่อท้ายมาที่เดียว',
                []
            );
        }

        $details = ["canonical: {$canonical}", "URL จริง: {$ctx->url}"];

        if (! preg_match('~^https?://~i', $canonical)) {
            return $this->partial(
                0.4,
                'canonical เป็น URL สัมพัทธ์',
                'เปลี่ยนเป็น URL เต็มที่มี https:// และโดเมนครบ - ตัวรวบรวมข้อมูลบางตัวตีความ path สัมพัทธ์ผิด',
                $details
            );
        }

        if (Url::sameDocument($canonical, $ctx->url)) {
            return $this->pass('ชี้มาที่ตัวเองแบบ absolute', $details);
        }

        /*
         * ตรวจไฟล์ที่อัปโหลดมาโดยไม่รู้โดเมนจริง จึงเทียบ canonical กับ URL ไม่ได้
         * canonical ที่ถูกต้องอยู่แล้วจะดูเหมือน "ชี้ไปหน้าอื่น" เสมอ
         * ให้ผ่านไปพร้อมบอกเหตุผล ดีกว่ารายงานปัญหาที่ไม่มีอยู่จริง
         */
        if ($ctx->syntheticBase) {
            return $this->pass(
                'มี canonical แบบ absolute (ข้ามการเทียบกับ URL)',
                array_merge($details, [
                    'ไม่ได้เทียบว่าชี้มาที่ตัวเองหรือไม่ เพราะยังไม่รู้โดเมนจริงของเว็บ',
                    'กรอกช่อง "URL ของเว็บจริง" ตอนอัปโหลด แล้วข้อนี้จะตรวจให้ครบ',
                ])
            );
        }

        $sameHost = Url::sameHost($canonical, $ctx->url);

        return $this->partial(
            $sameHost ? 0.5 : 0.2,
            'canonical ชี้ไปหน้าอื่น',
            $sameHost
                ? 'ถ้าตั้งใจให้หน้านี้เป็นฉบับซ้ำของอีกหน้า ก็ถูกแล้ว แต่ถ้าไม่ได้ตั้งใจ หน้านี้จะไม่ถูกจัดทำดัชนีในชื่อของตัวเอง ให้แก้ให้ชี้กลับมาที่ตัวเอง'
                : 'canonical ชี้ข้ามโดเมน ซึ่งจะยกเครดิตทั้งหมดไปให้โดเมนอื่น ตรวจสอบว่านี่คือสิ่งที่ตั้งใจจริง',
            $details
        );
    }
}
