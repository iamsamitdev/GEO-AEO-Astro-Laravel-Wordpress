{{--
    รายการ audit ทั้งหมดของหนึ่งหน้า พร้อมปุ่มกรองตามผล

    ใช้ <details> ของเบราว์เซอร์แทนการเขียน accordion เอง
    ทำให้ค้นในหน้าด้วย Ctrl+F เจอ และใช้งานได้แม้ JavaScript ไม่ทำงาน

    การกรองเป็น progressive enhancement: ถ้า JS ไม่ทำงาน ปุ่มกรองจะถูกซ่อน
    แล้วรายการทั้งหมดยังแสดงครบ ไม่ใช่หน้าว่างที่กดอะไรไม่ได้
--}}
@php
    $categories = \App\Audit\Category::ordered();

    $verdictLabels = [
        'pass' => 'ผ่าน',
        'average' => 'ต้องดู',
        'fail' => 'ตก',
        'na' => 'ไม่เกี่ยวข้อง',
    ];
@endphp

<div class="audit-list" data-audit-list>
    <div class="verdict-filter" role="group" aria-label="กรองผลตรวจตามประเภท" hidden>
        <button type="button" class="chip is-active" data-verdict="all" aria-pressed="true">
            <b>{{ count($page->audits()) }}</b> ทั้งหมด
        </button>

        @foreach ($verdictLabels as $verdict => $label)
            @php($count = $page->countVerdict($verdict))
            <button type="button"
                    class="chip v-{{ $verdict }}"
                    data-verdict="{{ $verdict }}"
                    aria-pressed="false"
                    @disabled($count === 0)>
                <span class="dot"></span><b>{{ $count }}</b> {{ $label }}
            </button>
        @endforeach
    </div>

    @foreach ($categories as $category)
        @php($items = $page->auditsIn($category))
        @continue($items === [])

        @php($categoryScore = $page->categoryScores()[$category->value] ?? null)

        <section class="audit-group">
            <h3>
                {{ $category->label() }}
                <span class="g-score {{ $categoryScore === null ? 'v-na' : ($categoryScore >= 90 ? 'v-pass' : ($categoryScore >= 50 ? 'v-average' : 'v-fail')) }}"
                      style="color:var(--gauge-color)">
                    {{ $categoryScore ?? '-' }}<span style="color:var(--text-faint);font-weight:400">/100</span>
                </span>
            </h3>
            <p class="g-desc">{{ $category->description() }}</p>

            @foreach ($items as $audit)
                <details class="audit v-{{ $audit['verdict'] }}" data-verdict="{{ $audit['verdict'] }}">
                    <summary>
                        <span class="dot"></span>
                        <span class="audit-title">
                            {{ $audit['title'] }}
                            @if (!empty($audit['byAi']))
                                <span class="badge-ai">AI</span>
                            @endif
                        </span>
                        <span class="audit-value">{{ $audit['displayValue'] ?: ($audit['verdict'] === 'na' ? 'ไม่เกี่ยวข้อง' : '') }}</span>
                    </summary>

                    <div class="audit-body">
                        @if (!empty($audit['details']))
                            <ul class="evidence">
                                @foreach ($audit['details'] as $line)
                                    {{-- หลักฐานมักมี URL ของหน้าที่ตรวจติดมา ถอดรหัสให้ภาษาไทยอ่านออก --}}
                                    <li class="url-text">{{ \App\Audit\Support\Url::forDisplay($line) }}</li>
                                @endforeach
                            </ul>
                        @endif

                        @if (!empty($audit['fix']))
                            <div class="fix">
                                <strong>วิธีแก้</strong>
                                {{ $audit['fix'] }}
                            </div>
                        @endif

                        @if (empty($audit['details']) && empty($audit['fix']))
                            <p style="margin:10px 0 0;color:var(--text-muted);font-size:13.5px">ไม่มีรายละเอียดเพิ่มเติม</p>
                        @endif
                    </div>
                </details>
            @endforeach
        </section>
    @endforeach
</div>
