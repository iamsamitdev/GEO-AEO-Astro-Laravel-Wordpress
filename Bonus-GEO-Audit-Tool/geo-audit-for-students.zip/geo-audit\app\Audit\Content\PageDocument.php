<?php

namespace App\Audit\Content;

use App\Audit\Support\JsonLd;
use App\Audit\Support\Text;
use DOMDocument;
use DOMElement;
use DOMNode;
use DOMXPath;

/**
 * แปลง HTML ดิบเป็นสิ่งที่ audit ถามได้
 *
 * ทุกอย่างที่นี่ทำงานบน HTML ที่เซิร์ฟเวอร์ส่งมา ไม่มีการรัน JavaScript
 * ซึ่งตรงกับสิ่งที่ AI crawler เห็นจริง
 */
final class PageDocument
{
    private DOMXPath $xpath;

    /** @var list<Heading>|null */
    private ?array $headingsCache = null;

    /** @var list<Section>|null */
    private ?array $sectionsCache = null;

    private ?string $mainTextCache = null;

    private const BOILERPLATE = ['nav', 'header', 'footer', 'aside', 'script', 'style', 'noscript', 'template', 'svg', 'form', 'iframe'];

    public function __construct(
        public readonly string $html,
        public readonly DOMDocument $dom,
        public readonly JsonLd $jsonLd,
    ) {
        $this->xpath = new DOMXPath($dom);
    }

    public static function parse(string $html): self
    {
        $dom = new DOMDocument;

        $previous = libxml_use_internal_errors(true);
        // ใส่ประกาศ encoding นำหน้าเพื่อบังคับให้ libxml อ่านเป็น UTF-8 ไม่งั้นภาษาไทยเพี้ยน
        $dom->loadHTML(
            '<?xml encoding="UTF-8">' . $html,
            LIBXML_NOWARNING | LIBXML_NOERROR | LIBXML_NOBLANKS
        );
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        return new self($html, $dom, self::extractJsonLd($html));
    }

    // ---------- head ----------

    public function title(): string
    {
        return Text::normalizeWhitespace($this->first('//head/title')?->textContent ?? '');
    }

    public function metaContent(string $name): ?string
    {
        $lower = strtolower($name);
        $node = $this->first(
            '//meta[translate(@name, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz")="' . $lower . '"]'
        );
        $value = $node instanceof DOMElement ? Text::normalizeWhitespace($node->getAttribute('content')) : null;

        return $value === '' ? null : $value;
    }

    public function propertyContent(string $property): ?string
    {
        $node = $this->first('//meta[@property="' . $property . '"]');
        $value = $node instanceof DOMElement ? Text::normalizeWhitespace($node->getAttribute('content')) : null;

        return $value === '' ? null : $value;
    }

    public function canonical(): ?string
    {
        $node = $this->first('//link[@rel="canonical"]');
        $value = $node instanceof DOMElement ? trim($node->getAttribute('href')) : null;

        return $value === '' ? null : $value;
    }

    public function htmlLang(): ?string
    {
        $node = $this->first('//html');
        $value = $node instanceof DOMElement ? trim($node->getAttribute('lang')) : null;

        return $value === '' ? null : $value;
    }

    /** @return list<array{hreflang:string, href:string}> */
    public function alternates(): array
    {
        $out = [];
        foreach ($this->xpath->query('//link[@rel="alternate"][@hreflang]') ?: [] as $node) {
            if ($node instanceof DOMElement) {
                $out[] = ['hreflang' => $node->getAttribute('hreflang'), 'href' => $node->getAttribute('href')];
            }
        }

        return $out;
    }

    public function metaRobots(): ?string
    {
        return $this->metaContent('robots');
    }

    // ---------- โครงเนื้อหา ----------

    /** @return list<Heading> */
    public function headings(): array
    {
        if ($this->headingsCache !== null) {
            return $this->headingsCache;
        }

        $out = [];
        $order = 0;
        foreach ($this->xpath->query('//h1|//h2|//h3|//h4|//h5|//h6') ?: [] as $node) {
            if (! $node instanceof DOMElement || $this->insideBoilerplate($node)) {
                continue;
            }
            $text = Text::normalizeWhitespace($node->textContent);
            if ($text === '') {
                continue;
            }
            $out[] = new Heading((int) substr($node->nodeName, 1), $text, $order++);
        }

        return $this->headingsCache = $out;
    }

    /** จำนวน h1 ทั้งหมดในหน้า รวมที่อยู่ใน header ด้วย เพราะกฎ "h1 เดียว" นับทั้งหน้า */
    public function h1Count(): int
    {
        return $this->xpath->query('//h1')?->length ?? 0;
    }

    /** @return list<string> */
    public function h1Texts(): array
    {
        $out = [];
        foreach ($this->xpath->query('//h1') ?: [] as $node) {
            $out[] = Text::normalizeWhitespace($node->textContent);
        }

        return $out;
    }

    /**
     * ตัดเนื้อหาเป็น section ตามหัวข้อ - หน่วยเดียวกับที่ระบบ RAG ใช้
     *
     * @return list<Section>
     */
    public function sections(): array
    {
        if ($this->sectionsCache !== null) {
            return $this->sectionsCache;
        }

        $root = $this->mainElement();
        if ($root === null) {
            return $this->sectionsCache = [];
        }

        $sections = [];
        $heading = null;
        $paragraphs = [];
        $listItems = 0;
        $tables = 0;
        $order = 0;

        $flush = function () use (&$sections, &$heading, &$paragraphs, &$listItems, &$tables): void {
            $section = new Section($heading, $paragraphs, $listItems, $tables);
            if (! $section->isEmpty() || $heading !== null) {
                $sections[] = $section;
            }
            $heading = null;
            $paragraphs = [];
            $listItems = 0;
            $tables = 0;
        };

        foreach ($this->walk($root) as $node) {
            $name = strtolower($node->nodeName);

            if (preg_match('/^h[1-6]$/', $name)) {
                if ($heading !== null || $paragraphs !== []) {
                    $flush();
                }
                $text = Text::normalizeWhitespace($node->textContent);
                $heading = $text === '' ? null : new Heading((int) substr($name, 1), $text, $order++);

                continue;
            }

            if (in_array($name, ['p', 'blockquote', 'dd'], true)) {
                $text = Text::normalizeWhitespace($node->textContent);
                if ($text !== '') {
                    $paragraphs[] = $text;
                }

                continue;
            }

            if (in_array($name, ['ul', 'ol'], true)) {
                $listItems += $this->xpath->query('.//li', $node)?->length ?? 0;

                continue;
            }

            if ($name === 'table') {
                $tables++;
            }
        }

        $flush();

        return $this->sectionsCache = array_values(array_filter($sections, fn (Section $s) => ! $s->isEmpty()));
    }

    /** ข้อความเนื้อหาหลัก ตัด nav/footer/script ออกแล้ว */
    public function mainText(): string
    {
        if ($this->mainTextCache !== null) {
            return $this->mainTextCache;
        }

        $root = $this->mainElement();
        if ($root === null) {
            return $this->mainTextCache = '';
        }

        return $this->mainTextCache = Text::normalizeWhitespace(
            $this->textWithout($root, self::BOILERPLATE)
        );
    }

    /** ข้อความทั้งหน้าแบบดิบ ใช้ตรวจว่าหน้าพึ่ง JS หรือเปล่า */
    public function bodyText(): string
    {
        $body = $this->first('//body');
        if (! $body instanceof DOMElement) {
            return '';
        }

        return Text::normalizeWhitespace(
            $this->textWithout($body, ['script', 'style', 'noscript', 'template'])
        );
    }

    // ---------- ลิงก์และรูป ----------

    /** @return list<array{href:string, text:string, rel:string}> */
    public function links(): array
    {
        $out = [];
        foreach ($this->xpath->query('//a[@href]') ?: [] as $node) {
            if (! $node instanceof DOMElement) {
                continue;
            }
            $out[] = [
                'href' => trim($node->getAttribute('href')),
                'text' => Text::normalizeWhitespace($node->textContent),
                'rel' => strtolower($node->getAttribute('rel')),
            ];
        }

        return $out;
    }

    /** @return list<array{src:string, alt:?string, decorative:bool}> */
    public function images(): array
    {
        $out = [];
        foreach ($this->xpath->query('//img') ?: [] as $node) {
            if (! $node instanceof DOMElement) {
                continue;
            }
            $hasAlt = $node->hasAttribute('alt');
            $alt = $hasAlt ? Text::normalizeWhitespace($node->getAttribute('alt')) : null;
            $out[] = [
                'src' => trim($node->getAttribute('src') ?: $node->getAttribute('data-src')),
                'alt' => $alt,
                'decorative' => $hasAlt && $alt === '',
            ];
        }

        return $out;
    }

    public function externalScriptCount(): int
    {
        return $this->xpath->query('//script[@src]')?->length ?? 0;
    }

    public function countTag(string $tag): int
    {
        return $this->xpath->query('//' . $tag)?->length ?? 0;
    }

    public function has(string $xpath): bool
    {
        return ($this->xpath->query($xpath)?->length ?? 0) > 0;
    }

    /** @return list<DOMNode> */
    public function query(string $xpath): array
    {
        $out = [];
        foreach ($this->xpath->query($xpath) ?: [] as $node) {
            $out[] = $node;
        }

        return $out;
    }

    public function first(string $xpath): ?DOMNode
    {
        $nodes = $this->xpath->query($xpath);

        return $nodes && $nodes->length > 0 ? $nodes->item(0) : null;
    }

    // ---------- ภายใน ----------

    /** เลือกกล่องเนื้อหาหลัก: main > article > [role=main] > .entry-content > body */
    private function mainElement(): ?DOMElement
    {
        $selectors = [
            '//main',
            '//article',
            '//*[@role="main"]',
            '//*[contains(concat(" ", normalize-space(@class), " "), " entry-content ")]',
            '//body',
        ];

        foreach ($selectors as $selector) {
            $node = $this->first($selector);
            if ($node instanceof DOMElement) {
                return $node;
            }
        }

        return null;
    }

    /**
     * textContent ของ element โดยตัด tag ที่ไม่ใช่เนื้อหาออกก่อน
     *
     * โคลนออกมาทำในเอกสารแยก จะได้ไม่ไปแก้ DOM จริงที่ audit ตัวอื่นยังใช้อยู่
     *
     * @param  list<string>  $remove
     */
    private function textWithout(DOMElement $element, array $remove): string
    {
        $scratch = new DOMDocument;
        $scratch->appendChild($scratch->importNode($element, true));

        $scratchXpath = new DOMXPath($scratch);
        $selector = '//' . implode('|//', $remove);

        foreach (iterator_to_array($scratchXpath->query($selector) ?: []) as $node) {
            $node->parentNode?->removeChild($node);
        }

        return $scratch->textContent;
    }

    private function insideBoilerplate(DOMElement $node): bool
    {
        for ($parent = $node->parentNode; $parent instanceof DOMElement; $parent = $parent->parentNode) {
            if (in_array(strtolower($parent->nodeName), ['nav', 'footer', 'aside'], true)) {
                return true;
            }
        }

        return false;
    }

    /**
     * เดินต้นไม้แบบ pre-order แต่ไม่ลงไปใน boilerplate
     * และไม่ลงไปในลูกของ block ที่เก็บค่าไปแล้ว (กันนับซ้ำ)
     *
     * @return iterable<DOMElement>
     */
    private function walk(DOMNode $node): iterable
    {
        foreach ($node->childNodes ?? [] as $child) {
            if (! $child instanceof DOMElement) {
                continue;
            }

            $name = strtolower($child->nodeName);

            if (in_array($name, self::BOILERPLATE, true)) {
                continue;
            }

            yield $child;

            if (in_array($name, ['p', 'ul', 'ol', 'table', 'blockquote'], true) || preg_match('/^h[1-6]$/', $name)) {
                continue;
            }

            yield from $this->walk($child);
        }
    }

    private static function extractJsonLd(string $html): JsonLd
    {
        preg_match_all(
            '#<script\b[^>]*type\s*=\s*["\']application/ld\+json["\'][^>]*>(.*?)</script>#is',
            $html,
            $matches
        );

        $blocks = [];
        $errors = [];

        foreach ($matches[1] ?? [] as $raw) {
            $raw = trim(html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
            if ($raw === '') {
                continue;
            }
            $decoded = json_decode($raw, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $errors[] = json_last_error_msg();

                continue;
            }
            $blocks[] = $decoded;
        }

        return new JsonLd($blocks, $errors);
    }
}
