<?php

namespace App\Audit;

use App\Audit\Content\PageDocument;
use App\Audit\Content\PageType;
use App\Audit\Http\FetchedResponse;
use App\Audit\Support\JsonLd;

/**
 * ทุกอย่างที่ audit ตัวหนึ่งต้องใช้ในการตัดสินหน้าหนึ่งหน้า
 *
 * สร้างครั้งเดียวต่อหน้า แล้วส่งต่อให้ audit ทุกตัว - audit ห้ามยิง HTTP เอง
 * เพื่อให้จำนวน request ต่อหน้าคาดเดาได้ และให้ audit ทดสอบได้โดยไม่ต้องมีเน็ต
 */
final class AuditContext
{
    public function __construct(
        public readonly string $url,
        public readonly FetchedResponse $response,
        public readonly PageDocument $document,
        public readonly PageType $pageType,
        public readonly SiteContext $site,
        /** โหมดไฟล์ในเครื่อง (ตรวจ dist/ ที่อัปโหลดมา) - audit ที่ต้องยิงเน็ตจะข้ามไป */
        public readonly bool $offline = false,
        /**
         * โดเมนใน $url เป็นค่าสมมติ ไม่ใช่โดเมนจริงของเว็บ
         *
         * เกิดตอนผู้ใช้อัปโหลด dist/ โดยไม่กรอก URL ของเว็บจริง
         * audit ที่เทียบ URL ของหน้ากับค่าในหน้า (canonical, og:url) ต้องงดตัดสิน
         * ไม่งั้นจะรายงานว่า canonical ผิดทั้งที่มันถูกต้องอยู่แล้ว
         */
        public readonly bool $syntheticBase = false,
        /**
         * ประเภทหน้ามาจากไหน: ผู้ใช้ระบุเอง หรือระบบเดาให้
         *
         * รายงานต้องบอกให้ชัด เพราะการเดาผิดจะเปลี่ยนเกณฑ์ทั้งหมวด Structured Data
         * ผู้อ่านควรรู้ว่าตัวเลขที่เห็นตั้งอยู่บนสมมติฐานอะไร
         */
        public readonly bool $pageTypeDeclared = false,
    ) {}

    public static function make(
        string $url,
        FetchedResponse $response,
        SiteContext $site,
        bool $offline = false,
        bool $syntheticBase = false,
        ?PageType $forcedPageType = null,
    ): self {
        $document = PageDocument::parse($response->body);

        return new self(
            url: $response->finalUrl !== '' ? $response->finalUrl : $url,
            response: $response,
            document: $document,
            pageType: $forcedPageType ?? PageType::infer($url, $document),
            site: $site,
            offline: $offline,
            syntheticBase: $syntheticBase,
            pageTypeDeclared: $forcedPageType !== null,
        );
    }

    public function jsonLd(): JsonLd
    {
        return $this->document->jsonLd;
    }

    public function path(): string
    {
        $path = parse_url($this->url, PHP_URL_PATH);

        return is_string($path) && $path !== '' ? $path : '/';
    }

    public function host(): string
    {
        return strtolower((string) parse_url($this->url, PHP_URL_HOST));
    }

    public function origin(): string
    {
        $parts = parse_url($this->url);

        return ($parts['scheme'] ?? 'https') . '://' . ($parts['host'] ?? '')
            . (isset($parts['port']) ? ':' . $parts['port'] : '');
    }

    public function isHttps(): bool
    {
        return str_starts_with(strtolower($this->url), 'https://');
    }

    /** ลิงก์นี้ชี้ออกนอกโดเมนหรือไม่ */
    public function isExternalLink(string $href): bool
    {
        if ($href === '' || str_starts_with($href, '#') || str_starts_with($href, 'mailto:') || str_starts_with($href, 'tel:')) {
            return false;
        }

        $host = parse_url($this->absolute($href), PHP_URL_HOST);

        return is_string($host) && strtolower($host) !== $this->host();
    }

    /** แปลง href สัมพัทธ์เป็น URL เต็ม */
    public function absolute(string $href): string
    {
        $href = trim($href);

        if ($href === '' || preg_match('~^[a-z][a-z0-9+.-]*:~i', $href)) {
            return $href;
        }

        if (str_starts_with($href, '//')) {
            return (parse_url($this->url, PHP_URL_SCHEME) ?: 'https') . ':' . $href;
        }

        if (str_starts_with($href, '/')) {
            return $this->origin() . $href;
        }

        $base = preg_replace('~/[^/]*$~', '/', $this->path()) ?: '/';

        return $this->origin() . $base . ltrim($href, './');
    }
}
