<?php

namespace App\Audit\Support;

use IntlBreakIterator;

/**
 * งานข้อความที่ต้องรองรับภาษาไทย
 *
 * ไทยไม่เว้นวรรคระหว่างคำ การนับคำด้วย str_word_count หรือ explode(' ') จึงผิดเสมอ
 * ที่นี่ใช้ ICU BreakIterator (ext-intl) ซึ่งมีพจนานุกรมภาษาไทยมาให้
 *
 * แต่ต้องทดสอบก่อนใช้ทุกครั้ง ไม่ใช่แค่เช็คว่ามี ext-intl ไหม
 * เพราะ ICU รุ่นเก่าบางรุ่นเรียกใช้ได้ปกติแต่ตัดคำไทยไม่ออก (ดู thaiSegmentationWorks)
 * ถ้าใช้ไม่ได้จะถอยไปประมาณเอา (ไทย ~3.5 ตัวอักษร / คำ)
 */
final class Text
{
    private static ?bool $thaiSegmentationWorks = null;

    /**
     * ประโยคทดสอบที่รู้คำตอบล่วงหน้า - ICU ที่ใช้ได้ต้องตัดได้อย่างน้อย 5 คำ
     * ICU ที่ไม่มีพจนานุกรมไทยจะคืนมาเป็นก้อนเดียว
     */
    private const THAI_PROBE = 'การทำเว็บให้ปรากฏในคำตอบของปัญญาประดิษฐ์';

    private const THAI_PROBE_MIN_WORDS = 5;

    public static function normalizeWhitespace(string $s): string
    {
        $s = preg_replace('/\x{00A0}|\x{200B}/u', ' ', $s) ?? $s;

        return trim(preg_replace('/\s+/u', ' ', $s) ?? $s);
    }

    public static function hasThai(string $s): bool
    {
        return (bool) preg_match('/\p{Thai}/u', $s);
    }

    /** นับคำแบบรองรับไทย+อังกฤษปนกัน */
    public static function wordCount(string $s): int
    {
        $s = self::normalizeWhitespace($s);
        if ($s === '') {
            return 0;
        }

        if (! self::hasThai($s)) {
            return count(preg_split('/\s+/u', $s, -1, PREG_SPLIT_NO_EMPTY) ?: []);
        }

        if (self::thaiSegmentationWorks()) {
            return self::countWithIcu($s);
        }

        // ถอยไปประมาณเอา: ไทยราว 3.5 ตัวอักษรต่อคำ ส่วนที่ไม่ใช่ไทยนับด้วยช่องว่าง
        $thaiChars = preg_match_all('/\p{Thai}/u', $s) ?: 0;
        $rest      = preg_replace('/\p{Thai}+/u', ' ', $s) ?? '';
        $restWords = count(preg_split('/\s+/u', trim($rest), -1, PREG_SPLIT_NO_EMPTY) ?: []);

        return (int) round($thaiChars / 3.5) + $restWords;
    }

    /**
     * ICU ตัวนี้ตัดคำไทยได้จริงหรือแค่มี ext-intl ติดตั้งอยู่
     *
     * นี่ไม่ใช่การเช็คเผื่อไว้ แต่แก้ปัญหาที่เกิดขึ้นจริงบนเซิร์ฟเวอร์ปลายทาง:
     * CentOS 7 มาพร้อม ICU 50.2 ซึ่งมี ext-intl ครบและเรียก IntlBreakIterator ได้
     * แต่ไม่มีพจนานุกรมภาษาไทย จึงคืนทั้งประโยคเป็นคำเดียว
     *
     * ความเสียหายคือมันเงียบสนิท ไม่มี error ให้เห็น แต่ทุก audit ที่วัดความยาวเนื้อหา
     * จะได้ตัวเลขผิดหมด ทำให้คะแนนหมวด AEO ทั้งหมวด (น้ำหนัก 20) พังโดยไม่มีใครรู้
     * เทียบจริงบนหน้าเดียวกัน: เครื่องพัฒนา ICU 72 ได้ 35 คะแนน เซิร์ฟเวอร์ ICU 50 ได้ 4
     *
     * จึงต้องทดสอบด้วยประโยคที่รู้คำตอบ แทนการเชื่อว่ามี ext-intl แล้วจะใช้ได้
     */
    public static function thaiSegmentationWorks(): bool
    {
        if (self::$thaiSegmentationWorks !== null) {
            return self::$thaiSegmentationWorks;
        }

        if (! class_exists(IntlBreakIterator::class)) {
            return self::$thaiSegmentationWorks = false;
        }

        try {
            $segments = self::countWithIcu(self::THAI_PROBE);
        } catch (\Throwable) {
            return self::$thaiSegmentationWorks = false;
        }

        return self::$thaiSegmentationWorks = $segments >= self::THAI_PROBE_MIN_WORDS;
    }

    private static function countWithIcu(string $s): int
    {
        $iterator = IntlBreakIterator::createWordInstance('th_TH');
        $iterator->setText($s);

        $n = 0;
        foreach ($iterator->getPartsIterator() as $part) {
            if (preg_match('/[\p{L}\p{N}]/u', $part)) {
                $n++;
            }
        }

        return $n;
    }

    /** ตัดประโยค รองรับทั้ง . ! ? และการขึ้นบรรทัด/เว้นวรรคยาวแบบไทย */
    public static function sentences(string $s): array
    {
        $s = self::normalizeWhitespace($s);
        if ($s === '') {
            return [];
        }

        $parts = preg_split('/(?<=[.!?\x{0E2F}])\s+|\s{2,}/u', $s, -1, PREG_SPLIT_NO_EMPTY) ?: [];

        return array_values(array_filter(array_map('trim', $parts), fn ($p) => $p !== ''));
    }

    /** ความยาวตัวอักษรที่มองเห็น (ไม่ใช่ไบต์) */
    public static function length(string $s): int
    {
        return mb_strlen(self::normalizeWhitespace($s), 'UTF-8');
    }

    public static function truncate(string $s, int $max = 120): string
    {
        $s = self::normalizeWhitespace($s);

        return mb_strlen($s, 'UTF-8') <= $max ? $s : mb_substr($s, 0, $max - 1, 'UTF-8').'…';
    }

    /**
     * heading นี้เป็นคำถามหรือเปล่า - รองรับรูปแบบคำถามไทยที่มักไม่มี ?
     */
    public static function isQuestion(string $s): bool
    {
        $s = self::normalizeWhitespace($s);
        if ($s === '') {
            return false;
        }

        if (str_contains($s, '?') || str_contains($s, '？')) {
            return true;
        }

        $thaiCues = [
            'คืออะไร', 'คือ อะไร', 'ทำไม', 'อย่างไร', 'ยังไง', 'เมื่อไร', 'เมื่อไหร่',
            'ที่ไหน', 'ใคร', 'อันไหน', 'แบบไหน', 'เท่าไร', 'เท่าไหร่', 'กี่',
            'ต่างกันอย่างไร', 'ควร', 'จำเป็นไหม', 'ได้ไหม', 'หรือไม่', 'วิธี', 'ขั้นตอน',
        ];
        foreach ($thaiCues as $cue) {
            if (str_contains($s, $cue)) {
                return true;
            }
        }

        $enCues = ['what ', 'why ', 'how ', 'when ', 'where ', 'who ', 'which ', 'can ', 'should ', 'is ', 'are ', 'does ', 'do '];
        $lower  = mb_strtolower($s, 'UTF-8').' ';
        foreach ($enCues as $cue) {
            if (str_starts_with($lower, $cue)) {
                return true;
            }
        }

        return false;
    }

    /** มีตัวเลข/สถิติ/หน่วย ที่ LLM ชอบหยิบไปอ้างหรือไม่ */
    public static function countStats(string $s): int
    {
        $patterns = [
            '/\d+(\.\d+)?\s*%/u',                       // 42%
            '/\b\d{4}\b/u',                             // ปี ค.ศ.
            '/\b25\d{2}\b/u',                           // ปี พ.ศ.
            '/\d+(\.\d+)?\s*(บาท|ล้าน|พัน|แสน|คน|ครั้ง|เท่า|วัน|ชั่วโมง|นาที|วินาที|GB|MB|KB|ms|วิ)/iu',
            '/[\$€£฿]\s?\d/u',
        ];

        $n = 0;
        foreach ($patterns as $p) {
            $n += preg_match_all($p, $s) ?: 0;
        }

        return $n;
    }

}
