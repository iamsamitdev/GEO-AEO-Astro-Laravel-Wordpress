<?php

namespace App\Audit\Audits\Crawlability;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;

/**
 * หน้านี้ตอบ 200 ผ่าน HTTPS โดยไม่ต้องเด้งหลายทอดหรือเปล่า
 *
 * บอทหลายตัวตาม redirect ได้จำกัด และ redirect ทุกทอดคือโอกาสที่จะหลุด
 */
final class HttpStatusAudit extends BaseAudit
{
    public function id(): string
    {
        return 'http-status';
    }

    public function title(): string
    {
        return 'ตอบ 200 ผ่าน HTTPS โดยไม่เด้งหลายทอด';
    }

    public function category(): Category
    {
        return Category::Crawlability;
    }

    public function weight(): float
    {
        return 2.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        if ($ctx->offline) {
            return $this->na('โหมดตรวจไฟล์ในเครื่อง ไม่มีการตอบกลับจริงให้ตรวจ');
        }

        $response = $ctx->response;
        $hops = count($response->redirectChain);

        $details = ["สถานะ: {$response->status}"];
        if ($hops > 0) {
            $details[] = 'เส้นทาง redirect: ' . implode(' -> ', array_merge([$response->requestedUrl], $response->redirectChain));
        }

        if ($response->status >= 400) {
            return $this->fail(
                "เซิร์ฟเวอร์ตอบ {$response->status}",
                $response->status === 404
                    ? 'หน้านี้ไม่มีอยู่ ถ้าย้ายไปที่อื่นแล้วให้ทำ 301 ไปหน้าใหม่ ไม่ใช่ปล่อย 404'
                    : 'แก้ให้หน้าตอบ 200 ก่อน ทุกอย่างที่เหลือไม่มีความหมายถ้าบอทเปิดหน้าไม่ได้',
                $details
            );
        }

        $score = 1.0;
        $issues = [];

        if (! $ctx->isHttps()) {
            $score -= 0.5;
            $issues[] = 'ยังเป็น http ไม่ใช่ https';
        }

        if ($hops >= 3) {
            $score -= 0.4;
            $issues[] = "เด้ง {$hops} ทอดก่อนถึงหน้าจริง";
        } elseif ($hops === 2) {
            $score -= 0.2;
            $issues[] = 'เด้ง 2 ทอดก่อนถึงหน้าจริง';
        }

        if ($issues === []) {
            return $this->pass('200 OK ผ่าน HTTPS ไม่มี redirect', $details);
        }

        return $this->partial(
            $score,
            implode(' และ ', $issues),
            'ให้ URL ที่เผยแพร่ชี้ตรงไปยังปลายทาง https สุดท้าย ทั้งใน sitemap, canonical และลิงก์ภายใน',
            $details
        );
    }
}
