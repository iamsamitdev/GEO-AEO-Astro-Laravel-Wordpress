<?php

namespace App\Console\Commands;

use App\Audit\Ai\AnswerQualityJudge;
use App\Audit\AuditResult;
use App\Audit\AuditRunner;
use App\Audit\Category;
use App\Audit\PageReport;
use Illuminate\Console\Command;

/**
 * ตรวจหน้าเดียวจากบรรทัดคำสั่ง - ใช้ทดสอบ engine และผูกกับ CI ได้
 *
 * คืน exit code 1 เมื่อคะแนนต่ำกว่าเกณฑ์ที่ตั้ง เพื่อให้ใช้เป็นด่านก่อน deploy ได้
 */
class GeoAuditCommand extends Command
{
    protected $signature = 'geo:audit
        {url : URL ที่ต้องการตรวจ}
        {--ai : เปิดการประเมินคุณภาพคำตอบด้วย Claude (ต้องตั้ง ANTHROPIC_API_KEY)}
        {--min= : คะแนนต่ำสุดที่ยอมรับได้ ถ้าต่ำกว่านี้จะคืน exit code 1}
        {--json : แสดงผลเป็น JSON}';

    protected $description = 'ตรวจความพร้อม SEO/GEO/AEO ของหน้าเว็บหนึ่งหน้า';

    public function handle(): int
    {
        $url = (string) $this->argument('url');

        $runner = new AuditRunner(
            judge: $this->option('ai') ? AnswerQualityJudge::fromConfig() : null,
        );

        $this->line("กำลังตรวจ {$url} ...");
        $report = $runner->auditUrl($url);

        if ($report->failed()) {
            $this->error('ตรวจไม่สำเร็จ: ' . $report->error);

            return self::FAILURE;
        }

        if ($this->option('json')) {
            $this->line(json_encode($report->toArray(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        } else {
            $this->render($report);
        }

        $min = $this->option('min');
        if ($min !== null && $report->score() < (int) $min) {
            $this->error("คะแนน {$report->score()} ต่ำกว่าเกณฑ์ {$min}");

            return self::FAILURE;
        }

        return self::SUCCESS;
    }

    private function render(PageReport $report): void
    {
        $score = $report->score();

        $this->newLine();
        $this->line("  คะแนนรวม: <options=bold>{$score}</> / 100  (" . PageReport::grade($score) . ')');
        $this->line('  ประเภทหน้า: ' . $report->pageType->label());
        $this->newLine();

        foreach (Category::ordered() as $category) {
            $categoryScore = $report->categoryScore($category);
            $label = str_pad($category->label(), 24);
            $shown = $categoryScore === null ? '  - ' : str_pad((string) $categoryScore, 4, ' ', STR_PAD_LEFT);
            $this->line("  {$label} {$shown}   (น้ำหนัก " . (int) $category->weight() . ')');
        }

        $this->newLine();
        $this->line('  <options=bold>สิ่งที่ควรแก้ก่อน</>');

        foreach ($report->opportunities() as $result) {
            $icon = $result->verdict() === 'fail' ? '✗' : '!';
            $this->line("  {$icon} {$result->title}");
            if ($result->displayValue !== '') {
                $this->line("      {$result->displayValue}");
            }
            if ($result->fix !== '') {
                $this->line("      แก้: {$result->fix}");
            }
        }

        $this->newLine();
        $this->line('  ผ่าน ' . $report->countVerdict('pass')
            . ' · ต้องดู ' . $report->countVerdict('average')
            . ' · ตก ' . $report->countVerdict('fail')
            . ' · ไม่เกี่ยวข้อง ' . $report->countVerdict('na'));
        $this->newLine();
    }

}
