<?php

return [
    /*
     * ยอมให้ตรวจเว็บที่รันอยู่ในเครื่องหรือในวงแลนได้ (localhost, 127.0.0.1, 192.168.x.x)
     *
     * เปิดเฉพาะตอนพัฒนาในเครื่อง เพื่อตรวจ dev server ของตัวเอง เช่น Astro ที่ localhost:4321
     *
     * ห้ามเปิดบนเซิร์ฟเวอร์ที่คนอื่นเข้าถึงได้เด็ดขาด เพราะใครก็ตามที่ใช้เว็บได้
     * จะสั่งให้เซิร์ฟเวอร์ยิงเข้าเครือข่ายภายในแทนตัวเองได้ (SSRF) เช่นเรียก
     * 169.254.169.254 เพื่อดึง credential ของเครื่อง หรือสแกนเครื่องอื่นในวงเดียวกัน
     */
    'allow_private_hosts' => (bool) env('GEO_AUDIT_ALLOW_PRIVATE_HOSTS', false),

    /*
     * ชื่อที่เครื่องมือใช้แนะนำตัวเวลาไปดึงหน้าเว็บของคนอื่น
     *
     * ควรใส่ช่องทางติดต่อไว้ด้วย เจ้าของเว็บที่เห็นในล็อกจะได้รู้ว่าใครเข้ามาและถามได้
     * เช่น GeoAuditBot/1.0 (+https://example.com/about-our-bot; GEO/AEO readiness checker)
     *
     * ห้ามแก้เป็นชื่อบอทของเจ้าอื่น เช่น GPTBot หรือ ClaudeBot เพราะเป็นการแอบอ้าง
     * เครื่องมือนี้ตรวจกฎใน robots.txt ที่มีต่อบอทเหล่านั้นให้อยู่แล้ว ไม่ต้องปลอมตัว
     */
    'user_agent' => env('GEO_AUDIT_USER_AGENT'),

    // เปิดชั้นตรวจด้วย Claude ได้ด้วยการใส่คีย์ ถ้าไม่ใส่ audit ข้อนั้นจะเป็น N/A
    'anthropic_key' => env('ANTHROPIC_API_KEY'),
    'anthropic_model' => env('GEO_AUDIT_MODEL', 'claude-opus-5'),

    // จำนวนหน้าสูงสุดต่อการตรวจทั้งเว็บหนึ่งครั้ง
    'crawl_limit' => (int) env('GEO_AUDIT_CRAWL_LIMIT', 25),

    // หน่วงระหว่างหน้า (มิลลิวินาที) เพื่อไม่ให้ยิงเว็บปลายทางถี่เกินไป
    'crawl_delay_ms' => (int) env('GEO_AUDIT_CRAWL_DELAY_MS', 400),

    // จำนวนการตรวจต่อ IP ต่อชั่วโมง กันไม่ให้เครื่องมือถูกใช้เป็นตัวยิงเว็บคนอื่น
    'rate_limit_per_hour' => (int) env('GEO_AUDIT_RATE_LIMIT', 20),

    // เก็บรายงานไว้กี่วันก่อนลบ
    'retention_days' => (int) env('GEO_AUDIT_RETENTION_DAYS', 30),

    /*
     * เขตเวลาที่ใช้ "แสดงผล" ให้ผู้ใช้เห็น
     *
     * จงใจแยกจาก app.timezone ซึ่งคงไว้ที่ UTC สำหรับการเก็บลงฐานข้อมูล
     * ถ้าเปลี่ยน app.timezone เป็น Asia/Bangkok ตรง ๆ รายงานที่บันทึกไว้ก่อนหน้า
     * (เก็บเป็น UTC แบบไม่มีข้อมูลเขตเวลาติดมา) จะถูกตีความผิดเพี้ยนไป 7 ชั่วโมง
     *
     * หมายเหตุ: config/app.php ของ Laravel 13 ฝัง 'timezone' => 'UTC' ไว้ตรง ๆ
     * ไม่ได้อ่าน APP_TIMEZONE จาก .env การใส่ APP_TIMEZONE จึงไม่มีผลอะไรเลย
     */
    'display_timezone' => env('GEO_AUDIT_DISPLAY_TIMEZONE', 'Asia/Bangkok'),

    // ขนาดไฟล์ zip ของ dist/ ที่ยอมรับ (KB)
    'max_upload_kb' => (int) env('GEO_AUDIT_MAX_UPLOAD_KB', 20480),
];
