<?php

namespace App\Audit\Http;

use RuntimeException;

/**
 * กันไม่ให้เครื่องมือถูกใช้ยิงเข้าเครือข่ายภายใน (SSRF)
 *
 * ผู้ใช้พิมพ์ URL อะไรก็ได้ ถ้าไม่กัน จะกลายเป็น proxy ให้คนนอกสแกน
 * 127.0.0.1, 10.x, 169.254.169.254 (cloud metadata) ผ่านเซิร์ฟเวอร์เรา
 */
final class UrlGuard
{
    public function __construct(private readonly bool $allowPrivate = false) {}

    /** คืน URL ที่ normalize แล้ว หรือโยน RuntimeException พร้อมเหตุผลที่แสดงผู้ใช้ได้ */
    public function validate(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            throw new RuntimeException('กรุณาใส่ URL');
        }

        if (! preg_match('~^https?://~i', $url)) {
            $url = 'https://'.ltrim($url, '/');
        }

        $parts = parse_url($url);
        if ($parts === false || empty($parts['host'])) {
            throw new RuntimeException('URL ไม่ถูกต้อง');
        }

        $scheme = strtolower($parts['scheme'] ?? '');
        if (! in_array($scheme, ['http', 'https'], true)) {
            throw new RuntimeException("รองรับเฉพาะ http/https (ได้รับ {$scheme})");
        }

        /*
         * จำกัดพอร์ตเฉพาะตอนใช้งานปกติ เพื่อไม่ให้เครื่องมือถูกใช้ไล่สแกนพอร์ตของเว็บคนอื่น
         *
         * ในโหมดพัฒนาในเครื่อง (allowPrivate) ไม่จำกัด เพราะ dev server ของแต่ละคน
         * ใช้พอร์ตต่างกันไปหมด การบังคับรายการตายตัวทำให้ตรวจเว็บตัวเองไม่ได้โดยไม่มีทางแก้
         */
        $allowedPorts = [80, 443, 3000, 4321, 5173, 8000, 8080, 8443];

        if (! $this->allowPrivate && isset($parts['port']) && ! in_array((int) $parts['port'], $allowedPorts, true)) {
            throw new RuntimeException(
                'พอร์ตนี้ไม่ได้รับอนุญาต (อนุญาตเฉพาะ ' . implode(', ', $allowedPorts) . ')'
            );
        }

        $this->assertPublicHost($parts['host']);

        return $url;
    }

    public function assertPublicHost(string $host): void
    {
        if ($this->allowPrivate) {
            return;
        }

        $host = strtolower(trim($host, '[]'));

        if ($host === 'localhost' || str_ends_with($host, '.localhost') || str_ends_with($host, '.internal') || str_ends_with($host, '.local')) {
            throw new RuntimeException('ไม่อนุญาตให้ตรวจ host ภายในเครือข่าย');
        }

        foreach ($this->resolve($host) as $ip) {
            if (! filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                throw new RuntimeException("โฮสต์ {$host} ชี้ไปที่ IP ภายใน ({$ip}) จึงไม่อนุญาต");
            }
        }
    }

    /** @return list<string> */
    private function resolve(string $host): array
    {
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return [$host];
        }

        $ips = [];
        foreach (['A' => DNS_A, 'AAAA' => DNS_AAAA] as $type => $flag) {
            $records = @dns_get_record($host, $flag) ?: [];
            foreach ($records as $r) {
                $ip = $r['ip'] ?? $r['ipv6'] ?? null;
                if (is_string($ip)) {
                    $ips[] = $ip;
                }
            }
        }

        if ($ips === []) {
            throw new RuntimeException("แปลงชื่อโฮสต์ {$host} เป็น IP ไม่ได้ (DNS ไม่ตอบ)");
        }

        return $ips;
    }
}
