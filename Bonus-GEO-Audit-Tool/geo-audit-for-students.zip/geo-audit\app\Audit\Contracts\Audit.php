<?php

namespace App\Audit\Contracts;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\Category;

interface Audit
{
    public function id(): string;

    public function title(): string;

    public function category(): Category;

    /** น้ำหนักภายในหมวด (relative) ไม่ใช่คะแนนเต็ม - runner จะ normalize ให้เอง */
    public function weight(): float;

    public function run(AuditContext $ctx): AuditResult;
}
