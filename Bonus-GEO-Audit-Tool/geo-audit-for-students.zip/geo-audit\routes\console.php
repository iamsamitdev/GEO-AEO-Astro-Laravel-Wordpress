<?php

use Illuminate\Support\Facades\Schedule;

/*
 * ลบรายงานเก่าวันละครั้ง
 *
 * ต้องมี cron เรียก `artisan schedule:run` ทุกนาทีจึงจะทำงาน
 * ถ้าไม่ได้ตั้ง cron นั้น ให้เรียก `artisan geo:prune` ตรง ๆ แทน (ดู deploy/README.md)
 */
Schedule::command('geo:prune')->dailyAt('03:30');
