<?php

namespace App\Audit\Audits\StructuredData;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;

/**
 * schema ในหน้าเชื่อมกันเป็นกราฟเดียว หรือเป็นก้อนที่ลอยแยกกัน
 *
 * นี่คือความต่างระหว่าง "มี schema" กับ "มี knowledge graph"
 * ถ้า Article.author เป็นแค่ string "สามิตร โกยม" ระบบไม่รู้ว่าคนนี้
 * คือคนเดียวกับที่เขียนอีก 40 บทความหรือเปล่า แต่ถ้าเป็น {"@id": "https://.../authors/samit#person"}
 * ทุกบทความจะรวมเป็นตัวตนเดียวกัน ซึ่งคือกลไกที่สร้าง E-E-A-T ระดับเอนทิตี
 */
final class EntityGraphAudit extends BaseAudit
{
    public function id(): string
    {
        return 'entity-graph';
    }

    public function title(): string
    {
        return 'เอนทิตีเชื่อมกันด้วย @id ไม่ใช่ก้อนลอย';
    }

    public function category(): Category
    {
        return Category::StructuredData;
    }

    public function weight(): float
    {
        return 1.5;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $jsonLd = $ctx->jsonLd();

        if ($jsonLd->isEmpty() || count($jsonLd->nodes) < 2) {
            return $this->na('มี schema น้อยเกินกว่าจะพูดถึงการเชื่อมโยง');
        }

        $declared = $jsonLd->declaredIds();
        $referenced = $jsonLd->referencedIds();
        $nodeCount = count($jsonLd->nodes);

        $dangling = array_values(array_diff($referenced, $declared));
        $relative = array_values(array_filter($declared, fn ($id) => ! preg_match('~^https?://~i', $id)));

        $details = [
            "node ทั้งหมด: {$nodeCount}",
            'ประกาศ @id: ' . (count($declared) ?: 0) . ' รายการ',
            'อ้างถึง @id: ' . (count($referenced) ?: 0) . ' ครั้ง',
        ];

        if ($declared === []) {
            return $this->partial(
                0.35,
                'ไม่มี @id เลย - schema แต่ละก้อนลอยแยกจากกัน',
                'ตั้ง @id ถาวรให้เอนทิตีที่ใช้ซ้ำทั้งเว็บ (Organization, Person, WebSite) เช่น https://example.com/#organization แล้วให้หน้าอื่นอ้างถึงด้วย {"@id": "..."} แทนการทำซ้ำทั้งก้อน',
                $details
            );
        }

        $score = 1.0;
        $issues = [];

        if ($relative !== []) {
            $score -= 0.3;
            $issues[] = '@id ที่ไม่ใช่ URL เต็ม: ' . implode(', ', array_slice($relative, 0, 3));
        }

        if ($dangling !== []) {
            $score -= 0.35;
            $issues[] = 'อ้างถึง @id ที่ไม่มีใครประกาศ: ' . implode(', ', array_slice($dangling, 0, 3));
            $details[] = 'หมายเหตุ: การอ้าง @id ข้ามหน้าเป็นเรื่องปกติ ถ้า @id นั้นถูกประกาศไว้ในหน้าอื่นของเว็บ ข้อนี้จะเตือนเกินจริง';
        }

        if ($referenced === []) {
            $score -= 0.25;
            $issues[] = 'ประกาศ @id ไว้แต่ไม่มี node ไหนอ้างถึงเลย';
        }

        if ($issues === []) {
            return $this->pass('เชื่อมกันครบ ' . count($referenced) . ' การอ้างอิง', $details);
        }

        return $this->partial(
            max(0.0, $score),
            $issues[0],
            'ใช้ @id เป็น URL เต็มพร้อม fragment ที่คงที่ตลอดอายุเว็บ แล้วอ้างถึงจากที่อื่นแทนการคัดลอกข้อมูลซ้ำ - แก้ที่เดียวจะมีผลทั้งเว็บ',
            array_merge($details, $issues)
        );
    }
}
