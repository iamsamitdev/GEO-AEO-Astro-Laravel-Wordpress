<?php

namespace App\Audit;

use App\Audit\Ai\AnswerQualityJudge;
use App\Audit\Audits;
use App\Audit\Content\PageType;
use App\Audit\Contracts\Audit;
use App\Audit\Http\FetchedResponse;
use App\Audit\Http\Fetcher;
use Throwable;

/**
 * ประกอบ audit ทั้งหมดแล้วรันกับหน้าหนึ่งหน้า
 *
 * audit ทุกตัวถูกห่อด้วย try/catch เพราะเว็บจริงมี HTML ที่พังได้ทุกรูปแบบ
 * audit ตัวเดียวที่ระเบิดต้องไม่ทำให้ทั้งรายงานล้ม แต่ต้องเห็นว่าตัวไหนพัง
 */
final class AuditRunner
{
    /** @var list<Audit>|null */
    private ?array $audits = null;

    public function __construct(
        private readonly Fetcher $fetcher = new Fetcher,
        private readonly ?AnswerQualityJudge $judge = null,
    ) {}

    /** @return list<Audit> */
    public function audits(): array
    {
        if ($this->audits !== null) {
            return $this->audits;
        }

        $audits = [
            new Audits\Crawlability\RobotsAllowsAiAudit,
            new Audits\Crawlability\NoJsDependencyAudit,
            new Audits\Crawlability\HttpStatusAudit,
            new Audits\Crawlability\MetaRobotsAudit,
            new Audits\Crawlability\CanonicalAudit,
            new Audits\Crawlability\SitemapAudit,
            new Audits\Crawlability\ResponseSpeedAudit,

            new Audits\StructuredData\JsonLdPresentAudit,
            new Audits\StructuredData\ExpectedTypesAudit,
            new Audits\StructuredData\RequiredPropertiesAudit,
            new Audits\StructuredData\IsoDatesAudit,
            new Audits\StructuredData\EntityGraphAudit,
            new Audits\StructuredData\SchemaMatchesContentAudit,

            new Audits\Aeo\AnswerFirstAudit,
            new Audits\Aeo\ChunkabilityAudit,
            new Audits\Aeo\DefinitionUpFrontAudit,
            new Audits\Aeo\QuestionHeadingsAudit,
            new Audits\Aeo\ExtractableFactsAudit,
            new Audits\Aeo\SelfContainedSectionsAudit,

            new Audits\Seo\TitleAudit,
            new Audits\Seo\MetaDescriptionAudit,
            new Audits\Seo\HeadingStructureAudit,
            new Audits\Seo\ImageAltAudit,
            new Audits\Seo\InternalLinksAudit,
            new Audits\Seo\SocialAndLanguageAudit,

            new Audits\Eeat\AuthorshipAudit,
            new Audits\Eeat\FreshnessAudit,
            new Audits\Eeat\OrganizationTrustAudit,

            new Audits\AiFiles\LlmsTxtAudit,
        ];

        if ($this->judge !== null && $this->judge->enabled()) {
            $audits[] = new Audits\Aeo\AiAnswerQualityAudit($this->judge);
        }

        return $this->audits = $audits;
    }

    /** ตรวจหน้าเดียวจาก URL - ดึง robots/sitemap/llms.txt ให้เอง */
    public function auditUrl(string $url): PageReport
    {
        $response = $this->fetcher->get($url);

        if (! $response->ok()) {
            return PageReport::unreachable(
                $url,
                $response->error ?? "เซิร์ฟเวอร์ตอบ {$response->status}"
            );
        }

        if (! str_contains($response->contentType(), 'html')) {
            return PageReport::unreachable(
                $url,
                'URL นี้ไม่ใช่หน้า HTML (Content-Type: ' . ($response->contentType() ?: 'ไม่ระบุ') . ')'
            );
        }

        return $this->auditResponse($url, $response, SiteContext::forUrl($url, $this->fetcher));
    }

    /** ตรวจหน้าเดียวโดยใช้ SiteContext ที่ดึงไว้แล้ว - ใช้ตอน crawl ทั้งเว็บ */
    public function auditWithSite(string $url, SiteContext $site): PageReport
    {
        $response = $this->fetcher->get($url);

        if (! $response->ok()) {
            return PageReport::unreachable($url, $response->error ?? "เซิร์ฟเวอร์ตอบ {$response->status}");
        }

        if (! str_contains($response->contentType(), 'html')) {
            return PageReport::unreachable($url, 'ไม่ใช่หน้า HTML');
        }

        return $this->auditResponse($url, $response, $site);
    }

    /**
     * ตรวจ HTML ที่มีอยู่แล้ว เช่นไฟล์จาก dist/ หรือไฟล์ .html ที่ผู้ใช้อัปโหลดมา
     *
     * @param  bool  $syntheticBase  โดเมนใน $url เป็นค่าสมมติเพราะผู้ใช้ไม่ได้บอกโดเมนจริง
     * @param  PageType|null  $forcedPageType  ประเภทหน้าที่ผู้ใช้ระบุ - null คือให้ระบบเดาเอง
     */
    public function auditHtml(
        string $url,
        string $html,
        bool $syntheticBase = false,
        ?PageType $forcedPageType = null,
    ): PageReport {
        $response = new FetchedResponse(
            requestedUrl: $url,
            finalUrl: $url,
            status: 200,
            headers: ['Content-Type' => ['text/html']],
            body: $html,
            elapsedMs: 0.0,
        );

        return $this->auditResponse(
            $url,
            $response,
            SiteContext::offline(),
            offline: true,
            syntheticBase: $syntheticBase,
            forcedPageType: $forcedPageType,
        );
    }

    private function auditResponse(
        string $url,
        FetchedResponse $response,
        SiteContext $site,
        bool $offline = false,
        bool $syntheticBase = false,
        ?PageType $forcedPageType = null,
    ): PageReport {
        $ctx = AuditContext::make($url, $response, $site, $offline, $syntheticBase, $forcedPageType);

        $results = [];
        foreach ($this->audits() as $audit) {
            try {
                $results[] = $audit->run($ctx);
            } catch (Throwable $e) {
                report($e);
                $results[] = new AuditResult(
                    id: $audit->id(),
                    title: $audit->title(),
                    category: $audit->category(),
                    weight: $audit->weight(),
                    score: null,
                    displayValue: 'ตรวจข้อนี้ไม่สำเร็จ',
                    details: ['ข้อผิดพลาดภายใน: ' . $e->getMessage()],
                );
            }
        }

        return new PageReport(
            url: $ctx->url,
            pageType: $ctx->pageType,
            pageTypeDeclared: $ctx->pageTypeDeclared,
            results: $results,
            httpStatus: $response->status,
            loadMs: $response->elapsedMs,
            bytes: $response->bytes(),
        );
    }
}
