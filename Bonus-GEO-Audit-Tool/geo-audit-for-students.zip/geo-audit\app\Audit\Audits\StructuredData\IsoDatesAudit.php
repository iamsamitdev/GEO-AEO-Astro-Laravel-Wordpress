<?php

namespace App\Audit\Audits\StructuredData;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use DateTimeImmutable;
use Throwable;

/**
 * วันที่ใน schema เป็น ISO 8601 และสมเหตุสมผล
 *
 * ความสดของเนื้อหาเป็นสัญญาณที่ระบบ AI Search ใช้หนักมากในการเลือกว่าจะอ้างใคร
 * แต่ค่าที่ผิดรูปแบบจะถูกทิ้งเงียบ ๆ เท่ากับหน้าไม่มีวันที่เลย
 *
 * ที่ต้องระวังเป็นพิเศษคือวันที่แบบไทย (พ.ศ.) ที่หลุดเข้ามาใน schema
 * เช่น 2568-09-08 ซึ่งอ่านได้ตามไวยากรณ์ แต่แปลว่าอีก 543 ปีข้างหน้า
 */
final class IsoDatesAudit extends BaseAudit
{
    public function id(): string
    {
        return 'iso-dates';
    }

    public function title(): string
    {
        return 'วันที่ใน schema เป็น ISO 8601 และสมเหตุสมผล';
    }

    public function category(): Category
    {
        return Category::StructuredData;
    }

    public function weight(): float
    {
        return 2.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $jsonLd = $ctx->jsonLd();
        $dates = $jsonLd->dateValues();

        if ($dates === []) {
            $needsDate = in_array($ctx->pageType->value, ['article'], true);

            return $needsDate
                ? $this->fail(
                    'หน้าบทความแต่ไม่มี datePublished / dateModified',
                    'ใส่ datePublished และ dateModified แบบ ISO 8601 พร้อม timezone เช่น 2026-09-08T14:30:00+07:00',
                    []
                )
                : $this->na('หน้าประเภทนี้ไม่จำเป็นต้องมีวันที่ใน schema');
        }

        $problems = [];
        $details = [];
        $parsed = [];

        foreach ($dates as [$property, $value]) {
            $value = is_string($value) ? trim($value) : '';
            $details[] = "{$property}: " . ($value === '' ? '(ว่าง)' : $value);

            if ($value === '') {
                $problems[] = "{$property} ว่างเปล่า";

                continue;
            }

            if (! preg_match('/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})?)?$/', $value)) {
                $problems[] = "{$property} ไม่ใช่รูปแบบ ISO 8601 ({$value})";

                continue;
            }

            $year = (int) substr($value, 0, 4);
            if ($year > 2100) {
                $problems[] = "{$property} เป็นปี {$year} - น่าจะเป็น พ.ศ. ที่ยังไม่ได้แปลงเป็น ค.ศ.";

                continue;
            }

            try {
                $date = new DateTimeImmutable($value);
            } catch (Throwable) {
                $problems[] = "{$property} แปลงเป็นวันที่ไม่ได้ ({$value})";

                continue;
            }

            if ($date > new DateTimeImmutable('+2 days')) {
                $problems[] = "{$property} เป็นวันที่ในอนาคต ({$value})";
            }

            if (! str_contains($value, 'T')) {
                $problems[] = "{$property} ไม่มีเวลาและ timezone - ควรใส่ให้ครบเพื่อให้เรียงลำดับความสดได้แม่นยำ";
            }

            $parsed[$property] = $date;
        }

        if (isset($parsed['datePublished'], $parsed['dateModified'])
            && $parsed['dateModified'] < $parsed['datePublished']) {
            $problems[] = 'dateModified อยู่ก่อน datePublished';
        }

        if ($problems === []) {
            return $this->pass(count($dates) . ' ค่า ถูกต้องทั้งหมด', $details);
        }

        $serious = array_filter($problems, fn ($p) => ! str_contains($p, 'ไม่มีเวลาและ timezone'));
        $score = $serious === []
            ? 0.85
            : max(0.0, 1.0 - count($serious) * 0.4);

        return $this->partial(
            $score,
            $problems[0],
            'ให้เทมเพลตแปลงวันที่ด้วยฟังก์ชันเดียว (เช่น toISOString / Carbon::toIso8601String) เสมอ อย่าประกอบสตริงวันที่เอง และแปลง พ.ศ. เป็น ค.ศ. ก่อนใส่ schema',
            array_merge($details, array_map(fn ($p) => 'พบปัญหา: ' . $p, $problems))
        );
    }
}
