<?php

namespace App\Audit\Audits\Eeat;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\JsonLd;
use DateTimeImmutable;
use Throwable;

/**
 * หน้านี้บอกไหมว่าแก้ล่าสุดเมื่อไร และคนอ่านเห็นด้วยหรือเปล่า
 *
 * ระบบที่ตอบคำถามเรื่องที่เปลี่ยนเร็ว (ราคา เวอร์ชัน กฎระเบียบ) ให้น้ำหนักความสดมาก
 * และวันที่ที่คนเห็นบนหน้า มีน้ำหนักกว่าวันที่ที่ซ่อนอยู่ใน schema อย่างเดียว
 * เพราะยืนยันซึ่งกันและกันได้
 */
final class FreshnessAudit extends BaseAudit
{
    public function id(): string
    {
        return 'freshness';
    }

    public function title(): string
    {
        return 'แสดงวันที่แก้ไขล่าสุดอย่างชัดเจน';
    }

    public function category(): Category
    {
        return Category::Eeat;
    }

    public function weight(): float
    {
        return 2.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $timeVisible = $ctx->document->has('//time[@datetime]');
        $jsonLd = $ctx->jsonLd();

        $modified = null;
        $published = null;

        foreach ($jsonLd->nodes as $node) {
            $modified ??= JsonLd::scalar($node, 'dateModified');
            $published ??= JsonLd::scalar($node, 'datePublished');
        }

        $needsDate = in_array($ctx->pageType->value, ['article', 'service', 'product'], true);

        $details = [
            'dateModified ใน schema: ' . ($modified ?? 'ไม่มี'),
            'datePublished ใน schema: ' . ($published ?? 'ไม่มี'),
            'แสดง <time datetime> บนหน้า: ' . ($timeVisible ? 'ใช่' : 'ไม่'),
        ];

        if ($modified === null && $published === null && ! $timeVisible) {
            return $needsDate
                ? $this->fail(
                    'ไม่มีวันที่ทั้งบนหน้าและใน schema',
                    'แสดงวันที่แก้ไขล่าสุดให้คนอ่านเห็นด้วย <time datetime="..."> และใส่ dateModified ใน schema จากค่าเดียวกัน โดยดึงจากเวลาที่แก้เนื้อหาจริง',
                    $details
                )
                : $this->na('หน้าประเภทนี้ไม่จำเป็นต้องแสดงวันที่');
        }

        $score = 1.0;
        $issues = [];

        if ($modified === null) {
            $score -= 0.3;
            $issues[] = 'ไม่มี dateModified';
        }

        if (! $timeVisible) {
            $score -= 0.25;
            $issues[] = 'ไม่แสดงวันที่ให้คนอ่านเห็น';
        }

        $age = $this->ageInDays($modified ?? $published);
        if ($age !== null) {
            $details[] = "อายุนับจากวันที่ล่าสุด: {$age} วัน";

            if ($age > 730) {
                $score -= 0.35;
                $issues[] = 'ไม่ได้อัปเดตมาเกิน 2 ปี';
            } elseif ($age > 365) {
                $score -= 0.15;
                $issues[] = 'ไม่ได้อัปเดตมาเกิน 1 ปี';
            }
        }

        if ($issues === []) {
            return $this->pass('วันที่ครบและแสดงบนหน้า', $details);
        }

        return $this->partial(
            max(0.0, $score),
            implode(' · ', $issues),
            'ผูก dateModified กับคอลัมน์ updated_at จริง แล้วเรนเดอร์ค่าเดียวกันทั้งใน schema และใน <time> บนหน้า - อย่าอัปเดตวันที่โดยไม่ได้แก้เนื้อหา เพราะจะเสียความน่าเชื่อถือเมื่อถูกตรวจสอบ',
            $details
        );
    }

    private function ageInDays(?string $date): ?int
    {
        if ($date === null || trim($date) === '') {
            return null;
        }

        try {
            $parsed = new DateTimeImmutable($date);
        } catch (Throwable) {
            return null;
        }

        $days = (new DateTimeImmutable)->diff($parsed)->days;

        return $days === false ? null : (int) $days;
    }
}
