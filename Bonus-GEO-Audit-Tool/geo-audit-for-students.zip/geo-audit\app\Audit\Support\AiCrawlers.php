<?php

namespace App\Audit\Support;

/**
 * รายชื่อบอทที่เกี่ยวกับ AI Search และ "ความสำคัญต่อการถูกอ้างอิง"
 *
 * แยกให้ชัดระหว่างสองกลุ่ม เพราะการบล็อกคนละกลุ่มมีผลไม่เท่ากันเลย:
 *
 *  retrieval - บอทที่วิ่งตอนผู้ใช้ถามคำถาม เพื่อไปหยิบหน้ามาตอบและใส่ลิงก์อ้างอิง
 *              บล็อกกลุ่มนี้ = เว็บคุณจะไม่ถูกอ้างอิงเลย ต่อให้เนื้อหาดีแค่ไหน
 *
 *  training  - บอทที่เก็บข้อมูลไปเทรนโมเดล ไม่เกี่ยวกับการอ้างอิงรายครั้ง
 *              บล็อกกลุ่มนี้เป็นการตัดสินใจเชิงนโยบาย/ลิขสิทธิ์ ไม่ใช่ข้อผิดพลาด
 */
final class AiCrawlers
{
    public const RETRIEVAL = 'retrieval';

    public const TRAINING = 'training';

    /**
     * @return list<array{agent:string, vendor:string, kind:string, note:string}>
     */
    public static function all(): array
    {
        return [
            ['agent' => 'OAI-SearchBot',      'vendor' => 'OpenAI',     'kind' => self::RETRIEVAL, 'note' => 'สร้างดัชนีให้ ChatGPT Search - ปิดตัวนี้ = ไม่มีวันถูก ChatGPT อ้างอิง'],
            ['agent' => 'ChatGPT-User',       'vendor' => 'OpenAI',     'kind' => self::RETRIEVAL, 'note' => 'วิ่งเมื่อผู้ใช้ ChatGPT เปิดลิงก์หรือสั่งให้อ่านหน้านี้'],
            ['agent' => 'PerplexityBot',      'vendor' => 'Perplexity', 'kind' => self::RETRIEVAL, 'note' => 'ดัชนีของ Perplexity ที่ใช้อ้างอิงในคำตอบ'],
            ['agent' => 'Perplexity-User',    'vendor' => 'Perplexity', 'kind' => self::RETRIEVAL, 'note' => 'วิ่งตามคำถามของผู้ใช้แบบเรียลไทม์'],
            ['agent' => 'Claude-SearchBot',   'vendor' => 'Anthropic',  'kind' => self::RETRIEVAL, 'note' => 'ดัชนีค้นหาของ Claude'],
            ['agent' => 'Claude-User',        'vendor' => 'Anthropic',  'kind' => self::RETRIEVAL, 'note' => 'วิ่งเมื่อผู้ใช้ Claude ขอให้อ่านหน้านี้'],
            ['agent' => 'Googlebot',          'vendor' => 'Google',     'kind' => self::RETRIEVAL, 'note' => 'เป็นฐานของ AI Overviews และ AI Mode ด้วย ไม่ใช่แค่ผลค้นหาปกติ'],
            ['agent' => 'Bingbot',            'vendor' => 'Microsoft',  'kind' => self::RETRIEVAL, 'note' => 'เป็นฐานของ Copilot'],
            ['agent' => 'DuckAssistBot',      'vendor' => 'DuckDuckGo', 'kind' => self::RETRIEVAL, 'note' => 'ใช้ตอบใน DuckDuckGo AI'],
            ['agent' => 'Applebot',           'vendor' => 'Apple',      'kind' => self::RETRIEVAL, 'note' => 'Siri และ Spotlight'],

            ['agent' => 'GPTBot',             'vendor' => 'OpenAI',     'kind' => self::TRAINING,  'note' => 'เก็บข้อมูลไปเทรนโมเดล'],
            ['agent' => 'ClaudeBot',          'vendor' => 'Anthropic',  'kind' => self::TRAINING,  'note' => 'เก็บข้อมูลไปเทรนโมเดล'],
            ['agent' => 'Google-Extended',    'vendor' => 'Google',     'kind' => self::TRAINING,  'note' => 'คุมเฉพาะการใช้เทรน Gemini ไม่กระทบการจัดอันดับ'],
            ['agent' => 'Applebot-Extended',  'vendor' => 'Apple',      'kind' => self::TRAINING,  'note' => 'คุมเฉพาะการใช้เทรน Apple Intelligence'],
            ['agent' => 'CCBot',              'vendor' => 'Common Crawl', 'kind' => self::TRAINING, 'note' => 'ชุดข้อมูลสาธารณะที่โมเดลจำนวนมากใช้'],
            ['agent' => 'Meta-ExternalAgent', 'vendor' => 'Meta',       'kind' => self::TRAINING,  'note' => 'เก็บข้อมูลให้ Llama'],
            ['agent' => 'Amazonbot',          'vendor' => 'Amazon',     'kind' => self::TRAINING,  'note' => 'Alexa และโมเดลของ Amazon'],
            ['agent' => 'Bytespider',         'vendor' => 'ByteDance',  'kind' => self::TRAINING,  'note' => 'เก็บข้อมูลให้โมเดลของ ByteDance'],
        ];
    }

    /** @return list<array{agent:string, vendor:string, kind:string, note:string}> */
    public static function retrieval(): array
    {
        return array_values(array_filter(self::all(), fn ($c) => $c['kind'] === self::RETRIEVAL));
    }

    /** @return list<array{agent:string, vendor:string, kind:string, note:string}> */
    public static function training(): array
    {
        return array_values(array_filter(self::all(), fn ($c) => $c['kind'] === self::TRAINING));
    }
}
