<?php

namespace App\Audit\Audits\Crawlability;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\AiCrawlers;

/**
 * บอทที่ต้องวิ่งมาอ่านหน้านี้ตอนมีคนถาม เข้ามาได้จริงหรือเปล่า
 *
 * นี่คือ audit ที่สำคัญที่สุดในเครื่องมือนี้ ถ้าตกข้อนี้ข้อเดียว
 * งานที่เหลือทั้งหมด (schema สวย เนื้อหาดี) ไม่มีผลเลย เพราะไม่มีใครมาอ่าน
 *
 * แยกน้ำหนักสองกลุ่ม: บล็อก retrieval bot = ผิดพลาด, บล็อก training bot = การตัดสินใจ
 */
final class RobotsAllowsAiAudit extends BaseAudit
{
    public function id(): string
    {
        return 'robots-allows-ai';
    }

    public function title(): string
    {
        return 'robots.txt เปิดให้บอทที่ใช้อ้างอิงเข้าถึงได้';
    }

    public function category(): Category
    {
        return Category::Crawlability;
    }

    public function weight(): float
    {
        return 3.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        if ($ctx->offline) {
            return $this->na('โหมดตรวจไฟล์ในเครื่อง ไม่มี robots.txt ให้ตรวจ');
        }

        $robots = $ctx->site->robots;
        $path = $ctx->path();

        if (! $robots->exists) {
            return $this->partial(
                0.85,
                'ไม่พบ robots.txt (ทุกบอทเข้าได้โดยปริยาย)',
                'ไม่มี robots.txt ไม่ได้ทำให้ถูกบล็อก แต่แปลว่าคุณไม่ได้ประกาศ Sitemap ไว้ที่นั่นด้วย และควบคุมบอทเทรนโมเดลไม่ได้ ควรสร้างไฟล์นี้ให้ชัดเจน',
                ['สถานะ HTTP ของ /robots.txt: ' . ($ctx->site->robots->exists ? 'พบ' : 'ไม่พบหรืออ่านไม่ได้')]
            );
        }

        $blockedRetrieval = [];
        $blockedTraining = [];
        $declared = [];

        foreach (AiCrawlers::all() as $crawler) {
            $agent = $crawler['agent'];
            $allowed = $robots->allows($agent, $path);

            if ($robots->knowsAgent(strtolower($agent))) {
                $declared[] = $agent;
            }

            if ($allowed) {
                continue;
            }

            if ($crawler['kind'] === AiCrawlers::RETRIEVAL) {
                $blockedRetrieval[] = $crawler;
            } else {
                $blockedTraining[] = $crawler;
            }
        }

        $details = [];
        $details[] = 'ตรวจกับ path: ' . $path;
        if ($declared !== []) {
            $details[] = 'robots.txt ระบุกฎเจาะจงให้: ' . implode(', ', $declared);
        }

        foreach ($blockedRetrieval as $crawler) {
            $details[] = "ถูกบล็อก (ใช้อ้างอิง): {$crawler['agent']} - {$crawler['note']}";
        }
        foreach ($blockedTraining as $crawler) {
            $details[] = "ถูกบล็อก (ใช้เทรนโมเดล): {$crawler['agent']} - {$crawler['note']}";
        }

        $retrievalTotal = count(AiCrawlers::retrieval());
        $retrievalOk = $retrievalTotal - count($blockedRetrieval);

        if ($blockedRetrieval !== []) {
            $names = implode(', ', array_column($blockedRetrieval, 'agent'));

            return $this->partial(
                // บล็อกแม้ตัวเดียวก็ลงโทษหนัก แล้วลดหลั่นตามจำนวนที่เหลือ
                max(0.0, ($retrievalOk / $retrievalTotal) - 0.35),
                "บล็อกบอทที่ใช้อ้างอิง {$names}",
                "เอา Disallow ที่ครอบ {$names} ออกจาก robots.txt หรือใส่ Allow เจาะจงให้กลุ่มนี้ ถ้าตั้งใจกันบอทเทรนโมเดล ให้ระบุเฉพาะ GPTBot / ClaudeBot / Google-Extended ซึ่งเป็นคนละตัวกัน",
                $details
            );
        }

        if ($blockedTraining !== []) {
            return $this->partial(
                0.95,
                'บอทที่ใช้อ้างอิงเข้าได้ครบ (บล็อกเฉพาะบอทเทรนโมเดล ' . count($blockedTraining) . ' ตัว)',
                'ไม่ต้องแก้ถ้าตั้งใจ - การกันบอทเทรนโมเดลเป็นการตัดสินใจเรื่องลิขสิทธิ์ ไม่กระทบการถูกอ้างอิง',
                $details
            );
        }

        return $this->pass('บอท AI เข้าถึงได้ครบทุกตัว', $details);
    }
}
