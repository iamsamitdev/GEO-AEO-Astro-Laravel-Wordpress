<?php

namespace App\Audit\Http;

final class FetchedResponse
{
    /**
     * @param  list<string>  $redirectChain
     * @param  array<string, list<string>>  $headers
     */
    public function __construct(
        public readonly string $requestedUrl,
        public readonly string $finalUrl,
        public readonly int $status,
        public readonly array $headers,
        public readonly string $body,
        public readonly float $elapsedMs,
        public readonly array $redirectChain = [],
        public readonly ?string $error = null,
        public readonly bool $truncated = false,
    ) {}

    public function ok(): bool
    {
        return $this->error === null && $this->status >= 200 && $this->status < 300;
    }

    public function header(string $name): ?string
    {
        foreach ($this->headers as $key => $values) {
            if (strcasecmp($key, $name) === 0) {
                return $values[0] ?? null;
            }
        }

        return null;
    }

    public function contentType(): string
    {
        return strtolower(trim(explode(';', $this->header('Content-Type') ?? '')[0]));
    }

    public function bytes(): int
    {
        return strlen($this->body);
    }

    public static function failed(string $url, string $error): self
    {
        return new self($url, $url, 0, [], '', 0.0, [], $error);
    }
}
