<?php

namespace Tests\Feature;

use App\Models\Report;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * พลุฉลองคะแนนเต็ม และเวอร์ชันของไฟล์ static
 *
 * พลุต้องขึ้นเฉพาะรายงานที่ตรวจเสร็จและได้ 100 จริงเท่านั้น
 * รายงานที่ได้ 99 หรือยังรอคิวอยู่ ห้ามโหลดสคริปต์พลุเด็ดขาด
 */
class CelebrationTest extends TestCase
{
    use RefreshDatabase;

    public function test_คะแนนเต็มโหลดสคริปต์พลุและมีปุ่มฉลองอีกครั้ง(): void
    {
        $html = $this->get(route('reports.show', $this->report('done', 100)))->assertOk()->getContent();

        $this->assertStringContainsString('data-celebrate', $html);
        $this->assertMatchesRegularExpression('#js/celebrate\.js\?v=[0-9a-f]{10}#', $html);
        $this->assertStringContainsString('data-celebrate-replay', $html);
    }

    /** @return array<string, array{string, ?int}> */
    public static function notPerfectCases(): array
    {
        return [
            'ได้ 99' => ['done', 99],
            'ยังรอคิว' => ['queued', null],
            'ตรวจไม่สำเร็จ' => ['failed', null],
        ];
    }

    #[\PHPUnit\Framework\Attributes\DataProvider('notPerfectCases')]
    public function test_ไม่ใช่คะแนนเต็มต้องไม่มีพลุ(string $status, ?int $score): void
    {
        $html = $this->get(route('reports.show', $this->report($status, $score)))->assertOk()->getContent();

        $this->assertStringNotContainsString('celebrate.js', $html);
        $this->assertStringNotContainsString('data-celebrate', $html);
    }

    public function test_css_มีเลขเวอร์ชันจากเนื้อหาไฟล์(): void
    {
        $html = $this->get(route('home'))->assertOk()->getContent();
        $expected = substr(md5_file(public_path('css/app.css')), 0, 10);

        // ไม่มีเวอร์ชัน = ผู้ใช้เก่าได้ CSS ค้างอยู่ 30 วันตาม mod_expires ของเว็บหลัก
        $this->assertStringContainsString('css/app.css?v=' . $expected, $html);
    }

    private function report(string $status, ?int $score): Report
    {
        return Report::create([
            'mode' => 'url',
            'target' => 'https://example.com/',
            'status' => $status,
            'score' => $score,
        ]);
    }
}
