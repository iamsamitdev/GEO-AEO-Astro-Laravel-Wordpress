<?php

namespace App\Audit\Audits\Aeo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Content\Section;
use App\Audit\Support\Text;

/**
 * เนื้อหาถูกตัดเป็นชิ้นขนาดพอดีสำหรับระบบ retrieval หรือยัง
 *
 * ระบบที่ไปหยิบหน้ามาตอบคำถามไม่ได้อ่านทั้งหน้า มันตัดเป็นชิ้น (chunk)
 * แล้วเลือกมาแค่ไม่กี่ชิ้น ชิ้นที่ยาวเกินจะถูกตัดกลางคัน ชิ้นที่สั้นเกินก็ไม่มีสาระพอ
 *
 * กำแพงข้อความยาว 900 คำใต้หัวข้อเดียว จึงแพ้เนื้อหาเดียวกันที่ซอยเป็น 6 หัวข้อ
 * ทั้งที่ข้อมูลเท่ากันเป๊ะ
 */
final class ChunkabilityAudit extends BaseAudit
{
    private const IDEAL_SECTION_MIN = 50;

    private const IDEAL_SECTION_MAX = 300;

    private const PARAGRAPH_MAX = 150;

    public function id(): string
    {
        return 'chunkability';
    }

    public function title(): string
    {
        return 'เนื้อหาแบ่งเป็นชิ้นขนาดพอดีให้ระบบหยิบไปใช้';
    }

    public function category(): Category
    {
        return Category::Aeo;
    }

    public function weight(): float
    {
        return 2.5;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $sections = array_values(array_filter(
            $ctx->document->sections(),
            fn (Section $s) => $s->heading !== null
        ));

        $totalWords = Text::wordCount($ctx->document->mainText());

        if ($totalWords < 80) {
            return $this->na('เนื้อหาน้อยเกินกว่าจะประเมินการแบ่งชิ้น');
        }

        if ($sections === []) {
            return $this->fail(
                "เนื้อหา {$totalWords} คำ ไม่มีหัวข้อย่อยเลย",
                'ซอยเนื้อหาด้วย h2/h3 ทุก 150-300 คำ โดยตั้งหัวข้อให้เป็นคำถามหรือประเด็นที่ชัดเจน - นี่คือเส้นที่ระบบ retrieval ใช้ตัดชิ้นเนื้อหา',
                []
            );
        }

        $tooLong = [];
        $tooShort = [];
        $lengths = [];

        foreach ($sections as $section) {
            $words = Text::wordCount($section->text());
            $lengths[] = $words;
            $title = Text::truncate($section->title(), 45);

            if ($words > self::IDEAL_SECTION_MAX * 2) {
                $tooLong[] = "{$title} ({$words} คำ)";
            } elseif ($words > 0 && $words < 15) {
                $tooShort[] = "{$title} ({$words} คำ)";
            }
        }

        $longParagraphs = 0;
        $paragraphCount = 0;
        foreach ($sections as $section) {
            foreach ($section->paragraphs as $paragraph) {
                $paragraphCount++;
                if (Text::wordCount($paragraph) > self::PARAGRAPH_MAX) {
                    $longParagraphs++;
                }
            }
        }

        $average = $lengths === [] ? 0 : (int) round(array_sum($lengths) / count($lengths));

        $details = [
            'จำนวนหัวข้อย่อย: ' . count($sections),
            "ความยาวเฉลี่ยต่อหัวข้อ: {$average} คำ (ช่วงที่เหมาะ " . self::IDEAL_SECTION_MIN . '-' . self::IDEAL_SECTION_MAX . ')',
            "ย่อหน้าที่ยาวเกิน " . self::PARAGRAPH_MAX . " คำ: {$longParagraphs} จาก {$paragraphCount}",
        ];

        foreach (array_slice($tooLong, 0, 4) as $item) {
            $details[] = 'หัวข้อยาวเกิน: ' . $item;
        }

        $score = 1.0;
        $issues = [];

        if ($tooLong !== []) {
            $score -= min(0.5, count($tooLong) / max(1, count($sections)) * 1.2);
            $issues[] = count($tooLong) . ' หัวข้อยาวเกินไป';
        }

        if ($longParagraphs > 0 && $paragraphCount > 0) {
            $score -= min(0.3, $longParagraphs / $paragraphCount);
            $issues[] = "{$longParagraphs} ย่อหน้ายาวเกิน";
        }

        if ($average > self::IDEAL_SECTION_MAX) {
            $score -= 0.2;
            $issues[] = "เฉลี่ยยาวกว่าช่วงที่เหมาะ";
        } elseif ($average > 0 && $average < 20) {
            $score -= 0.2;
            $issues[] = 'หัวข้อย่อยสั้นจนแทบไม่มีเนื้อหา';
        }

        if ($issues === []) {
            return $this->pass(count($sections) . " หัวข้อ · เฉลี่ย {$average} คำ", $details);
        }

        return $this->partial(
            max(0.0, $score),
            implode(' · ', $issues),
            'ตั้งเป้าให้แต่ละหัวข้อย่อยจบในตัวที่ ' . self::IDEAL_SECTION_MIN . '-' . self::IDEAL_SECTION_MAX . ' คำ และย่อหน้าไม่เกิน ' . self::PARAGRAPH_MAX . ' คำ ถ้าหัวข้อไหนยาวกว่านั้นให้ซอยเป็นหัวข้อย่อยหรือแปลงเป็นรายการ',
            $details
        );
    }
}
