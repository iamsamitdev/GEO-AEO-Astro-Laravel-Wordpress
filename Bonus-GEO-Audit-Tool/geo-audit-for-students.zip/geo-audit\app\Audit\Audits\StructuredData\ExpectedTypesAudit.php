<?php

namespace App\Audit\Audits\StructuredData;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Content\PageType;

/**
 * schema ที่มี ตรงกับประเภทของหน้าหรือเปล่า
 *
 * หน้าบทความที่ประกาศแค่ WebPage ไม่ผิดไวยากรณ์ แต่บอกอะไรไม่ได้เลย
 * ประเภทหน้าเดามาจาก URL และ og:type เท่านั้น (ไม่ได้เดาจาก schema)
 * เพื่อไม่ให้หน้าที่ไม่มี schema เลยรอดไปได้เพราะตรรกะวงกลม
 */
final class ExpectedTypesAudit extends BaseAudit
{
    public function id(): string
    {
        return 'expected-types';
    }

    public function title(): string
    {
        return 'ชนิด schema ตรงกับประเภทของหน้า';
    }

    public function category(): Category
    {
        return Category::StructuredData;
    }

    public function weight(): float
    {
        return 3.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $jsonLd = $ctx->jsonLd();

        if ($jsonLd->isEmpty()) {
            return $this->na('ยังไม่มี JSON-LD ที่อ่านได้ (ดูข้อก่อนหน้า)');
        }

        $expected = $ctx->pageType->expectedTypes();
        $present = $jsonLd->types();

        $missingRequired = [];
        $missingRecommended = [];

        foreach ($expected['required'] as $type) {
            if (! $this->satisfied($type, $present)) {
                $missingRequired[] = $type;
            }
        }

        foreach ($expected['recommended'] as $type) {
            if (! $this->satisfied($type, $present)) {
                $missingRecommended[] = $type;
            }
        }

        $details = [
            'ประเภทหน้าที่ตรวจพบ: ' . $ctx->pageType->label() . ' (เดาจาก URL และ og:type)',
            'ชนิดที่ควรมี: ' . implode(', ', $expected['required']),
            'ชนิดที่พบจริง: ' . implode(', ', $present),
        ];

        $requiredCount = max(1, count($expected['required']));
        $score = 1.0
            - (count($missingRequired) / $requiredCount) * 0.8
            - (count($missingRecommended) > 0 ? 0.15 : 0.0);

        if ($missingRequired === [] && $missingRecommended === []) {
            return $this->pass('ครบตามประเภทหน้า', $details);
        }

        if ($missingRequired === []) {
            return $this->partial(
                max(0.8, $score),
                'ขาดชนิดที่แนะนำ: ' . implode(', ', $missingRecommended),
                $this->adviceFor($ctx->pageType, $missingRecommended),
                $details
            );
        }

        return $this->partial(
            max(0.0, $score),
            'ขาดชนิดที่จำเป็น: ' . implode(', ', $missingRequired),
            $this->adviceFor($ctx->pageType, $missingRequired),
            $details
        );
    }

    /** @param list<string> $present */
    private function satisfied(string $required, array $present): bool
    {
        if (in_array($required, $present, true)) {
            return true;
        }

        // ชนิดย่อยนับว่าผ่าน: BlogPosting ผ่านเงื่อนไข Article, AboutPage ผ่านเงื่อนไข WebPage
        $family = match ($required) {
            'WebPage' => PageType::WEBPAGE_SUBTYPES,
            'Article' => PageType::ARTICLE_SUBTYPES,
            'Organization' => ['Organization', 'Corporation', 'LocalBusiness', 'EducationalOrganization', 'NGO', 'OnlineBusiness'],
            'Service' => ['Service', 'ProfessionalService', 'Product'],
            default => [$required],
        };

        return array_intersect($family, $present) !== [];
    }

    /** @param list<string> $missing */
    private function adviceFor(PageType $pageType, array $missing): string
    {
        $hints = [
            'Organization' => 'Organization ควรอยู่ครั้งเดียวและใช้ @id เดียวกันทั้งเว็บ แล้วหน้าอื่นอ้างถึงด้วย {"@id": "..."}',
            'WebSite' => 'WebSite บนหน้าแรกทำให้ AI รู้ชื่อเว็บและช่องค้นหาภายใน (potentialAction)',
            'Article' => 'ใช้ Article หรือ BlogPosting พร้อม headline, datePublished, dateModified, author และ image',
            'BreadcrumbList' => 'BreadcrumbList บอกว่าหน้านี้อยู่ตรงไหนของเว็บ ช่วยให้ AI เข้าใจบริบทของหัวข้อ',
            'Service' => 'Service ควรมี name, description, provider ที่อ้างถึง Organization และ areaServed',
            'Product' => 'Product ต้องมีอย่างน้อยหนึ่งใน offers, review หรือ aggregateRating',
            'FAQPage' => 'FAQPage คือช่องทางตรงที่สุดในการป้อนคู่คำถาม-คำตอบให้ AI หยิบไปตอบ',
            'Person' => 'Person ของผู้เขียนพร้อม sameAs คือสัญญาณ E-E-A-T ที่หนักที่สุดที่ใส่ได้ในโค้ด',
            'CollectionPage' => 'CollectionPage พร้อม ItemList บอกว่าหน้านี้เป็นสารบัญ ไม่ใช่เนื้อหาหลัก',
            'AboutPage' => 'AboutPage ทำให้หน้านี้ถูกจับคู่กับคำถามว่า "บริษัทนี้คือใคร"',
            'ContactPage' => 'ContactPage คู่กับ Organization ที่มี telephone และ address',
        ];

        $lines = [];
        foreach ($missing as $type) {
            $lines[] = $hints[$type] ?? "เพิ่ม @type {$type}";
        }

        return implode(' · ', $lines);
    }
}
