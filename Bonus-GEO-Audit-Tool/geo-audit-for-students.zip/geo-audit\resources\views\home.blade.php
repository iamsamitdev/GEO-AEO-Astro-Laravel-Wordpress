@extends('layouts.app')

@section('content')
<div class="wrap">
    <section class="hero">
        <h1>เว็บของคุณพร้อมให้ AI อ้างอิงหรือยัง</h1>
        <p class="lede">
            ใส่ URL แล้วเครื่องมือจะดึงหน้าแบบเดียวกับที่ GPTBot, ClaudeBot และ PerplexityBot เห็น
            คือ HTML ดิบที่ยังไม่รัน JavaScript แล้วให้คะแนน 6 หมวด พร้อมบอกว่าควรแก้อะไรก่อน
        </p>
    </section>

    <div class="card" style="margin-top:24px">
        @if ($errors->any())
            <div class="errors">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="tabs" role="tablist">
            <button type="button" class="tab" role="tab" aria-selected="true" data-panel="panel-url">ตรวจจาก URL</button>
            <button type="button" class="tab" role="tab" aria-selected="false" data-panel="panel-files">อัปโหลดไฟล์ HTML</button>
            <button type="button" class="tab" role="tab" aria-selected="false" data-panel="panel-upload">อัปโหลดโฟลเดอร์ dist/</button>
        </div>

        <div id="panel-url">
            <form method="POST" action="{{ route('reports.store') }}">
                @csrf

                <label class="field">
                    <span class="label-text">URL ที่ต้องการตรวจ</span>
                    <input type="text" name="url" value="{{ old('url') }}" placeholder="https://example.com/blog/my-article"
                           required autocomplete="url" spellcheck="false">
                    <span class="hint">ใส่ที่อยู่เต็มของหน้าที่ต้องการ ถ้าไม่ใส่ https:// ให้เอง ระบบจะเติมให้</span>
                </label>

                <label class="check">
                    <input type="radio" name="mode" value="url" {{ old('mode', 'url') === 'url' ? 'checked' : '' }}>
                    <span class="check-body">
                        <strong>ตรวจหน้าเดียว</strong>
                        <span>เร็วที่สุด ใช้เวลาไม่กี่วินาที เหมาะกับการตรวจทีละหน้าตอนแก้งาน</span>
                    </span>
                </label>

                <label class="check">
                    <input type="radio" name="mode" value="site" {{ old('mode') === 'site' ? 'checked' : '' }}>
                    <span class="check-body">
                        <strong>ตรวจทั้งเว็บ (สูงสุด {{ $crawlLimit }} หน้า)</strong>
                        <span>ไล่ตามรายการใน sitemap.xml แล้วสรุปว่าปัญหาไหนเกิดซ้ำหลายหน้า ใช้เวลาหลายนาที</span>
                    </span>
                </label>

                <label class="check {{ $aiAvailable ? '' : 'disabled' }}">
                    <input type="checkbox" name="use_ai" value="1" {{ $aiAvailable ? '' : 'disabled' }} {{ old('use_ai') ? 'checked' : '' }}>
                    <span class="check-body">
                        <strong>ให้ Claude ประเมินคุณภาพคำตอบด้วย</strong>
                        <span>
                            @if ($aiAvailable)
                                เพิ่มการตรวจที่กฎทำไม่ได้ เช่น "ย่อหน้าใต้หัวข้อนี้ตอบคำถามจริงไหม" ช้าลงและมีค่าใช้จ่ายต่อครั้ง
                            @else
                                ยังไม่ได้ตั้งค่า ANTHROPIC_API_KEY บนเซิร์ฟเวอร์นี้
                            @endif
                        </span>
                    </span>
                </label>

                <button type="submit" class="btn">เริ่มตรวจ</button>
            </form>
        </div>

        <div id="panel-files" hidden>
            <form method="POST" action="{{ route('reports.files') }}" enctype="multipart/form-data">
                @csrf

                <label class="field">
                    <span class="label-text">ไฟล์ .html (เลือกได้หลายไฟล์)</span>
                    <input type="file" name="documents[]" accept=".html,.htm" multiple required>
                    <span class="hint">
                        ลากไฟล์มาวางหรือกดเลือกได้ทีละหลายไฟล์ สูงสุด {{ $crawlLimit }} ไฟล์ต่อครั้ง
                        ระบบอ่านอย่างเดียวแล้วลบทิ้งทันทีที่ตรวจเสร็จ
                    </span>
                </label>

                <label class="field">
                    <span class="label-text">ประเภทหน้า</span>
                    <select name="page_type">
                        <option value="auto">ให้ระบบเดาเอง (แนะนำ)</option>
                        @foreach (\App\Audit\Content\PageType::cases() as $type)
                            <option value="{{ $type->value }}" @selected(old('page_type') === $type->value)>{{ $type->label() }}</option>
                        @endforeach
                    </select>
                    <span class="hint">
                        ปกติระบบเดาจาก og:type และโครงสร้างในหน้าได้เอง
                        แต่ถ้าไฟล์ไม่ได้ประกาศอะไรไว้เลย การระบุเองจะทำให้ตรวจเรื่องผู้เขียน วันที่ และ schema ได้ตรงประเภท
                    </span>
                </label>

                <label class="field">
                    <span class="label-text">URL ของเว็บจริง (ไม่บังคับ)</span>
                    <input type="text" name="base_url" value="{{ old('base_url') }}" placeholder="https://example.com" spellcheck="false">
                    <span class="hint">ใส่ไว้เพื่อให้ตรวจ canonical ได้ครบ</span>
                </label>

                <div class="notice" style="margin-bottom:16px">
                    <strong>ข้อจำกัดของโหมดนี้:</strong>
                    ไฟล์ในเครื่องไม่มี robots.txt, sitemap.xml และ llms.txt ให้ตรวจ
                    ข้อที่เกี่ยวกับสามอย่างนี้จะถูกข้าม (แสดงเป็น "ไม่เกี่ยวข้อง") และไม่นำมาคิดคะแนน
                </div>

                <button type="submit" class="btn">อัปโหลดแล้วตรวจ</button>
            </form>
        </div>

        <div id="panel-upload" hidden>
            <form method="POST" action="{{ route('reports.upload') }}" enctype="multipart/form-data">
                @csrf

                <label class="field">
                    <span class="label-text">ไฟล์ zip ของโฟลเดอร์ dist/</span>
                    <input type="file" name="archive" accept=".zip" required>
                    <span class="hint">
                        บีบอัดโฟลเดอร์ที่ได้จาก <code>npm run build</code> แล้วอัปโหลดมา
                        ระบบจะอ่านเฉพาะไฟล์ .html และลบทิ้งทันทีที่ตรวจเสร็จ
                    </span>
                </label>

                <label class="field">
                    <span class="label-text">URL ของเว็บจริง (ไม่บังคับ)</span>
                    <input type="text" name="base_url" value="{{ old('base_url') }}" placeholder="https://example.com" spellcheck="false">
                    <span class="hint">ใส่ไว้เพื่อให้ตรวจ canonical และลิงก์ภายในได้ถูกต้อง</span>
                </label>

                <div class="notice" style="margin-bottom:16px">
                    <strong>ข้อจำกัดของโหมดนี้:</strong>
                    ไฟล์ในเครื่องไม่มี robots.txt, sitemap.xml และ llms.txt ให้ตรวจ
                    ข้อที่เกี่ยวกับสามอย่างนี้จะถูกข้าม (แสดงเป็น "ไม่เกี่ยวข้อง") และไม่นำมาคิดคะแนน
                </div>

                <button type="submit" class="btn">อัปโหลดแล้วตรวจ</button>
            </form>
        </div>
    </div>

    @if ($recent->isNotEmpty())
        <div class="card">
            <h2>ตรวจไปล่าสุด</h2>
            <p class="sub">รายงานทุกฉบับเปิดดูได้จากลิงก์ ไม่ต้องล็อกอิน</p>
            <ul class="recent-list">
                @foreach ($recent as $item)
                    <li>
                        <span class="pill {{ $item->score >= 90 ? 'v-pass' : ($item->score >= 50 ? 'v-average' : 'v-fail') }}">{{ $item->score ?? '-' }}</span>
                        <a class="url" href="{{ route('reports.show', $item) }}">{{ \Illuminate\Support\Str::limit(\App\Audit\Support\Url::forDisplay($item->target), 70) }}</a>
                        <span style="color:var(--text-faint)">{{ $item->created_at->diffForHumans() }}</span>
                    </li>
                @endforeach
            </ul>
        </div>
    @endif
</div>

@push('scripts')
<script>
    document.querySelectorAll('.tab').forEach(function (tab) {
        tab.addEventListener('click', function () {
            document.querySelectorAll('.tab').forEach(function (other) {
                var panel = document.getElementById(other.dataset.panel);
                var selected = other === tab;
                other.setAttribute('aria-selected', selected ? 'true' : 'false');
                if (panel) panel.hidden = !selected;
            });
        });
    });
</script>
@endpush
@endsection
