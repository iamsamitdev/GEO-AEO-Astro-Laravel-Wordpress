<?php

namespace App\Audit\Audits\StructuredData;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\JsonLd;
use App\Audit\Support\Text;

/**
 * สิ่งที่ schema ประกาศ ตรงกับสิ่งที่คนเห็นบนหน้าจริงหรือเปล่า
 *
 * นี่คือข้อที่ทำให้เว็บโดนลงโทษจริงจัง ทั้งจาก Google และจากการที่ AI เลิกเชื่อ
 * รูปแบบที่พบบ่อยคือปลั๊กอิน SEO สร้าง FAQPage จากช่องกรอกในหลังบ้าน
 * แต่หน้าเว็บจริงไม่เคยแสดงคำถามเหล่านั้นเลย - นับเป็น structured data ที่หลอกลวง
 */
final class SchemaMatchesContentAudit extends BaseAudit
{
    public function id(): string
    {
        return 'schema-matches-content';
    }

    public function title(): string
    {
        return 'schema ตรงกับเนื้อหาที่แสดงบนหน้า';
    }

    public function category(): Category
    {
        return Category::StructuredData;
    }

    public function weight(): float
    {
        return 2.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $jsonLd = $ctx->jsonLd();

        if ($jsonLd->isEmpty()) {
            return $this->na('ยังไม่มี JSON-LD ที่อ่านได้');
        }

        $pageText = $this->searchable($ctx->document->bodyText());
        $checks = [];
        $details = [];

        // headline / name ของหน้า ควรปรากฏบนหน้าจริง
        foreach (['Article', 'BlogPosting', 'NewsArticle', 'Service', 'Product'] as $type) {
            $node = $jsonLd->firstOfType($type);
            if ($node === null) {
                continue;
            }

            $headline = JsonLd::scalar($node, 'headline') ?? JsonLd::scalar($node, 'name');
            if ($headline === null || Text::length($headline) < 8) {
                continue;
            }

            $found = $this->appearsOnPage($headline, $pageText);
            $checks[] = $found;
            $details[] = ($found ? 'พบบนหน้า: ' : 'ไม่พบบนหน้า: ') . "{$type}.headline = " . Text::truncate($headline, 70);
            break;
        }

        // คำถามใน FAQPage ต้องแสดงบนหน้าจริงทุกข้อ
        $faq = $jsonLd->firstOfType('FAQPage');
        if ($faq !== null) {
            $questions = $this->faqQuestions($faq);
            $missing = [];

            foreach ($questions as $question) {
                $found = $this->appearsOnPage($question, $pageText);
                $checks[] = $found;
                if (! $found) {
                    $missing[] = Text::truncate($question, 60);
                }
            }

            $details[] = 'คำถามใน FAQPage: ' . count($questions) . ' ข้อ · ไม่พบบนหน้า ' . count($missing) . ' ข้อ';
            foreach (array_slice($missing, 0, 4) as $question) {
                $details[] = 'ไม่พบบนหน้า: ' . $question;
            }
        }

        if ($checks === []) {
            return $this->na('ไม่มีคุณสมบัติที่เทียบกับเนื้อหาบนหน้าได้');
        }

        $matched = count(array_filter($checks));
        $total = count($checks);
        $ratio = $matched / $total;

        if ($ratio >= 0.95) {
            return $this->pass("ตรงกัน {$matched}/{$total} รายการ", $details);
        }

        return $this->partial(
            max(0.0, $ratio - 0.1),
            "ไม่ตรงกัน " . ($total - $matched) . " จาก {$total} รายการ",
            'schema ต้องประกอบจากข้อมูลชุดเดียวกับที่เรนเดอร์บนหน้า ไม่ใช่กรอกแยกในหลังบ้าน - ถ้าคำถามอยู่ใน FAQPage ก็ต้องมีบล็อกคำถามให้คนอ่านเห็นด้วย ไม่งั้นถือเป็น structured data ที่ไม่ตรงกับหน้า',
            $details
        );
    }

    /** @return list<string> */
    private function faqQuestions(array $faq): array
    {
        $entities = $faq['mainEntity'] ?? [];
        if (! is_array($entities)) {
            return [];
        }
        if (! array_is_list($entities)) {
            $entities = [$entities];
        }

        $out = [];
        foreach ($entities as $entity) {
            if (! is_array($entity)) {
                continue;
            }
            $name = JsonLd::scalar($entity, 'name');
            if (is_string($name) && Text::length($name) >= 5) {
                $out[] = $name;
            }
        }

        return $out;
    }

    /**
     * เทียบแบบผ่อนปรน: ตัดช่องว่างและวรรคตอนออกก่อน
     * เพราะเทมเพลตมักแทรก &nbsp; หรือขึ้นบรรทัดกลางประโยค
     */
    private function appearsOnPage(string $needle, string $haystack): bool
    {
        $needle = $this->searchable($needle);

        if ($needle === '' || mb_strlen($needle, 'UTF-8') < 8) {
            return true;
        }

        if (str_contains($haystack, $needle)) {
            return true;
        }

        // ยอมให้ข้อความบนหน้าถูกตัดท้าย เทียบแค่ครึ่งแรกที่ยาวพอ
        $prefix = mb_substr($needle, 0, max(20, (int) (mb_strlen($needle, 'UTF-8') * 0.6)), 'UTF-8');

        return mb_strlen($prefix, 'UTF-8') >= 12 && str_contains($haystack, $prefix);
    }

    private function searchable(string $s): string
    {
        $s = mb_strtolower(Text::normalizeWhitespace($s), 'UTF-8');

        return preg_replace('/[\s\p{P}\p{S}]+/u', '', $s) ?? $s;
    }
}
