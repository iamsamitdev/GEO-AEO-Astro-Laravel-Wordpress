<?php

namespace Tests\Feature;

use App\Audit\Http\Fetcher;
use App\Audit\Http\UrlGuard;
use PHPUnit\Framework\Attributes\DataProvider;
use RuntimeException;
use Tests\TestCase;

/**
 * ค่าที่คนนำเครื่องมือไปใช้ต่อต้องตั้งเองได้ และด่านกัน SSRF
 *
 * สองเรื่องนี้เป็นจุดที่พลาดแล้วเดือดร้อนคนอื่น: แนะนำตัวด้วยชื่อของเจ้าอื่น
 * หรือเผลอเปิดให้เว็บสาธารณะยิงเข้าเครือข่ายภายในได้
 */
class BotIdentityAndGuardTest extends TestCase
{
    public function test_ใช้ชื่อบอทที่ตั้งใน_env(): void
    {
        config(['geoaudit.user_agent' => 'MyAuditBot/2.0 (+https://example.org/bot)']);

        $this->assertSame('MyAuditBot/2.0 (+https://example.org/bot)', Fetcher::userAgent());
    }

    public function test_ไม่ได้ตั้งชื่อบอทให้ใช้ค่าเริ่มต้นที่ไม่ผูกกับใคร(): void
    {
        config(['geoaudit.user_agent' => null]);

        $agent = Fetcher::userAgent();

        $this->assertSame(Fetcher::DEFAULT_USER_AGENT, $agent);
        $this->assertStringNotContainsString('itgenius', strtolower($agent), 'ค่าเริ่มต้นต้องไม่ผูกกับเว็บใดเว็บหนึ่ง');
        $this->assertStringNotContainsString('gptbot', strtolower($agent), 'ห้ามแอบอ้างเป็นบอทของเจ้าอื่น');
    }

    public function test_ปิดการตรวจเครือข่ายภายในเป็นค่าเริ่มต้น(): void
    {
        config(['geoaudit.allow_private_hosts' => null]);

        $this->assertFalse(Fetcher::allowsPrivateHosts(), 'ค่าเริ่มต้นต้องปิดไว้ ไม่งั้นเว็บสาธารณะจะกลายเป็นช่องยิงเข้าเครือข่ายภายใน');
    }

    #[DataProvider('blockedHosts')]
    public function test_บล็อกเครือข่ายภายในเมื่อปิดสวิตช์(string $url): void
    {
        $this->expectException(RuntimeException::class);

        (new UrlGuard)->validate($url);
    }

    public static function blockedHosts(): array
    {
        return [
            'localhost' => ['http://localhost:8000/'],
            'loopback' => ['http://127.0.0.1:8000/'],
            'วงแลน' => ['http://192.168.1.10/'],
            'cloud metadata' => ['http://169.254.169.254/latest/meta-data/'],
        ];
    }

    public function test_เปิดสวิตช์แล้วตรวจ_dev_server_ในเครื่องได้(): void
    {
        $guard = new UrlGuard(allowPrivate: true);

        $this->assertSame('http://localhost:4321/blog', $guard->validate('http://localhost:4321/blog'));
    }

    #[DataProvider('publicPorts')]
    public function test_เว็บสาธารณะใช้ได้เฉพาะพอร์ตที่กำหนด(int $port, bool $allowed): void
    {
        $url = "https://example.com:{$port}/";

        if (! $allowed) {
            $this->expectException(RuntimeException::class);
        }

        $this->assertSame($url, (new UrlGuard)->validate($url));
    }

    public static function publicPorts(): array
    {
        return [
            'https' => [443, true],
            'พอร์ตสำรองของเว็บ' => [8443, true],
            // กันไม่ให้เครื่องมือถูกใช้ไล่สแกนพอร์ตของเว็บคนอื่น
            'พอร์ตนอกรายการ' => [9999, false],
        ];
    }

    /** dev server ของแต่ละคนใช้พอร์ตต่างกัน บังคับรายการตายตัวจะตรวจเว็บตัวเองไม่ได้ */
    #[DataProvider('devPorts')]
    public function test_โหมดพัฒนาในเครื่องใช้พอร์ตใดก็ได้(int $port): void
    {
        $url = "http://localhost:{$port}/";

        $this->assertSame($url, (new UrlGuard(allowPrivate: true))->validate($url));
    }

    public static function devPorts(): array
    {
        return [
            'Astro' => [4321],
            'Vite' => [5173],
            'artisan serve' => [8000],
            'พอร์ตที่ตั้งเอง' => [8100],
        ];
    }
}
