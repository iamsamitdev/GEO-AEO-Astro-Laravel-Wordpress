<?php

namespace App\Audit\Audits\Seo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\Text;

/**
 * โครงหัวข้อถูกต้อง: h1 เดียว ไม่ข้ามระดับ
 *
 * ลำดับหัวข้อคือโครงร่างที่บอกว่าอะไรอยู่ใต้อะไร
 * การกระโดดจาก h2 ไป h4 ทำให้เครื่องเข้าใจความสัมพันธ์ผิด
 * และมักเกิดจากการเลือกหัวข้อตามขนาดตัวอักษรที่ชอบ แทนที่จะเลือกตามลำดับชั้น
 */
final class HeadingStructureAudit extends BaseAudit
{
    public function id(): string
    {
        return 'heading-structure';
    }

    public function title(): string
    {
        return 'โครงหัวข้อถูกลำดับและมี h1 เดียว';
    }

    public function category(): Category
    {
        return Category::Seo;
    }

    public function weight(): float
    {
        return 2.5;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $doc = $ctx->document;
        $h1Count = $doc->h1Count();
        $headings = $doc->headings();

        $details = ['จำนวน h1: ' . $h1Count];
        foreach (array_slice($doc->h1Texts(), 0, 3) as $text) {
            $details[] = 'h1: ' . Text::truncate($text, 70);
        }

        $score = 1.0;
        $issues = [];

        if ($h1Count === 0) {
            $score -= 0.6;
            $issues[] = 'ไม่มี h1 เลย';
        } elseif ($h1Count > 1) {
            $score -= 0.35;
            $issues[] = "มี h1 {$h1Count} ตัว";
        }

        // ตรวจการข้ามระดับ เช่น h2 -> h4
        $skips = [];
        $previous = null;
        foreach ($headings as $heading) {
            if ($previous !== null && $heading->level > $previous + 1) {
                $skips[] = "h{$previous} ตามด้วย h{$heading->level} ที่ " . Text::truncate($heading->text, 40);
            }
            $previous = $heading->level;
        }

        if ($skips !== []) {
            $score -= min(0.35, count($skips) * 0.12);
            $issues[] = 'ข้ามระดับ ' . count($skips) . ' จุด';
            foreach (array_slice($skips, 0, 3) as $skip) {
                $details[] = $skip;
            }
        }

        $empty = count(array_filter($headings, fn ($h) => Text::length($h->text) < 2));
        if ($empty > 0) {
            $score -= 0.1;
            $issues[] = "{$empty} หัวข้อว่างเปล่า";
        }

        $details[] = 'หัวข้อทั้งหมด (ไม่นับใน nav/footer): ' . count($headings);

        if ($issues === []) {
            return $this->pass('h1 เดียว · ลำดับถูกต้อง', $details);
        }

        return $this->partial(
            max(0.0, $score),
            implode(' · ', $issues),
            'ให้แต่ละหน้ามี h1 ตัวเดียวที่เป็นชื่อของหน้า แล้วไล่ h2 h3 ตามลำดับโดยไม่ข้ามขั้น ถ้าอยากได้ขนาดตัวอักษรต่างไป ให้แก้ที่ CSS ไม่ใช่เปลี่ยนระดับหัวข้อ',
            $details
        );
    }
}
