<?php

namespace Tests\Feature;

use App\Audit\Support\Url;
use App\Models\PageResult;
use App\Models\Report;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\TestCase;

/**
 * URL ภาษาไทยที่แสดงบนหน้าเว็บ และชื่อไฟล์ JSON ของโหมดอัปโหลด
 *
 * เจอจริงบน production: URL บทความภาษาไทยแสดงเป็น %E0%B8%... ยาวจนล้นการ์ด
 * และไฟล์ JSON ของโหมดอัปโหลดไฟล์ HTML ได้ชื่อ "report" ทุกฉบับ
 */
class UrlDisplayAndFileNameTest extends TestCase
{
    use RefreshDatabase;

    private const ENCODED_THAI = 'https://www.itgenius.co.th/article/matt-mullenweg-%E0%B8%81%E0%B8%A5%E0%B8%B1%E0%B8%9A%E0%B8%A1%E0%B8%B2';

    #[DataProvider('displayCases')]
    public function test_ถอดรหัส_url_เพื่อแสดงผล(string $input, string $expected): void
    {
        $this->assertSame($expected, Url::forDisplay($input));
    }

    public static function displayCases(): array
    {
        return [
            'ไทยที่เข้ารหัส' => [self::ENCODED_THAI, 'https://www.itgenius.co.th/article/matt-mullenweg-กลับมา'],
            'ไม่มีการเข้ารหัส' => ['https://example.com/about', 'https://example.com/about'],
            'ถอดแล้วไม่ใช่ UTF-8 คืนค่าเดิม' => ['https://example.com/%FF%FE', 'https://example.com/%FF%FE'],
            'อักขระควบคุมคืนค่าเดิม' => ['https://example.com/a%0Ab', 'https://example.com/a%0Ab'],
        ];
    }

    public function test_หน้ารายงานแสดง_url_ไทยที่อ่านออกแทนรหัส(): void
    {
        foreach (['queued', 'failed', 'done'] as $status) {
            $report = Report::create([
                'mode' => 'url',
                'target' => self::ENCODED_THAI,
                'status' => $status,
                'score' => $status === 'done' ? 80 : null,
            ]);

            $html = $this->get(route('reports.show', $report))->assertOk()->getContent();

            $this->assertStringContainsString('matt-mullenweg-กลับมา', $html, "สถานะ {$status} ต้องแสดง URL ที่ถอดรหัสแล้ว");
            $this->assertStringContainsString('url-text', $html, "สถานะ {$status} ต้องมีคลาสที่ให้ URL ขึ้นบรรทัดใหม่ได้");
            $this->assertStringNotContainsString('%E0%B8%81%E0%B8%A5', $this->bodyWithoutHead($html), "สถานะ {$status} ยังแสดงรหัส %E0 อยู่");
        }
    }

    public function test_หลักฐานในแต่ละข้อแสดง_url_ไทยที่อ่านออก(): void
    {
        $report = Report::create([
            'mode' => 'url',
            'target' => self::ENCODED_THAI,
            'status' => 'done',
            'score' => 80,
        ]);

        PageResult::create([
            'report_id' => $report->id,
            'position' => 0,
            'url' => self::ENCODED_THAI,
            'page_type' => 'article',
            'score' => 80,
            'payload' => [
                'url' => self::ENCODED_THAI,
                'pageTypeLabel' => 'บทความ / ข่าว',
                'score' => 80,
                'categories' => ['crawlability' => ['label' => 'Crawlability', 'weight' => 20, 'score' => 80]],
                'audits' => [[
                    'id' => 'canonical',
                    'title' => 'canonical ถูกต้อง',
                    'category' => 'crawlability',
                    'weight' => 2.0,
                    'score' => 0.5,
                    'verdict' => 'average',
                    'displayValue' => '',
                    'details' => ['URL จริง: ' . self::ENCODED_THAI, 'สัดส่วนข้อความต่อ HTML: 12.5%'],
                    'fix' => '',
                    'byAi' => false,
                ]],
            ],
        ]);

        $body = $this->bodyWithoutHead($this->get(route('reports.show', $report))->getContent());

        $this->assertStringContainsString('URL จริง: https://www.itgenius.co.th/article/matt-mullenweg-กลับมา', $body);
        $this->assertStringNotContainsString('%E0%B8', $body);
        // เครื่องหมาย % ที่ไม่ใช่การเข้ารหัสต้องอยู่ครบ
        $this->assertStringContainsString('12.5%', $body);
    }

    #[DataProvider('fileNameCases')]
    public function test_ชื่อไฟล์_json_ของแต่ละโหมด(string $mode, string $target, string $expectedSlug): void
    {
        $report = Report::create([
            'mode' => $mode,
            'target' => $target,
            'status' => 'done',
            'score' => 70,
        ]);

        $disposition = $this->get(route('reports.json', $report))->headers->get('Content-Disposition');

        $this->assertStringContainsString('filename="geo-audit-' . $expectedSlug . '-', $disposition);
    }

    public static function fileNameCases(): array
    {
        return [
            'ไฟล์ HTML ไฟล์เดียว' => ['files', 'about.html', 'about'],
            'ไฟล์ HTML หลายไฟล์' => ['files', 'index.html และอีก 2 ไฟล์', 'index-3-files'],
            'ชื่อไฟล์ไทยล้วน' => ['files', 'เกี่ยวกับเรา.html', 'html-files'],
            'zip ของ dist' => ['upload', 'dist.zip', 'dist'],
            'จาก URL' => ['url', self::ENCODED_THAI, 'www-itgenius-co-th'],
        ];
    }

    /** ตัด <head> ออก เพราะ URL ใน href ของลิงก์ภายนอกยังต้องเป็นรูปเข้ารหัสได้ตามปกติ */
    private function bodyWithoutHead(string $html): string
    {
        return preg_replace('#<head>.*?</head>#s', '', $html) ?? $html;
    }
}
