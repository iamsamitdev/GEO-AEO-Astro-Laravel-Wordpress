<?php

namespace App\Audit\Audits\AiFiles;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;

/**
 * มี llms.txt ที่เขียนถูกรูปแบบหรือไม่
 *
 * ต้องพูดตรง ๆ ว่า llms.txt ยังเป็นข้อเสนอของชุมชน ไม่ใช่มาตรฐานที่ผู้ให้บริการ AI รายใหญ่
 * ประกาศว่าอ่าน ณ ตอนนี้ - เราจึงให้น้ำหนักหมวดนี้แค่ 5 คะแนน ไม่ใช่ 20
 *
 * ที่ยังคุ้มทำเพราะต้นทุนต่ำมาก (ไฟล์ข้อความไฟล์เดียว generate จากข้อมูลที่มีอยู่แล้ว)
 * และการเขียนมันบังคับให้ทีมตอบให้ได้ว่า "หน้าไหนของเราคือหน้าที่สำคัญจริง"
 *
 * รูปแบบตามข้อเสนอ: H1 ชื่อโครงการ, ย่อหน้าสรุปใน blockquote, แล้วรายการลิงก์ใต้ H2
 */
final class LlmsTxtAudit extends BaseAudit
{
    public function id(): string
    {
        return 'llms-txt';
    }

    public function title(): string
    {
        return 'มี llms.txt ที่เขียนถูกรูปแบบ';
    }

    public function category(): Category
    {
        return Category::AiFiles;
    }

    public function weight(): float
    {
        return 1.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        if ($ctx->offline) {
            return $this->na('โหมดตรวจไฟล์ในเครื่อง ไม่มีโดเมนให้ตรวจ');
        }

        $site = $ctx->site;

        if (! $site->hasLlmsTxt()) {
            $servedHtml = $site->llmsTxt !== null && str_contains($site->llmsTxt->contentType(), 'html');

            return $this->partial(
                0.0,
                $servedHtml ? '/llms.txt ตอบกลับเป็นหน้า HTML (น่าจะเป็นหน้า 404 ของเว็บ)' : 'ไม่มี /llms.txt',
                'สร้าง /llms.txt เป็นไฟล์ text/plain ที่ขึ้นต้นด้วย # ชื่อเว็บ ตามด้วยย่อหน้าสรุปหนึ่งย่อหน้า แล้วลิสต์หน้าสำคัญเป็นรายการลิงก์ Markdown พร้อมคำอธิบายสั้นต่อท้ายแต่ละบรรทัด สร้างอัตโนมัติจากข้อมูลชุดเดียวกับที่ใช้ทำ sitemap ได้เลย',
                ['หมายเหตุ: llms.txt ยังเป็นข้อเสนอของชุมชน ยังไม่มีผู้ให้บริการ AI รายใหญ่ประกาศว่าอ่านไฟล์นี้เป็นทางการ หมวดนี้จึงมีน้ำหนักเพียง 5 คะแนนจาก 100']
            );
        }

        $body = $site->llmsTxt->body;
        $lines = preg_split('/\R/', $body) ?: [];

        $hasH1 = (bool) preg_match('/^#\s+\S/m', $body);
        $hasSummary = (bool) preg_match('/^>\s*\S/m', $body);
        $hasSections = (bool) preg_match('/^##\s+\S/m', $body);
        $linkCount = preg_match_all('/^\s*[-*]\s*\[[^\]]+\]\([^)]+\)/m', $body) ?: 0;
        $bytes = strlen($body);

        $details = [
            'ขนาด: ' . round($bytes / 1024, 1) . ' KB · ' . count($lines) . ' บรรทัด',
            'หัวเรื่อง H1: ' . ($hasH1 ? 'มี' : 'ไม่มี'),
            'ย่อหน้าสรุป (blockquote): ' . ($hasSummary ? 'มี' : 'ไม่มี'),
            'หัวข้อหมวด H2: ' . ($hasSections ? 'มี' : 'ไม่มี'),
            "รายการลิงก์: {$linkCount}",
        ];

        if ($site->llmsFullTxt !== null && $site->llmsFullTxt->ok()) {
            $details[] = 'มี /llms-full.txt ด้วย';
        }

        $score = 0.0;
        $score += $hasH1 ? 0.25 : 0.0;
        $score += $hasSummary ? 0.2 : 0.0;
        $score += $hasSections ? 0.15 : 0.0;
        $score += min(0.4, $linkCount * 0.05);

        if ($score >= 0.9) {
            return $this->pass("มีครบตามรูปแบบ · {$linkCount} ลิงก์", $details);
        }

        $missing = [];
        if (! $hasH1) {
            $missing[] = 'H1';
        }
        if (! $hasSummary) {
            $missing[] = 'ย่อหน้าสรุป';
        }
        if ($linkCount < 5) {
            $missing[] = 'รายการลิงก์ (มี ' . $linkCount . ')';
        }

        return $this->partial(
            $score,
            'มีไฟล์แต่ยังไม่ครบรูปแบบ: ขาด ' . implode(', ', $missing),
            'โครงที่แนะนำคือ: บรรทัดแรก "# ชื่อเว็บ" ตามด้วย "> สรุปหนึ่งประโยคว่าเว็บนี้ทำอะไร" แล้วแบ่งเป็นหมวดด้วย ## และในแต่ละหมวดใส่ "- [ชื่อหน้า](URL): คำอธิบายสั้น" ให้ครบหน้าที่อยากให้ AI อ้างอิง',
            $details
        );
    }
}
