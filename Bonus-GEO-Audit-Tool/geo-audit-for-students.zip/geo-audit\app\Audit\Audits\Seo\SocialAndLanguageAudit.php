<?php

namespace App\Audit\Audits\Seo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;

/**
 * ป้ายข้อมูลพื้นฐาน: Open Graph, Twitter card และการประกาศภาษา
 *
 * lang ที่ถูกต้องสำคัญกว่าที่คิดกับเว็บภาษาไทย
 * เพราะระบบที่คัดเนื้อหามาตอบมักกรองตามภาษาก่อน ถ้าหน้าไทยประกาศ lang="en"
 * ก็มีสิทธิ์ถูกตัดออกจากผลของคำถามภาษาไทยตั้งแต่ต้นทาง
 */
final class SocialAndLanguageAudit extends BaseAudit
{
    public function id(): string
    {
        return 'social-and-language';
    }

    public function title(): string
    {
        return 'ประกาศภาษาและการ์ดแชร์ครบ';
    }

    public function category(): Category
    {
        return Category::Seo;
    }

    public function weight(): float
    {
        return 1.5;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $doc = $ctx->document;

        $lang = $doc->htmlLang();
        $bodyText = $doc->bodyText();
        $thaiChars = preg_match_all('/\p{Thai}/u', $bodyText) ?: 0;
        $isThaiPage = $thaiChars > 100;

        $og = [
            'og:title' => $doc->propertyContent('og:title'),
            'og:description' => $doc->propertyContent('og:description'),
            'og:image' => $doc->propertyContent('og:image'),
            'og:url' => $doc->propertyContent('og:url'),
            'og:type' => $doc->propertyContent('og:type'),
        ];

        $missingOg = array_keys(array_filter($og, fn ($v) => $v === null));
        $hasTwitter = $doc->metaContent('twitter:card') !== null;

        $details = [
            'lang: ' . ($lang ?? '(ไม่ประกาศ)'),
            'ภาษาของเนื้อหา: ' . ($isThaiPage ? 'ไทย' : 'ไม่ใช่ไทย'),
            'Open Graph ที่ขาด: ' . ($missingOg === [] ? 'ไม่ขาด' : implode(', ', $missingOg)),
            'twitter:card: ' . ($hasTwitter ? 'มี' : 'ไม่มี'),
        ];

        $score = 1.0;
        $issues = [];

        if ($lang === null) {
            $score -= 0.35;
            $issues[] = 'ไม่ประกาศ lang บน <html>';
        } elseif ($isThaiPage && ! str_starts_with(strtolower($lang), 'th')) {
            $score -= 0.4;
            $issues[] = "เนื้อหาเป็นภาษาไทยแต่ประกาศ lang=\"{$lang}\"";
        }

        $criticalOg = array_intersect($missingOg, ['og:title', 'og:description', 'og:image']);
        if ($criticalOg !== []) {
            $score -= min(0.35, count($criticalOg) * 0.12);
            $issues[] = 'ขาด ' . implode(', ', $criticalOg);
        }

        if (! $hasTwitter) {
            $score -= 0.1;
            $issues[] = 'ไม่มี twitter:card';
        }

        $alternates = $doc->alternates();
        if ($alternates !== []) {
            $details[] = 'hreflang ที่ประกาศ: ' . implode(', ', array_column($alternates, 'hreflang'));
        }

        if ($issues === []) {
            return $this->pass('ครบทั้ง lang และการ์ดแชร์', $details);
        }

        return $this->partial(
            max(0.0, $score),
            implode(' · ', $issues),
            'ตั้ง lang ให้ตรงกับภาษาเนื้อหา (th สำหรับหน้าไทย) และใส่ Open Graph ครบชุดในเลย์เอาต์กลาง เพื่อให้ทุกหน้าได้ไปพร้อมกัน',
            $details
        );
    }
}
