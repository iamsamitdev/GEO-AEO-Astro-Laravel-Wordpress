<?php

namespace App\Http\Controllers;

use App\Audit\Category;
use App\Audit\Content\PageType;
use App\Audit\Http\UrlGuard;
use App\Jobs\RunReportJob;
use App\Models\Report;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Throwable;

class ReportController extends Controller
{
    public function index(): View
    {
        return view('home', [
            'aiAvailable' => (bool) config('geoaudit.anthropic_key'),
            'crawlLimit' => (int) config('geoaudit.crawl_limit'),
            'recent' => Report::where('status', 'done')
                ->latest()
                ->limit(6)
                ->get(['ulid', 'target', 'mode', 'score', 'created_at']),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'mode' => ['required', 'in:url,site'],
            'url' => ['required', 'string', 'max:2000'],
            'use_ai' => ['nullable', 'boolean'],
        ], [], [
            'url' => 'URL',
        ]);

        $this->assertWithinRateLimit($request);

        try {
            $url = (new UrlGuard)->validate($data['url']);
        } catch (Throwable $e) {
            throw ValidationException::withMessages(['url' => $e->getMessage()]);
        }

        $report = Report::create([
            'mode' => $data['mode'],
            'target' => $url,
            'status' => 'queued',
            'use_ai' => $this->aiRequested($request),
            'requester_hash' => $this->requesterHash($request),
        ]);

        RunReportJob::dispatch($report->id);

        return redirect()->route('reports.show', $report);
    }

    public function upload(Request $request): RedirectResponse
    {
        $request->validate([
            'archive' => ['required', 'file', 'mimes:zip', 'max:' . (int) config('geoaudit.max_upload_kb')],
            'base_url' => ['nullable', 'string', 'max:500'],
            'use_ai' => ['nullable', 'boolean'],
        ], [], [
            'archive' => 'ไฟล์ zip',
            'base_url' => 'URL ของเว็บจริง',
        ]);

        $this->assertWithinRateLimit($request);

        $baseUrl = $this->validatedBaseUrl($request);

        $report = Report::create([
            'mode' => 'upload',
            'target' => $request->file('archive')->getClientOriginalName(),
            'label' => $baseUrl !== '' ? $baseUrl : null,
            'status' => 'queued',
            'use_ai' => $this->aiRequested($request),
            'requester_hash' => $this->requesterHash($request),
        ]);

        $request->file('archive')->storeAs('uploads', $report->ulid . '.zip', 'local');

        RunReportJob::dispatch($report->id);

        return redirect()->route('reports.show', $report);
    }

    /**
     * อัปโหลดไฟล์ .html ทีละไฟล์ ไม่ต้องบีบเป็น zip
     *
     * ปลอดภัยกว่าโหมด zip เพราะไม่มีการแตกอาร์ไคฟ์ จึงไม่มีช่อง zip slip
     * แลกกับการที่ไม่มีโครงโฟลเดอร์ให้เดา path ผู้ใช้จึงระบุประเภทหน้าเองได้
     */
    public function uploadFiles(Request $request): RedirectResponse
    {
        $limit = max(1, (int) config('geoaudit.crawl_limit'));

        $request->validate([
            'documents' => ['required', 'array', 'max:' . $limit],
            // mimes:html ไม่พอ เพราะไฟล์ที่ export มามักถูกตรวจเป็น text/plain
            'documents.*' => ['file', 'max:' . (int) config('geoaudit.max_upload_kb'), 'extensions:html,htm'],
            'base_url' => ['nullable', 'string', 'max:500'],
            'page_type' => ['nullable', 'string', Rule::in($this->pageTypeValues())],
            'use_ai' => ['nullable', 'boolean'],
        ], [
            'documents.required' => 'กรุณาเลือกไฟล์ .html อย่างน้อยหนึ่งไฟล์',
            'documents.max' => "อัปโหลดได้สูงสุด {$limit} ไฟล์ต่อครั้ง",
            'documents.*.extensions' => 'รับเฉพาะไฟล์นามสกุล .html หรือ .htm',
        ], [
            'documents' => 'ไฟล์ HTML',
            'base_url' => 'URL ของเว็บจริง',
            'page_type' => 'ประเภทหน้า',
        ]);

        $this->assertWithinRateLimit($request);

        $baseUrl = $this->validatedBaseUrl($request);

        $files = array_values($request->file('documents'));
        $pageType = $request->input('page_type');

        $report = Report::create([
            'mode' => 'files',
            'target' => $this->describeFiles($files),
            'label' => $baseUrl !== '' ? $baseUrl : null,
            'forced_page_type' => $pageType === '' || $pageType === 'auto' ? null : $pageType,
            'status' => 'queued',
            'use_ai' => $this->aiRequested($request),
            'requester_hash' => $this->requesterHash($request),
        ]);

        foreach ($files as $index => $file) {
            $file->storeAs('uploads/' . $report->ulid, $this->safeFileName($file->getClientOriginalName(), $index), 'local');
        }

        RunReportJob::dispatch($report->id);

        return redirect()->route('reports.show', $report);
    }

    public function show(Report $report): View
    {
        $report->load('pages');

        return view('report', [
            'report' => $report,
            'page' => $report->pages->first(),
        ]);
    }

    /** ให้หน้ารายงานถามความคืบหน้าระหว่างงานยังไม่เสร็จ */
    public function status(Report $report): JsonResponse
    {
        return response()->json([
            'status' => $report->status,
            'statusLabel' => $report->statusLabel(),
            'pagesDone' => $report->pages_done,
            'pagesTotal' => $report->pages_total,
            'score' => $report->score,
            'finished' => $report->isFinished(),
        ]);
    }

    public function json(Report $report): Response
    {
        $report->load('pages');

        $payload = [
            'tool' => 'GEO Audit',
            'ulid' => $report->ulid,
            'mode' => $report->mode,
            'target' => $report->target,
            'status' => $report->status,
            'score' => $report->score,
            // ISO 8601 พร้อม offset (+07:00) ตรงกับเวลาที่เห็นบนหน้าเว็บ และยังระบุเวลาได้ชัดเจนไม่กำกวม
            'createdAt' => $report->createdAtLocal()?->toIso8601String(),
            'categoryWeights' => collect(Category::ordered())
                ->mapWithKeys(fn (Category $c) => [$c->value => $c->weight()])
                ->all(),
            'categoryAverages' => $report->categoryAverages(),
            'pages' => $report->pages->map(fn ($page) => $page->payload)->all(),
        ];

        $json = json_encode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT
        );

        /*
         * ต้องเป็น attachment ไม่ใช่ inline
         * inline ทำให้เบราว์เซอร์เปิด JSON แสดงในแท็บแทนที่จะบันทึกไฟล์
         * และต้องส่งเป็น Response ธรรมดา ไม่ใช่ JsonResponse
         * เพราะ JsonResponse บังคับ Content-Type เป็น application/json
         * ซึ่งบางเบราว์เซอร์ยังเลือกแสดงผลเองแม้สั่ง attachment แล้ว
         */
        return response($json, 200, [
            'Content-Type' => 'application/octet-stream',
            'Content-Disposition' => 'attachment; filename="' . $this->downloadName($report) . '"',
            'Content-Length' => (string) strlen($json),
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    /** ชื่อไฟล์ที่บอกได้ว่าเป็นผลของเว็บไหนเมื่อไร ไม่ใช่ ulid ที่คนอ่านไม่ออก */
    private function downloadName(Report $report): string
    {
        $label = match ($report->mode) {
            'upload' => pathinfo($report->target, PATHINFO_FILENAME),
            'files' => $this->uploadedFilesLabel($report),
            default => parse_url($report->target, PHP_URL_HOST) ?: 'report',
        };

        // Str::slug ตัดจุดทิ้ง ทำให้ www.itgenius.co.th กลายเป็น wwwitgeniuscoth ซึ่งอ่านไม่ออก
        // แปลงจุดเป็นขีดก่อน จะได้ www-itgenius-co-th
        // ชื่อไฟล์ภาษาไทยล้วนจะ slug ออกมาว่าง จึงต้องมีชื่อสำรองตามโหมด
        $slug = Str::slug(str_replace('.', '-', $label)) ?: ($report->mode === 'files' ? 'html-files' : 'report');
        $date = ($report->createdAtLocal() ?? now(config('geoaudit.display_timezone')))->format('Ymd-Hi');

        return "geo-audit-{$slug}-{$date}.json";
    }

    /**
     * index.html -> "index"   ·   "index.html และอีก 2 ไฟล์" -> "index-3-files"
     *
     * target ของโหมดนี้คือข้อความที่ describeFiles() ประกอบไว้ ไม่ใช่ URL
     * เดิมตกไปเข้าเงื่อนไข parse_url ซึ่งหา host ไม่เจอ ชื่อไฟล์ทุกฉบับจึงกลายเป็น "report"
     */
    private function uploadedFilesLabel(Report $report): string
    {
        $count = 1;
        if (preg_match('/และอีก\s+(\d+)\s+ไฟล์$/u', $report->target, $m)) {
            $count += (int) $m[1];
        }

        $first = preg_replace('/\s+และอีก\s+\d+\s+ไฟล์$/u', '', $report->target) ?? $report->target;
        $name = pathinfo($first, PATHINFO_FILENAME);

        return $count > 1 ? "{$name}-{$count}-files" : $name;
    }

    private function aiRequested(Request $request): bool
    {
        return $request->boolean('use_ai') && (bool) config('geoaudit.anthropic_key');
    }

    /** @return list<string> */
    private function pageTypeValues(): array
    {
        return array_merge(['auto'], array_column(PageType::cases(), 'value'));
    }

    private function validatedBaseUrl(Request $request): string
    {
        $baseUrl = trim((string) $request->input('base_url'));

        if ($baseUrl === '') {
            return '';
        }

        try {
            // allowPrivate: ค่านี้ไม่ได้ถูกนำไปยิง HTTP แค่ใช้ประกอบ URL ให้ audit เทียบ canonical
            return (new UrlGuard(allowPrivate: true))->validate($baseUrl);
        } catch (Throwable $e) {
            throw ValidationException::withMessages(['base_url' => $e->getMessage()]);
        }
    }

    /** @param array<int, \Illuminate\Http\UploadedFile> $files */
    private function describeFiles(array $files): string
    {
        $first = $files[0]->getClientOriginalName();
        $rest = count($files) - 1;

        return $rest > 0 ? "{$first} และอีก {$rest} ไฟล์" : $first;
    }

    /**
     * ชื่อไฟล์มาจากผู้ใช้ จึงเชื่อไม่ได้
     *
     * ตัดเหลือแค่ basename แล้วอนุญาตเฉพาะตัวอักษร ตัวเลข ไทย จุด ขีด
     * กัน path traversal และชื่อที่ทำให้ระบบไฟล์สับสน
     * ถ้าเหลือไม่พอใช้ ค่อยตั้งชื่อให้ใหม่ตามลำดับ
     */
    private function safeFileName(string $original, int $index): string
    {
        $name = basename(str_replace('\\', '/', $original));
        $name = preg_replace('/\.html?$/i', '', $name) ?? $name;
        $name = preg_replace('/[^\p{L}\p{N}._-]+/u', '-', $name) ?? '';
        $name = trim($name, '-.');

        if ($name === '' || mb_strlen($name) > 80) {
            $name = 'page-' . ($index + 1);
        }

        // นำหน้าด้วยลำดับเพื่อไม่ให้ชื่อซ้ำกันแล้วเขียนทับกันเอง และคงลำดับที่ผู้ใช้เลือกไว้
        return str_pad((string) ($index + 1), 3, '0', STR_PAD_LEFT) . '_' . $name . '.html';
    }

    /**
     * เครื่องมือนี้ยิง HTTP ไปเว็บที่ผู้ใช้ระบุ ถ้าไม่จำกัดจำนวน
     * มันจะกลายเป็นตัวช่วยยิงเว็บคนอื่นโดยที่เจ้าของเว็บเห็นแค่ IP ของเรา
     */
    private function assertWithinRateLimit(Request $request): void
    {
        $limit = (int) config('geoaudit.rate_limit_per_hour');

        if ($limit <= 0) {
            return;
        }

        $used = Report::where('requester_hash', $this->requesterHash($request))
            ->where('created_at', '>=', now()->subHour())
            ->count();

        if ($used >= $limit) {
            throw ValidationException::withMessages([
                'url' => "ตรวจได้สูงสุด {$limit} ครั้งต่อชั่วโมง กรุณารอสักครู่แล้วลองใหม่",
            ]);
        }
    }

    private function requesterHash(Request $request): string
    {
        return hash_hmac('sha256', (string) $request->ip(), (string) config('app.key'));
    }
}
