<?php

namespace App\Audit\Content;

use App\Audit\Content\PageDocument;

/**
 * ประเภทของหน้า ใช้ตัดสินว่า "หน้านี้ควรมี schema อะไร"
 *
 * สำคัญ: การเดาประเภทหน้าห้ามดูจาก JSON-LD เด็ดขาด
 * เพราะเราจะเอาผลนี้ไปตรวจ JSON-LD อีกที ถ้าเดาจาก JSON-LD ก็จะกลายเป็นตรรกะวงกลม
 * (หน้าที่ไม่มี schema เลยจะ "ผ่าน" เพราะเราเดาว่ามันเป็นหน้าทั่วไป)
 *
 * จึงเดาจาก URL, og:type และร่องรอยใน DOM เท่านั้น
 */
enum PageType: string
{
    case Home = 'home';
    case Article = 'article';
    case Service = 'service';
    case Product = 'product';
    case Collection = 'collection';
    case About = 'about';
    case Contact = 'contact';
    case Faq = 'faq';
    case Other = 'other';

    public function label(): string
    {
        return match ($this) {
            self::Home => 'หน้าแรก',
            self::Article => 'บทความ / ข่าว',
            self::Service => 'หน้าบริการ',
            self::Product => 'หน้าสินค้า',
            self::Collection => 'หน้ารวมรายการ',
            self::About => 'เกี่ยวกับเรา',
            self::Contact => 'ติดต่อเรา',
            self::Faq => 'คำถามที่พบบ่อย',
            self::Other => 'หน้าทั่วไป',
        };
    }

    /**
     * schema @type ที่หน้าประเภทนี้ควรมี
     *
     * @return array{required: list<string>, recommended: list<string>}
     */
    public function expectedTypes(): array
    {
        return match ($this) {
            self::Home => [
                'required' => ['Organization', 'WebSite'],
                'recommended' => ['WebPage'],
            ],
            self::Article => [
                'required' => ['Article', 'BreadcrumbList'],
                'recommended' => ['Person', 'Organization'],
            ],
            self::Service => [
                'required' => ['Service', 'BreadcrumbList'],
                'recommended' => ['FAQPage', 'Organization'],
            ],
            self::Product => [
                'required' => ['Product', 'BreadcrumbList'],
                'recommended' => ['Offer', 'AggregateRating'],
            ],
            self::Collection => [
                'required' => ['CollectionPage'],
                'recommended' => ['BreadcrumbList', 'ItemList'],
            ],
            self::About => [
                'required' => ['AboutPage'],
                'recommended' => ['Organization', 'Person'],
            ],
            self::Contact => [
                'required' => ['ContactPage'],
                'recommended' => ['Organization'],
            ],
            self::Faq => [
                'required' => ['FAQPage'],
                'recommended' => ['BreadcrumbList'],
            ],
            self::Other => [
                'required' => ['WebPage'],
                'recommended' => ['BreadcrumbList'],
            ],
        };
    }

    /** @type ที่ Schema.org ถือว่าเป็น WebPage ชนิดหนึ่ง จึงนับว่าผ่านเงื่อนไข WebPage */
    public const WEBPAGE_SUBTYPES = [
        'WebPage', 'AboutPage', 'ContactPage', 'CollectionPage', 'ProfilePage',
        'FAQPage', 'ItemPage', 'SearchResultsPage', 'CheckoutPage', 'QAPage', 'RealEstateListing',
    ];

    /** @type ที่นับเป็น Article ได้ */
    public const ARTICLE_SUBTYPES = [
        'Article', 'BlogPosting', 'NewsArticle', 'TechArticle', 'ScholarlyArticle', 'Report', 'AdvertiserContentArticle',
    ];

    public static function infer(string $url, PageDocument $doc): self
    {
        $path = strtolower(trim(parse_url($url, PHP_URL_PATH) ?: '/', '/'));

        if ($path === '' || $path === 'index.html' || $path === 'home') {
            return self::Home;
        }

        $ogType = strtolower($doc->propertyContent('og:type') ?? '');
        $segments = explode('/', $path);
        $first = $segments[0];
        $last = $segments[count($segments) - 1];

        /*
         * "อยู่ลึกกว่าหนึ่งชั้น" ไม่ได้แปลว่าเป็นหน้าเนื้อหาเสมอไป
         * /article/all และ /blog/page/2 ลึกสองชั้นเหมือนกับ /blog/my-post
         * แต่สองอันแรกเป็นสารบัญ การเดาผิดตรงนี้ทำให้ไปคาดหวัง Article schema
         * บนหน้าที่ไม่ควรมี แล้วหักคะแนนโดยไม่มีเหตุผล
         */
        $listingSlugs = ['all', 'index', 'list', 'archive', 'page', 'home', 'ทั้งหมด'];
        $isLeaf = count($segments) > 1
            && $last !== ''
            && ! in_array($last, $listingSlugs, true)
            && ! ctype_digit($last)
            && ! in_array($segments[count($segments) - 2] ?? '', ['page', 'p'], true);

        $matches = static fn (array $needles) => (bool) array_filter(
            $needles,
            static fn ($needle) => str_contains($path, $needle)
        );

        if ($matches(['faq', 'คำถาม', 'question'])) {
            return self::Faq;
        }

        if ($matches(['contact', 'ติดต่อ'])) {
            return self::Contact;
        }

        if ($matches(['about', 'เกี่ยวกับ', 'our-story', 'company'])) {
            return self::About;
        }

        /*
         * og:type คือการที่หน้าประกาศเองว่ามันคืออะไร เชื่อได้มากกว่าการเดาจากความลึกของ path
         *
         * จุดนี้เคยผิด: เดิมเอา og:type ไปรวมกับเงื่อนไข $isLeaf ทำให้ permalink แบน
         * อย่าง /hello-world ที่ประกาศ og:type=article ถูกตัดสินเป็นหน้ารวมรายการ
         * (เพราะ path มีชั้นเดียวเลยไม่ผ่าน $isLeaf) แล้วไปเรียกหา CollectionPage schema
         * ซึ่งเป็นผลลวงที่เจอได้จริงบน WordPress ที่ตั้ง permalink แบบ /%postname%/
         *
         * ไม่ถือเป็นตรรกะวงกลม เพราะ og:type เป็นคนละชุดข้อมูลกับ JSON-LD
         * ที่ ExpectedTypesAudit เอาไปตรวจ
         */
        if ($ogType === 'article') {
            return self::Article;
        }

        if ($ogType === 'product') {
            return self::Product;
        }

        if ($matches(['product', 'shop', 'สินค้า'])) {
            return $isLeaf ? self::Product : self::Collection;
        }

        if (in_array($first, ['service', 'services', 'บริการ', 'solutions', 'course', 'courses', 'online-courses', 'training', 'หลักสูตร'], true)) {
            return $isLeaf ? self::Service : self::Collection;
        }

        if (in_array($first, ['blog', 'news', 'article', 'articles', 'posts', 'บทความ', 'ข่าว'], true)) {
            return $isLeaf ? self::Article : self::Collection;
        }

        // ร่องรอยของบทความในหน้าเอง: มี <article> + วันที่ + ชื่อผู้เขียน
        if ($doc->countTag('article') > 0 && $doc->has('//time[@datetime]')) {
            return self::Article;
        }

        if (in_array($first, ['category', 'tag', 'archive', 'หมวดหมู่'], true)) {
            return self::Collection;
        }

        return self::Other;
    }
}
