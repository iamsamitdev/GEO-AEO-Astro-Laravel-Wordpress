<?php

namespace App\Support;

/**
 * URL ของไฟล์ static พร้อมเลขเวอร์ชันจากเนื้อหาไฟล์ (?v=<hash>)
 *
 * บน production เว็บหลักตั้ง mod_expires ให้ css/js เก็บ cache ไว้ 30 วัน
 * และกฎนั้นถูกสืบทอดลงมาถึงโฟลเดอร์ /geo-audit ด้วย (mod_expires สืบทอด ต่างจาก mod_rewrite)
 * ถ้าไม่ใส่เวอร์ชัน คนที่เคยเข้าเว็บแล้วจะได้ CSS เก่าไปอีกเป็นเดือน
 * ทุกครั้งที่แก้หน้าตาจะเห็นผลไม่ครบ และฟีเจอร์ที่ต้องพึ่งสไตล์ใหม่จะพังให้เห็นแบบสุ่ม ๆ
 *
 * ใช้ hash ของเนื้อหาแทนเวลาแก้ไขไฟล์ เพราะ deploy ซ้ำด้วยไฟล์เดิมจะได้เวอร์ชันเดิม
 * ผู้ใช้จึงไม่ต้องโหลดใหม่โดยไม่จำเป็น
 */
final class Asset
{
    /** @var array<string, string|null> */
    private static array $versions = [];

    public static function url(string $path): string
    {
        $url = asset($path);

        if (! array_key_exists($path, self::$versions)) {
            self::$versions[$path] = self::hash($path);
        }

        $version = self::$versions[$path];

        return $version === null ? $url : $url . '?v=' . $version;
    }

    private static function hash(string $path): ?string
    {
        $file = public_path($path);

        if (! is_file($file)) {
            return null;
        }

        $hash = md5_file($file);

        return $hash === false ? null : substr($hash, 0, 10);
    }
}
