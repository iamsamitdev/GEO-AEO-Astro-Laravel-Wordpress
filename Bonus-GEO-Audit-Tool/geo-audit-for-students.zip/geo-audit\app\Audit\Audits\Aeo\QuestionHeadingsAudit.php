<?php

namespace App\Audit\Audits\Aeo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Content\Heading;
use App\Audit\Support\Text;

/**
 * หัวข้อในหน้าเขียนในรูปคำถามที่คนถามจริงหรือเปล่า
 *
 * ผู้ใช้พิมพ์เข้า AI เป็นประโยคคำถามเต็ม ไม่ใช่คำค้นสั้น ๆ แบบยุค Google
 * หัวข้อที่เขียนว่า "ราคา" จึงจับคู่กับคำถามได้แย่กว่า "ค่าใช้จ่ายเริ่มต้นเท่าไร"
 *
 * ไม่ได้บังคับว่าทุกหัวข้อต้องเป็นคำถาม - หน้าที่มีสัดส่วนราวหนึ่งในสามก็เพียงพอ
 */
final class QuestionHeadingsAudit extends BaseAudit
{
    public function id(): string
    {
        return 'question-headings';
    }

    public function title(): string
    {
        return 'มีหัวข้อในรูปคำถามที่คนถามจริง';
    }

    public function category(): Category
    {
        return Category::Aeo;
    }

    public function weight(): float
    {
        return 2.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $headings = array_values(array_filter(
            $ctx->document->headings(),
            fn (Heading $h) => $h->level >= 2 && $h->level <= 3
        ));

        if (count($headings) < 2) {
            return $this->partial(
                0.3,
                'มีหัวข้อ h2/h3 น้อยกว่า 2 หัวข้อ',
                'ซอยเนื้อหาด้วย h2/h3 แล้วตั้งชื่อหัวข้อให้เป็นคำถามที่ผู้ใช้พิมพ์ถามจริง เช่น "ต่างจาก SEO อย่างไร" แทน "ความแตกต่าง"',
                ['จำนวน h2/h3: ' . count($headings)]
            );
        }

        $questions = array_values(array_filter($headings, fn (Heading $h) => Text::isQuestion($h->text)));
        $vague = array_values(array_filter($headings, fn (Heading $h) => Text::wordCount($h->text) <= 1 && ! Text::isQuestion($h->text)));

        $ratio = count($questions) / count($headings);

        $details = [
            'หัวข้อ h2/h3 ทั้งหมด: ' . count($headings),
            'ที่เป็นคำถาม: ' . count($questions),
        ];

        foreach (array_slice($questions, 0, 4) as $heading) {
            $details[] = 'คำถาม: ' . Text::truncate($heading->text, 70);
        }
        foreach (array_slice($vague, 0, 3) as $heading) {
            $details[] = 'หัวข้อกว้างเกินไป: ' . Text::truncate($heading->text, 40);
        }

        // ครบหนึ่งในสามถือว่าเต็ม เกินกว่านั้นไม่ได้ดีขึ้น (หน้าที่ทุกหัวข้อเป็นคำถามอ่านยาก)
        $score = min(1.0, $ratio / 0.34);

        if ($vague !== []) {
            $score -= min(0.2, count($vague) * 0.05);
        }

        if ($score >= 0.9) {
            return $this->pass(count($questions) . '/' . count($headings) . ' หัวข้อเป็นคำถาม', $details);
        }

        return $this->partial(
            max(0.0, $score),
            count($questions) . '/' . count($headings) . ' หัวข้อเป็นคำถาม',
            'เปลี่ยนหัวข้อสัก 1 ใน 3 ให้อยู่ในรูปคำถามเต็มประโยคที่ลูกค้าถามจริง ดูคำถามที่ได้จริงจากแชทฝ่ายขาย อีเมล หรือช่องค้นหาในเว็บ',
            $details
        );
    }
}
