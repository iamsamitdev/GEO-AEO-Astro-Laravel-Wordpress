<?php

namespace App\Audit\Audits\Aeo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\Text;

/**
 * หน้ามีข้อเท็จจริงที่หยิบไปอ้างได้ หรือมีแต่ข้อความลอย ๆ
 *
 * เนื้อหาที่ถูกอ้างอิงบ่อยมีลักษณะร่วมกันคือ "มีของให้หยิบ":
 * ตัวเลขที่เจาะจง ตาราง รายการเป็นข้อ ๆ และการอ้างอิงแหล่งที่มา
 *
 * ประโยคว่า "ช่วยเพิ่มยอดขายได้อย่างมาก" ไม่มีอะไรให้หยิบ
 * ส่วน "เพิ่มยอดขาย 34% ใน 6 เดือน" หยิบไปตอบได้ทันที
 */
final class ExtractableFactsAudit extends BaseAudit
{
    public function id(): string
    {
        return 'extractable-facts';
    }

    public function title(): string
    {
        return 'มีตัวเลข รายการ และตารางที่หยิบไปอ้างได้';
    }

    public function category(): Category
    {
        return Category::Aeo;
    }

    public function weight(): float
    {
        return 2.0;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $doc = $ctx->document;
        $text = $doc->mainText();
        $words = Text::wordCount($text);

        if ($words < 80) {
            return $this->na('เนื้อหาน้อยเกินกว่าจะประเมิน');
        }

        $stats = Text::countStats($text);
        $tables = $doc->countTag('table');
        $listItems = 0;
        foreach ($doc->sections() as $section) {
            $listItems += $section->listItems;
        }

        $externalCitations = 0;
        foreach ($doc->links() as $link) {
            if ($ctx->isExternalLink($link['href']) && ! str_contains($link['rel'], 'nofollow')) {
                $externalCitations++;
            }
        }

        // ความหนาแน่นของตัวเลขต่อ 100 คำ - 1.5 ขึ้นไปถือว่าเนื้อหามีของ
        $statDensity = $stats / max(1, $words / 100);

        $details = [
            "จำนวนคำในเนื้อหา: {$words}",
            "ตัวเลข/สถิติที่พบ: {$stats} จุด (ความหนาแน่น " . round($statDensity, 2) . ' ต่อ 100 คำ)',
            "รายการเป็นข้อ: {$listItems} ข้อ",
            "ตาราง: {$tables}",
            "ลิงก์อ้างอิงออกนอกเว็บ: {$externalCitations}",
        ];

        $score = 0.0;

        // สถิติ - ให้น้ำหนักมากที่สุด เพราะเป็นสัญญาณที่ชัดที่สุดว่าเนื้อหามีเนื้อ
        $score += min(0.4, $statDensity / 1.5 * 0.4);

        // รายการหรือตาราง
        $hasStructure = $listItems >= 3 || $tables >= 1;
        $score += $hasStructure ? 0.3 : ($listItems > 0 ? 0.12 : 0.0);

        // การอ้างอิงแหล่งที่มา
        $score += min(0.3, $externalCitations * 0.1);

        $missing = [];
        if ($statDensity < 0.7) {
            $missing[] = 'ตัวเลขที่เจาะจงน้อย';
        }
        if (! $hasStructure) {
            $missing[] = 'ไม่มีรายการหรือตาราง';
        }
        if ($externalCitations === 0) {
            $missing[] = 'ไม่อ้างอิงแหล่งภายนอกเลย';
        }

        if ($score >= 0.9) {
            return $this->pass("{$stats} ตัวเลข · {$listItems} รายการ · {$tables} ตาราง", $details);
        }

        return $this->partial(
            $score,
            implode(' · ', $missing ?: ['มีของให้หยิบไม่มากพอ']),
            'แทนคำขยายด้วยตัวเลขจริง (ระยะเวลา ราคา สัดส่วน จำนวน) แปลงย่อหน้าเปรียบเทียบเป็นตาราง แปลงขั้นตอนเป็นรายการเรียงข้อ และอ้างอิงแหล่งที่มาของตัวเลขทุกครั้งด้วยลิงก์ออกนอกเว็บ',
            $details
        );
    }
}
