<?php

namespace App\Audit;

use App\Audit\Contracts\Audit;

abstract class BaseAudit implements Audit
{
    public function weight(): float
    {
        return 1.0;
    }

    protected function result(
        ?float $score,
        string $displayValue = '',
        array $details = [],
        string $fix = '',
        bool $byAi = false,
    ): AuditResult {
        return new AuditResult(
            id: $this->id(),
            title: $this->title(),
            category: $this->category(),
            weight: $this->weight(),
            score: $score === null ? null : max(0.0, min(1.0, $score)),
            displayValue: $displayValue,
            details: array_values(array_filter($details, fn ($d) => $d !== '' && $d !== null)),
            fix: $fix,
            byAi: $byAi,
        );
    }

    protected function pass(string $displayValue = '', array $details = []): AuditResult
    {
        return $this->result(1.0, $displayValue, $details);
    }

    protected function fail(string $displayValue, string $fix, array $details = []): AuditResult
    {
        return $this->result(0.0, $displayValue, $details, $fix);
    }

    protected function partial(float $score, string $displayValue, string $fix, array $details = []): AuditResult
    {
        return $this->result($score, $displayValue, $details, $fix);
    }

    protected function na(string $why): AuditResult
    {
        return $this->result(null, $why);
    }

    /**
     * ให้คะแนนแบบสัดส่วน ok/total แต่ไม่ปัดขึ้นเป็น 1 ถ้ายังไม่ครบจริง
     */
    protected function ratio(int $ok, int $total): float
    {
        return $total === 0 ? 1.0 : $ok / $total;
    }
}
