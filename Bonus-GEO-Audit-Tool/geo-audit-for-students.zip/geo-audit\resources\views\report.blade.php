@extends('layouts.app')

@section('title', 'ผลตรวจ ' . \Illuminate\Support\Str::limit(\App\Audit\Support\Url::forDisplay($report->target), 60) . ' - GEO Audit')
@section('robots', 'noindex, follow')

@php
    $verdictClass = fn (?int $score) => $score === null
        ? 'v-na'
        : ($score >= 90 ? 'v-pass' : ($score >= 50 ? 'v-average' : 'v-fail'));
@endphp

@section('content')
<div class="wrap">

@if ($report->status === 'failed')
    <div class="card" style="margin-top:32px">
        <h2>ตรวจไม่สำเร็จ</h2>
        <p class="sub url-text">{{ \App\Audit\Support\Url::forDisplay($report->target) }}</p>
        <div class="errors">{{ $report->error ?: 'ไม่ทราบสาเหตุ' }}</div>
        <a class="btn secondary" href="{{ route('home') }}">กลับไปตรวจใหม่</a>
    </div>

@elseif (! $report->isFinished())
    <div class="card" style="margin-top:32px" id="progress-card">
        <h2><span class="spinner"></span> {{ $report->statusLabel() }}</h2>
        <p class="sub url-text">{{ \App\Audit\Support\Url::forDisplay($report->target) }}</p>

        <div class="progress">
            <i style="width: {{ $report->pages_total > 0 ? max(4, (int) round($report->pages_done / $report->pages_total * 100)) : 6 }}%"></i>
        </div>
        <p class="running-note" id="progress-text">
            @if ($report->pages_total > 1)
                ตรวจแล้ว {{ $report->pages_done }} จาก {{ $report->pages_total }} หน้า
            @else
                กำลังดึงหน้าเว็บและไฟล์ประกอบ (robots.txt, sitemap.xml, llms.txt)
            @endif
        </p>

        <div class="notice" style="margin-top:18px">
            หน้านี้จะรีเฟรชผลให้เองเมื่อตรวจเสร็จ เก็บลิงก์นี้ไว้เปิดทีหลังได้
            @if ($report->mode === 'site')
                <br>การตรวจทั้งเว็บมีการหน่วงระหว่างหน้าเพื่อไม่ให้ยิงเว็บปลายทางถี่เกินไป จึงใช้เวลาหลายนาที
            @endif
        </div>
    </div>

@else
    @php($isSite = $report->pages->count() > 1)

    @if ($report->isPerfect())
        {{-- จุดพลุเมื่อได้คะแนนเต็ม - สคริปต์โหลดเฉพาะหน้าที่ได้ 100 หน้าอื่นไม่ต้องโหลดอะไรเพิ่ม --}}
        <div data-celebrate hidden></div>
        @push('scripts')
            <script src="{{ \App\Support\Asset::url('js/celebrate.js') }}" defer></script>
        @endpush
    @endif

    <div class="card" style="margin-top:32px">
        <div class="score-hero">
            <div class="gauge {{ $verdictClass($report->score) }}" style="--value: {{ $report->score ?? 0 }}">
                <div class="gauge-num">{{ $report->score ?? '-' }}</div>
                <div class="gauge-den">/ 100</div>
            </div>

            <div class="score-meta">
                <h1 class="url-text">{{ \Illuminate\Support\Str::limit(\App\Audit\Support\Url::forDisplay($report->target), 90) }}</h1>
                <p class="grade {{ $verdictClass($report->score) }}" style="margin:0;color:var(--gauge-color)">
                    {{ \App\Audit\PageReport::grade((int) $report->score) }}
                </p>
                <dl>
                    <div><dt>รูปแบบ</dt><dd>{{ $report->modeLabel() }}</dd></div>
                    <div><dt>จำนวนหน้า</dt><dd>{{ $report->pages->count() }}</dd></div>
                    @if (! $isSite && $page)
                        <div>
                            <dt>ประเภทหน้า</dt>
                            <dd>
                                {{ $page->pageTypeLabel() }}
                                <span style="font-weight:400;color:var(--text-faint)">
                                    ({{ $page->pageTypeDeclared() ? 'คุณระบุเอง' : 'ระบบเดาให้' }})
                                </span>
                            </dd>
                        </div>
                        @if ($report->mode !== 'upload' && $report->mode !== 'files')
                            <div><dt>เวลาตอบ</dt><dd>{{ $page->load_ms }} ms</dd></div>
                        @endif
                    @endif
                    <div><dt>ตรวจเมื่อ</dt><dd>{{ $report->createdAtLocal()->format('d/m/Y H:i') }} น.</dd></div>
                </dl>
                <div class="hero-actions">
                    {{-- download บอกเบราว์เซอร์ให้บันทึกไฟล์ คู่กับ Content-Disposition: attachment ฝั่งเซิร์ฟเวอร์ --}}
                    <a class="btn secondary" href="{{ route('reports.json', $report) }}" download>
                        ดาวน์โหลดผลเป็น JSON
                    </a>
                    @if ($report->isPerfect())
                        <button type="button" class="btn secondary" data-celebrate-replay>
                            ฉลองอีกครั้ง
                        </button>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <h2>คะแนนรายหมวด</h2>
        <p class="sub">{{ $isSite ? 'ค่าเฉลี่ยของทุกหน้าที่ตรวจ' : 'ถ่วงน้ำหนักตามผลกระทบต่อการถูก AI อ้างอิง' }}</p>

        <div class="categories">
            @php($averages = $report->categoryAverages())
            @foreach (\App\Audit\Category::ordered() as $category)
                @php($value = $averages[$category->value] ?? null)
                <div class="cat-row {{ $verdictClass($value) }}">
                    <div class="cat-name">
                        {{ $category->label() }}
                        <span class="cat-weight">น้ำหนัก {{ (int) $category->weight() }}</span>
                    </div>
                    <div class="cat-score" style="color:var(--gauge-color)">{{ $value ?? '-' }}</div>
                    <div class="bar"><i style="width: {{ $value ?? 0 }}%"></i></div>
                    <div class="cat-desc">{{ $category->description() }}</div>
                </div>
            @endforeach
        </div>
    </div>

    @if ($isSite)
        @php($issues = $report->recurringIssues())
        @if ($issues !== [])
            <div class="card">
                <h2>ปัญหาที่เกิดซ้ำหลายหน้า</h2>
                <p class="sub">แก้ที่เทมเพลตครั้งเดียว จะได้คะแนนคืนทุกหน้าพร้อมกัน</p>
                <ol class="priority">
                    @foreach ($issues as $issue)
                        <li class="{{ $issue['worst'] < 0.5 ? 'v-fail' : 'v-average' }}">
                            <div class="p-title">{{ $issue['title'] }}</div>
                            <div class="p-value">พบใน {{ $issue['pages'] }} จาก {{ $report->pages->count() }} หน้า</div>
                            @if ($issue['fix'])
                                <div class="p-fix">{{ $issue['fix'] }}</div>
                            @endif
                        </li>
                    @endforeach
                </ol>
            </div>
        @endif

        <div class="card">
            <h2>หน้าที่ตรวจทั้งหมด</h2>
            <p class="sub">เรียงตามคะแนนจากน้อยไปมาก - หน้าบนสุดคือหน้าที่ควรแก้ก่อน</p>
            <div class="table-scroll">
                <table class="page-table">
                    <thead>
                        <tr>
                            <th>คะแนน</th>
                            <th>URL</th>
                            <th>ประเภท</th>
                            <th class="num">ตอบใน</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($report->pages->sortBy(fn ($p) => $p->score ?? -1) as $row)
                            <tr>
                                <td><span class="pill {{ $verdictClass($row->score) }}">{{ $row->score ?? '!' }}</span></td>
                                <td class="url">
                                    <a href="{{ $row->url }}" target="_blank" rel="noopener nofollow">{{ \Illuminate\Support\Str::limit(\App\Audit\Support\Url::forDisplay($row->url), 90) }}</a>
                                    @if ($row->error)
                                        <br><span style="color:var(--fail);font-size:12.5px">{{ $row->error }}</span>
                                    @endif
                                </td>
                                <td>{{ $row->pageTypeLabel() }}</td>
                                <td class="num">{{ $row->load_ms }} ms</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        @php($worst = $report->pages->filter(fn ($p) => $p->score !== null)->sortBy('score')->first())
        @if ($worst)
            <div class="card">
                <h2>รายละเอียดของหน้าที่คะแนนต่ำที่สุด</h2>
                <p class="sub url-text">{{ \App\Audit\Support\Url::forDisplay($worst->url) }}</p>
                @include('partials.audits', ['page' => $worst])
            </div>
        @endif

    @elseif ($page)
        @php($opportunities = $page->opportunities())
        @if ($opportunities !== [])
            <div class="card">
                <h2>ควรแก้ก่อน</h2>
                <p class="sub">เรียงตามคะแนนที่จะได้คืนมากที่สุด</p>
                <ol class="priority">
                    @foreach ($opportunities as $item)
                        <li class="v-{{ $item['verdict'] }}">
                            <div class="p-title">{{ $item['title'] }}</div>
                            <div class="p-value">{{ $item['displayValue'] }}</div>
                            @if (!empty($item['fix']))
                                <div class="p-fix">{{ $item['fix'] }}</div>
                            @endif
                        </li>
                    @endforeach
                </ol>
            </div>
        @endif

        <div class="card">
            <h2>ผลตรวจทั้งหมด</h2>
            <p class="sub">กดที่แต่ละข้อเพื่อดูหลักฐานที่ทำให้ได้คะแนนนั้น หรือกดปุ่มด้านล่างเพื่อกรองเฉพาะประเภทที่สนใจ</p>

            @include('partials.audits', ['page' => $page])
        </div>
    @endif

    <div class="card">
        <div class="notice">
            <strong>อ่านคะแนนนี้อย่างไร:</strong>
            ไม่มีใครรู้สูตรจริงที่ ChatGPT หรือ Gemini ใช้เลือกว่าจะอ้างอิงหน้าไหน
            คะแนนนี้จึงเป็นการวัดว่าเว็บทำตามแนวปฏิบัติที่ควบคุมได้ครบแค่ไหน ไม่ใช่การทำนายว่าจะถูกอ้างอิงจริง
            ให้ใช้คู่กับการดู log ว่าบอทเข้ามาจริงหรือไม่
            <a href="{{ route('about') }}">ดูเกณฑ์และน้ำหนักทั้งหมด</a>
        </div>
    </div>
@endif

</div>

@push('scripts')
<script>
    /*
        กรองรายการ audit ตามผล (ผ่าน / ต้องดู / ตก / ไม่เกี่ยวข้อง)

        ปุ่มกรองถูกซ่อนไว้ใน HTML แล้วเปิดตรงนี้ ถ้าสคริปต์ไม่ทำงาน
        ผู้ใช้จะเห็นรายการครบทุกข้อ ไม่ใช่ปุ่มที่กดแล้วไม่มีอะไรเกิดขึ้น

        ทำงานแยกกันต่อ [data-audit-list] เผื่อหน้าหนึ่งมีรายการมากกว่าหนึ่งชุด
    */
    document.querySelectorAll('[data-audit-list]').forEach(function (list) {
        var bar = list.querySelector('.verdict-filter');
        if (!bar) return;

        bar.hidden = false;

        var chips = Array.prototype.slice.call(bar.querySelectorAll('.chip'));
        var audits = Array.prototype.slice.call(list.querySelectorAll('details.audit'));
        var groups = Array.prototype.slice.call(list.querySelectorAll('.audit-group'));

        function apply(verdict) {
            audits.forEach(function (item) {
                var show = verdict === 'all' || item.dataset.verdict === verdict;
                item.hidden = !show;

                // กรองไปที่ข้อที่มีปัญหา = ตั้งใจจะอ่านว่าต้องแก้อะไร กางให้เลยจะได้ไม่ต้องกดทีละอัน
                if (show && (verdict === 'fail' || verdict === 'average')) {
                    item.open = true;
                }
            });

            groups.forEach(function (group) {
                group.hidden = group.querySelectorAll('details.audit:not([hidden])').length === 0;
            });

            chips.forEach(function (chip) {
                var on = chip.dataset.verdict === verdict;
                chip.classList.toggle('is-active', on);
                chip.setAttribute('aria-pressed', on ? 'true' : 'false');
            });
        }

        chips.forEach(function (chip) {
            chip.addEventListener('click', function () {
                // กดปุ่มเดิมซ้ำ = ยกเลิกการกรอง
                var next = chip.classList.contains('is-active') ? 'all' : chip.dataset.verdict;
                apply(next);
            });
        });
    });
</script>
@endpush

@if (! $report->isFinished())
@push('scripts')
<script>
    (function () {
        var url = @json(route('reports.status', $report));
        var tries = 0;

        function poll() {
            tries++;
            fetch(url, { headers: { 'Accept': 'application/json' } })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.finished) {
                        window.location.reload();
                        return;
                    }

                    var text = document.getElementById('progress-text');
                    var bar = document.querySelector('.progress i');
                    if (data.pagesTotal > 1 && text) {
                        text.textContent = 'ตรวจแล้ว ' + data.pagesDone + ' จาก ' + data.pagesTotal + ' หน้า';
                    }
                    if (bar && data.pagesTotal > 0) {
                        bar.style.width = Math.max(4, Math.round(data.pagesDone / data.pagesTotal * 100)) + '%';
                    }

                    // ถามถี่ตอนแรกแล้วค่อย ๆ ห่างออก งานที่ยาวจะได้ไม่ยิงถี่โดยเปล่าประโยชน์
                    setTimeout(poll, Math.min(2000 + tries * 400, 8000));
                })
                .catch(function () {
                    setTimeout(poll, 6000);
                });
        }

        setTimeout(poll, 1500);
    })();
</script>
@endpush
@endif
@endsection
