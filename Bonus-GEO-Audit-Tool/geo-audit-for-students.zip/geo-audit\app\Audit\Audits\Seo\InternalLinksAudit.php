<?php

namespace App\Audit\Audits\Seo;

use App\Audit\AuditContext;
use App\Audit\AuditResult;
use App\Audit\BaseAudit;
use App\Audit\Category;
use App\Audit\Support\Text;

/**
 * ลิงก์ภายในมีพอ และข้อความลิงก์บอกได้ว่าปลายทางคืออะไร
 *
 * ข้อความลิงก์คือคำอธิบายสั้น ๆ ของหน้าปลายทางที่เขียนโดยหน้าอื่น
 * "คลิกที่นี่" จึงเป็นการทิ้งโอกาสอธิบายไปเปล่า ๆ ทั้งกับคนและกับเครื่อง
 */
final class InternalLinksAudit extends BaseAudit
{
    private const VAGUE_ANCHORS = [
        'คลิกที่นี่', 'ที่นี่', 'อ่านต่อ', 'ดูเพิ่มเติม', 'เพิ่มเติม', 'รายละเอียด', 'ลิงก์',
        'click here', 'here', 'read more', 'learn more', 'more', 'this link', 'link',
    ];

    public function id(): string
    {
        return 'internal-links';
    }

    public function title(): string
    {
        return 'ลิงก์ภายในเพียงพอและข้อความลิงก์สื่อความ';
    }

    public function category(): Category
    {
        return Category::Seo;
    }

    public function weight(): float
    {
        return 1.5;
    }

    public function run(AuditContext $ctx): AuditResult
    {
        $internal = [];
        $external = 0;

        foreach ($ctx->document->links() as $link) {
            $href = $link['href'];

            if ($href === '' || str_starts_with($href, '#') || str_starts_with($href, 'mailto:')
                || str_starts_with($href, 'tel:') || str_starts_with($href, 'javascript:')) {
                continue;
            }

            if ($ctx->isExternalLink($href)) {
                $external++;

                continue;
            }

            $internal[] = $link;
        }

        $unique = count(array_unique(array_map(fn ($l) => $ctx->absolute($l['href']), $internal)));

        $vague = [];
        $empty = 0;
        foreach ($internal as $link) {
            $text = mb_strtolower(trim($link['text']), 'UTF-8');

            if ($text === '') {
                $empty++;

                continue;
            }

            if (in_array($text, array_map(fn ($a) => mb_strtolower($a, 'UTF-8'), self::VAGUE_ANCHORS), true)) {
                $vague[] = $link['text'];
            }
        }

        $details = [
            'ลิงก์ภายใน: ' . count($internal) . " (ปลายทางไม่ซ้ำ {$unique})",
            "ลิงก์ออกนอกเว็บ: {$external}",
            'ข้อความลิงก์ที่กว้างเกินไป: ' . count($vague),
        ];

        if ($empty > 0) {
            $details[] = "ลิงก์ที่ไม่มีข้อความเลย (เช่น ไอคอนล้วน): {$empty}";
        }
        foreach (array_slice(array_unique($vague), 0, 4) as $anchor) {
            $details[] = 'ข้อความลิงก์: ' . Text::truncate($anchor, 30);
        }

        $score = 1.0;
        $issues = [];

        if ($unique === 0) {
            return $this->fail(
                'ไม่มีลิงก์ภายในเลย',
                'ลิงก์ไปหน้าที่เกี่ยวข้องอย่างน้อย 3-5 จุดในเนื้อหา โดยใช้ชื่อหัวข้อปลายทางเป็นข้อความลิงก์ - นี่คือวิธีที่บอทเดินสำรวจเว็บและเข้าใจว่าหน้าไหนเกี่ยวกับอะไร',
                $details
            );
        }

        if ($unique < 3) {
            $score -= 0.35;
            $issues[] = "ลิงก์ภายในน้อย ({$unique} ปลายทาง)";
        }

        if ($vague !== []) {
            $score -= min(0.35, count($vague) * 0.08);
            $issues[] = count($vague) . ' ลิงก์ใช้ข้อความกว้างเกินไป';
        }

        if ($empty > 2) {
            $score -= 0.1;
            $issues[] = "{$empty} ลิงก์ไม่มีข้อความ";
        }

        if ($issues === []) {
            return $this->pass("{$unique} ปลายทางภายใน · ข้อความลิงก์ใช้ได้", $details);
        }

        return $this->partial(
            max(0.0, $score),
            implode(' · ', $issues),
            'เปลี่ยนข้อความลิงก์ให้เป็นชื่อเรื่องของหน้าปลายทาง เช่น จาก "อ่านต่อ" เป็น "วิธีติดตั้ง Schema ด้วย Rank Math" และเชื่อมหน้าที่เกี่ยวข้องกันเป็นกลุ่มหัวข้อ',
            $details
        );
    }
}
