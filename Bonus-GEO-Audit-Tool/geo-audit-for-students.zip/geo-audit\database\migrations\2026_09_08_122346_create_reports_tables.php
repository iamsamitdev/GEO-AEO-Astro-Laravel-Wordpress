<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('reports', function (Blueprint $table) {
            $table->id();
            // ใช้ ulid เป็นตัวชี้ในลิงก์ที่แชร์ได้ ไม่เปิดเผยจำนวนรายงานทั้งระบบเหมือน id ที่ไล่เลข
            $table->ulid('ulid')->unique();
            $table->string('mode', 16);            // url | site | upload
            $table->string('target', 2048);
            $table->string('label')->nullable();
            $table->string('status', 16)->default('queued'); // queued | running | done | failed
            $table->boolean('use_ai')->default(false);
            $table->unsignedTinyInteger('score')->nullable();
            $table->unsignedSmallInteger('pages_done')->default(0);
            $table->unsignedSmallInteger('pages_total')->default(0);
            $table->text('error')->nullable();
            // เก็บ hash ไม่เก็บ IP ตรง ๆ - พอสำหรับจำกัดจำนวนครั้ง แต่ไม่ได้สะสมข้อมูลผู้ใช้
            $table->string('requester_hash', 64)->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('finished_at')->nullable();
            $table->timestamps();

            $table->index(['status', 'created_at']);
            $table->index('requester_hash');
        });

        Schema::create('page_results', function (Blueprint $table) {
            $table->id();
            $table->foreignId('report_id')->constrained()->cascadeOnDelete();
            $table->unsignedSmallInteger('position')->default(0);
            $table->string('url', 2048);
            $table->string('page_type', 32)->nullable();
            $table->unsignedTinyInteger('score')->nullable();
            $table->unsignedSmallInteger('http_status')->nullable();
            $table->unsignedInteger('load_ms')->nullable();
            $table->unsignedInteger('bytes')->nullable();
            $table->text('error')->nullable();
            // ผลของ audit ทุกข้อ เก็บเป็นก้อนเดียว - ไม่ต้อง query รายข้อ จึงไม่ต้องแตกตาราง
            $table->json('payload')->nullable();
            $table->timestamps();

            $table->index(['report_id', 'position']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('page_results');
        Schema::dropIfExists('reports');
    }
};
