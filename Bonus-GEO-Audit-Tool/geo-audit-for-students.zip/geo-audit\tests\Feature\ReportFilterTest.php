<?php

namespace Tests\Feature;

use App\Models\PageResult;
use App\Models\Report;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * ปุ่มกรองผลตรวจตามประเภท
 *
 * ตัวการกรองทำงานด้วย JavaScript ซึ่งเทสฝั่ง PHP ตรวจไม่ได้
 * แต่สิ่งที่ JS พึ่งพาคือ "สัญญา" ใน HTML: ปุ่มต้องมี data-verdict
 * และทุกรายการต้องมี data-verdict ติดอยู่ ถ้าใครแก้ Blade แล้วลบ attribute เหล่านี้
 * ปุ่มจะยังขึ้นแต่กดแล้วไม่มีอะไรเกิดขึ้น เทสนี้จึงล็อกสัญญาส่วนนั้นไว้
 */
class ReportFilterTest extends TestCase
{
    use RefreshDatabase;

    public function test_ปุ่มกรองแสดงจำนวนของแต่ละประเภทถูกต้อง(): void
    {
        $report = $this->reportWithVerdicts(['pass', 'pass', 'pass', 'average', 'fail']);

        $html = $this->get(route('reports.show', $report))->assertOk()->getContent();

        $this->assertStringContainsString('<b>5</b> ทั้งหมด', $this->squash($html));
        $this->assertStringContainsString('<b>3</b> ผ่าน', $this->squash($html));
        $this->assertStringContainsString('<b>1</b> ต้องดู', $this->squash($html));
        $this->assertStringContainsString('<b>1</b> ตก', $this->squash($html));
    }

    public function test_ประเภทที่ไม่มีรายการจะกดไม่ได้(): void
    {
        $report = $this->reportWithVerdicts(['pass', 'fail']);

        $html = $this->squash($this->get(route('reports.show', $report))->getContent());

        // ไม่มีข้อไหนเป็น na จึงต้องถูก disabled ไม่ใช่ปล่อยให้กดแล้วได้หน้าว่าง
        $this->assertMatchesRegularExpression(
            '/data-verdict="na"[^>]*disabled/',
            $html,
            'ปุ่มประเภทที่นับได้ 0 ต้องถูก disabled'
        );
        $this->assertDoesNotMatchRegularExpression('/data-verdict="pass"[^>]*disabled/', $html);
    }

    public function test_ทุกรายการมี_data_verdict_ให้สคริปต์ใช้กรอง(): void
    {
        $report = $this->reportWithVerdicts(['pass', 'average', 'fail', 'na']);

        $html = $this->get(route('reports.show', $report))->getContent();

        preg_match_all('/<details class="audit v-(\w+)" data-verdict="(\w+)"/', $html, $m, PREG_SET_ORDER);

        $this->assertCount(4, $m, 'ทุก <details class="audit"> ต้องมี data-verdict');
        foreach ($m as $match) {
            $this->assertSame($match[1], $match[2], 'คลาส v-* กับ data-verdict ต้องตรงกัน');
        }
    }

    public function test_แถบกรองถูกซ่อนไว้ใน_html_แล้วให้สคริปต์เปิด(): void
    {
        $report = $this->reportWithVerdicts(['pass']);

        $html = $this->squash($this->get(route('reports.show', $report))->getContent());

        // ซ่อนไว้ก่อนเพื่อไม่ให้คนที่ JS ไม่ทำงานเห็นปุ่มที่กดแล้วเงียบ
        $this->assertStringContainsString('class="verdict-filter" role="group" aria-label="กรองผลตรวจตามประเภท" hidden', $html);
        $this->assertStringContainsString('data-audit-list', $html);
    }

    /** @param list<string> $verdicts */
    private function reportWithVerdicts(array $verdicts): Report
    {
        $report = Report::create([
            'mode' => 'url',
            'target' => 'https://example.com/page',
            'status' => 'done',
            'score' => 70,
        ]);

        $audits = [];
        foreach ($verdicts as $index => $verdict) {
            $audits[] = [
                'id' => 'audit-' . $index,
                'title' => 'ข้อตรวจที่ ' . ($index + 1),
                'category' => 'seo',
                'weight' => 1.0,
                'score' => $verdict === 'na' ? null : 0.5,
                'verdict' => $verdict,
                'displayValue' => '',
                'details' => [],
                'fix' => '',
                'byAi' => false,
            ];
        }

        PageResult::create([
            'report_id' => $report->id,
            'position' => 0,
            'url' => 'https://example.com/page',
            'page_type' => 'other',
            'score' => 70,
            'http_status' => 200,
            'load_ms' => 100,
            'bytes' => 1024,
            'payload' => [
                'url' => 'https://example.com/page',
                'pageTypeLabel' => 'หน้าทั่วไป',
                'score' => 70,
                'categories' => ['seo' => ['label' => 'On-Page SEO', 'weight' => 20, 'score' => 70]],
                'audits' => $audits,
            ],
        ]);

        return $report->fresh();
    }

    /** ยุบช่องว่างและการขึ้นบรรทัดใน HTML ให้เทียบสตริงได้โดยไม่ผูกกับการจัดรูปแบบใน Blade */
    private function squash(string $html): string
    {
        return preg_replace('/\s+/u', ' ', $html) ?? $html;
    }
}
