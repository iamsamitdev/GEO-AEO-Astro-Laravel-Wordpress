<?php

namespace Tests\Feature;

use App\Models\Report;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Tests\TestCase;

/**
 * เวลาที่แสดงต้องเป็นเวลาไทย ขณะที่ฐานข้อมูลยังเก็บเป็น UTC
 *
 * เคยผิดจริงบน production: สั่งตรวจตอน 17:18 น. แต่หน้ารายงานขึ้น 10:18
 * เพราะใส่ APP_TIMEZONE ไว้ใน .env ซึ่ง config/app.php ของ Laravel 13 ไม่ได้อ่าน
 * แอปจึงยังเป็น UTC แล้วหน้าเว็บ format created_at ออกมาตรง ๆ
 */
class ReportTimezoneTest extends TestCase
{
    use RefreshDatabase;

    protected function tearDown(): void
    {
        Carbon::setTestNow();
        parent::tearDown();
    }

    public function test_ฐานข้อมูลเก็บเป็น_utc(): void
    {
        $this->assertSame('UTC', config('app.timezone'), 'ห้ามเปลี่ยน app.timezone ไม่งั้นรายงานเก่าจะเพี้ยน 7 ชั่วโมง');

        $report = $this->reportCreatedAt('2026-09-12 10:18:48');

        $this->assertSame('2026-09-12 10:18:48', $report->getRawOriginal('created_at'));
    }

    public function test_หน้ารายงานแสดงเวลาไทย(): void
    {
        $report = $this->reportCreatedAt('2026-09-12 10:18:48');

        $html = $this->get(route('reports.show', $report))->assertOk()->getContent();

        $this->assertStringContainsString('12/09/2026 17:18', $html);
        $this->assertStringNotContainsString('12/09/2026 10:18', $html);
    }

    public function test_ข้ามวันตามเวลาไทยได้ถูกต้อง(): void
    {
        // 20:30 UTC ของวันที่ 12 คือ 03:30 น. ของวันที่ 13 ตามเวลาไทย
        $report = $this->reportCreatedAt('2026-09-12 20:30:00');

        $html = $this->get(route('reports.show', $report))->getContent();

        $this->assertStringContainsString('13/09/2026 03:30', $html);
    }

    public function test_json_และชื่อไฟล์ใช้เวลาไทย(): void
    {
        $report = $this->reportCreatedAt('2026-09-12 10:18:48');

        $response = $this->get(route('reports.json', $report));

        $this->assertStringContainsString('-20260912-1718.json', $response->headers->get('Content-Disposition'));
        $this->assertSame('2026-09-12T17:18:48+07:00', json_decode($response->getContent(), true)['createdAt']);
    }

    private function reportCreatedAt(string $utc): Report
    {
        Carbon::setTestNow(Carbon::parse($utc, 'UTC'));

        $report = Report::create([
            'mode' => 'url',
            'target' => 'https://www.itgenius.co.th/',
            'status' => 'done',
            'score' => 82,
        ]);

        Carbon::setTestNow();

        return $report->fresh();
    }
}
