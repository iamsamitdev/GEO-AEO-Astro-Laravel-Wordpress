<?php

namespace App\Audit;

use App\Audit\Http\FetchedResponse;
use App\Audit\Http\Fetcher;
use App\Audit\Support\RobotsTxt;
use App\Audit\Support\Sitemap;

/**
 * สิ่งที่เป็นของ "ทั้งโดเมน" ไม่ใช่ของหน้าใดหน้าหนึ่ง
 *
 * ดึงครั้งเดียวต่อ origin แล้วใช้ซ้ำทุกหน้าตอน crawl ทั้งเว็บ
 * จะได้ไม่ยิง robots.txt กับ sitemap.xml ซ้ำทุกหน้า
 */
final class SiteContext
{
    private function __construct(
        public readonly string $origin,
        public readonly RobotsTxt $robots,
        public readonly ?FetchedResponse $sitemapResponse,
        public readonly Sitemap $sitemap,
        public readonly ?string $sitemapUrl,
        public readonly ?FetchedResponse $llmsTxt,
        public readonly ?FetchedResponse $llmsFullTxt,
    ) {}

    /**
     * @param  string|null  $lookFor  URL ที่อยากได้ entry ใน sitemap ของมันโดยเฉพาะ
     */
    public static function forUrl(string $url, Fetcher $fetcher, ?string $lookFor = null): self
    {
        $parts = parse_url($url);
        $origin = ($parts['scheme'] ?? 'https') . '://' . ($parts['host'] ?? '')
            . (isset($parts['port']) ? ':' . $parts['port'] : '');

        $robotsResponse = $fetcher->get($origin . '/robots.txt');
        $robots = $robotsResponse->ok() && str_contains($robotsResponse->contentType(), 'text')
            ? RobotsTxt::parse($robotsResponse->body)
            : RobotsTxt::missing();

        [$sitemapResponse, $sitemap, $sitemapUrl] = self::loadSitemap(
            $fetcher,
            $robots->sitemaps !== [] ? $robots->sitemaps : [$origin . '/sitemap.xml'],
            $lookFor ?? $url
        );

        return new self(
            origin: $origin,
            robots: $robots,
            sitemapResponse: $sitemapResponse,
            sitemap: $sitemap,
            sitemapUrl: $sitemapUrl,
            llmsTxt: $fetcher->get($origin . '/llms.txt'),
            llmsFullTxt: $fetcher->get($origin . '/llms-full.txt'),
        );
    }

    /** context ว่างสำหรับโหมดตรวจไฟล์ในเครื่อง (ไม่มีโดเมนให้ยิง) */
    public static function offline(string $origin = ''): self
    {
        return new self($origin, RobotsTxt::missing(), null, Sitemap::invalid(), null, null, null);
    }

    public function hasSitemap(): bool
    {
        return $this->sitemap->valid;
    }

    public function declaredSitemapInRobots(): bool
    {
        return $this->robots->sitemaps !== [];
    }

    /** entry ของหน้าที่กำลังตรวจ ถ้าอยู่ใน sitemap */
    public function sitemapEntryForAuditedUrl(): ?array
    {
        return $this->sitemap->matchedEntry;
    }

    /**
     * URL ที่ใช้เป็นจุดตั้งต้นตอน crawl ทั้งเว็บ
     *
     * @return list<string>
     */
    public function crawlSeeds(int $limit): array
    {
        $seeds = array_column($this->sitemap->entries, 'loc');

        return array_slice(array_values(array_unique($seeds)), 0, $limit);
    }

    public function hasLlmsTxt(): bool
    {
        if ($this->llmsTxt === null || ! $this->llmsTxt->ok()) {
            return false;
        }

        $type = $this->llmsTxt->contentType();

        return str_contains($type, 'text')
            && ! str_contains($type, 'html')
            && trim($this->llmsTxt->body) !== '';
    }

    /**
     * ลองที่อยู่ sitemap ทีละอันจนกว่าจะอ่านได้
     *
     * @param  list<string>  $candidates
     * @return array{0: ?FetchedResponse, 1: Sitemap, 2: ?string}
     */
    private static function loadSitemap(Fetcher $fetcher, array $candidates, string $lookFor): array
    {
        $lastResponse = null;

        foreach (array_slice($candidates, 0, 3) as $candidate) {
            $response = $fetcher->get($candidate, Fetcher::MAX_XML_BYTES);
            $lastResponse ??= $response;

            if (! $response->ok()) {
                continue;
            }

            $sitemap = Sitemap::parse($response->body, $lookFor);

            if (! $sitemap->valid) {
                continue;
            }

            // เป็น sitemap index: ตามเข้าไปอีกชั้นเดียวเพื่อให้เห็นหน้าจริง ไม่ไล่ทั้งต้นไม้
            if ($sitemap->isIndex) {
                $merged = self::followIndex($fetcher, $sitemap, $lookFor);
                if ($merged !== null) {
                    return [$response, $merged, $candidate];
                }
            }

            return [$response, $sitemap, $candidate];
        }

        return [$lastResponse, Sitemap::invalid(), null];
    }

    private static function followIndex(Fetcher $fetcher, Sitemap $index, string $lookFor): ?Sitemap
    {
        $best = null;

        foreach (array_slice($index->entries, 0, 5) as $child) {
            $response = $fetcher->get($child['loc'], Fetcher::MAX_XML_BYTES);
            if (! $response->ok()) {
                continue;
            }

            $childMap = Sitemap::parse($response->body, $lookFor);
            if (! $childMap->valid) {
                continue;
            }

            // sitemap ย่อยที่มีหน้าที่เรากำลังตรวจอยู่ ชนะเสมอ
            if ($childMap->matchedEntry !== null) {
                return $childMap;
            }

            $best ??= $childMap;
        }

        return $best;
    }
}
