<?php

namespace App\Audit\Http;

use Composer\CaBundle\CaBundle;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\RequestOptions;
use Psr\Http\Message\UriInterface;
use Throwable;

/**
 * ดึงหน้าเว็บในมุมมองเดียวกับ AI crawler: HTTP อย่างเดียว ไม่รัน JavaScript
 *
 * เราไม่ปลอม User-Agent เป็น GPTBot/ClaudeBot เพราะเป็นการแอบอ้างบริการอื่น
 * แต่ประกาศตัวตรง ๆ แล้วไปตรวจ "กฎใน robots.txt ที่มีต่อบอทเหล่านั้น" แทน
 */
final class Fetcher
{
    /** ใช้เมื่อยังไม่ได้ตั้ง GEO_AUDIT_USER_AGENT ใน .env */
    public const DEFAULT_USER_AGENT = 'GeoAuditBot/1.0 (GEO/AEO readiness checker)';

    /**
     * ชื่อที่ใช้แนะนำตัวกับเว็บปลายทาง
     *
     * อ่านจาก config เพื่อให้คนที่นำเครื่องมือไปใช้ตั้งช่องทางติดต่อของตัวเองได้
     * ต้องเผื่อกรณีเรียกจากเทสที่ไม่ได้บูต Laravel ด้วย config() จึงอาจโยน exception
     */
    /** เปิดให้ตรวจ localhost / วงแลนได้หรือไม่ - ดูคำอธิบายใน config/geoaudit.php */
    public static function allowsPrivateHosts(): bool
    {
        try {
            return (bool) config('geoaudit.allow_private_hosts', false);
        } catch (Throwable) {
            return false;
        }
    }

    public static function userAgent(): string
    {
        try {
            $configured = trim((string) config('geoaudit.user_agent', ''));
        } catch (Throwable) {
            $configured = '';
        }

        return $configured !== '' ? $configured : self::DEFAULT_USER_AGENT;
    }

    /** หน้า HTML ที่ใหญ่กว่านี้ตัดทิ้ง - ส่วนที่เกินไม่ช่วยการวิเคราะห์ */
    public const MAX_HTML_BYTES = 3_145_728; // 3 MB

    /**
     * sitemap ตามสเปกใหญ่ได้ถึง 50 MB จึงต้องมีเพดานคนละตัวกับหน้า HTML
     * ถ้าใช้เพดานเดียวกัน sitemap ของเว็บใหญ่จะถูกตัดจน XML พัง
     * แล้วเครื่องมือจะรายงานผิดว่า "ไม่มี sitemap" ทั้งที่มีและใช้งานได้ปกติ
     */
    public const MAX_XML_BYTES = 25_165_824; // 24 MB

    private Client $client;

    private readonly UrlGuard $guard;

    private readonly int $timeoutSeconds;

    // ประกาศ property เองแทน constructor promotion เพราะ readonly ที่ promote แล้ว
    // จะถูกกำหนดค่าตั้งแต่ตอนรับพารามิเตอร์ กำหนดค่าเริ่มต้นทีหลังใน constructor ไม่ได้
    public function __construct(?UrlGuard $guard = null, int $timeoutSeconds = 20)
    {
        $this->guard = $guard ?? new UrlGuard(allowPrivate: self::allowsPrivateHosts());
        $this->timeoutSeconds = $timeoutSeconds;

        $this->client = new Client([
            RequestOptions::HTTP_ERRORS     => false,
            RequestOptions::TIMEOUT         => $this->timeoutSeconds,
            RequestOptions::CONNECT_TIMEOUT => 10,
            // php.ini ที่ตั้ง curl.cainfo ผิดจะทำให้ทุก request https ล้มด้วย cURL 77
            // ให้ composer/ca-bundle หาที่ตั้งของ CA ที่ใช้ได้จริงบนเครื่องนี้แทน
            RequestOptions::VERIFY          => CaBundle::getSystemCaRootBundlePath(),
            RequestOptions::HEADERS         => [
                'User-Agent'      => self::userAgent(),
                'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.5',
                'Accept-Language' => 'th,en;q=0.8',
                'Accept-Encoding' => 'gzip, deflate',
            ],
        ]);
    }

    public function get(string $url, int $maxBytes = self::MAX_HTML_BYTES): FetchedResponse
    {
        try {
            $url = $this->guard->validate($url);
        } catch (Throwable $e) {
            return FetchedResponse::failed($url, $e->getMessage());
        }

        $chain   = [];
        $started = microtime(true);

        try {
            $response = $this->client->get($url, [
                RequestOptions::ALLOW_REDIRECTS => [
                    'max'             => 5,
                    'strict'          => true,
                    'referer'         => false,
                    'protocols'       => ['http', 'https'],
                    'track_redirects' => true,
                    'on_redirect'     => function ($request, $response, UriInterface $to) {
                        $this->guard->assertPublicHost($to->getHost());
                    },
                ],
            ]);
        } catch (RequestException $e) {
            return FetchedResponse::failed($url, $this->explain($e));
        } catch (Throwable $e) {
            return FetchedResponse::failed($url, $e->getMessage());
        }

        $elapsed = (microtime(true) - $started) * 1000;
        $chain   = $response->getHeader('X-Guzzle-Redirect-History');
        $final   = $chain === [] ? $url : (string) end($chain);

        // อ่านเป็นก้อนจนถึงเพดาน - read() ครั้งเดียวไม่รับประกันว่าได้ครบตามที่ขอ
        $stream = $response->getBody();
        $body = '';
        while (! $stream->eof() && strlen($body) <= $maxBytes) {
            $chunk = $stream->read(262_144);
            if ($chunk === '') {
                break;
            }
            $body .= $chunk;
        }

        $truncated = strlen($body) > $maxBytes;
        if ($truncated) {
            $body = substr($body, 0, $maxBytes);
        }

        return new FetchedResponse(
            requestedUrl: $url,
            finalUrl: $final,
            status: $response->getStatusCode(),
            headers: $response->getHeaders(),
            body: $body,
            elapsedMs: round($elapsed, 1),
            redirectChain: array_values(array_map('strval', $chain)),
            truncated: $truncated,
        );
    }

    private function explain(RequestException $e): string
    {
        $msg = $e->getMessage();

        return match (true) {
            str_contains($msg, 'SSL certificate') || str_contains($msg, 'certificate verify') => 'ใบรับรอง SSL ของเว็บนี้มีปัญหา ทำให้เชื่อมต่อแบบปลอดภัยไม่ได้',
            str_contains($msg, 'Could not resolve host')                                      => 'หาโดเมนนี้ไม่เจอ (DNS)',
            str_contains($msg, 'timed out') || str_contains($msg, 'Timeout')                  => "เว็บไม่ตอบภายใน {$this->timeoutSeconds} วินาที",
            str_contains($msg, 'Connection refused')                                          => 'เซิร์ฟเวอร์ปฏิเสธการเชื่อมต่อ',
            default                                                                           => 'เชื่อมต่อไม่สำเร็จ: '.strtok($msg, "\n"),
        };
    }
}
