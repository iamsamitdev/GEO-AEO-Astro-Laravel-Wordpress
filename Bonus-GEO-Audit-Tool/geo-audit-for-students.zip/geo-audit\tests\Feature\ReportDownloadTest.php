<?php

namespace Tests\Feature;

use App\Models\PageResult;
use App\Models\Report;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * ปุ่มดาวน์โหลด JSON ต้องบันทึกเป็นไฟล์จริง ไม่ใช่เปิดแสดงในแท็บ
 *
 * ข้อแตกต่างอยู่ที่ header ล้วน ๆ ถ้าใครเผลอเปลี่ยนกลับไปเป็น
 * response()->json() หรือ Content-Disposition: inline พฤติกรรมจะเปลี่ยนแบบเงียบ ๆ
 * โดยที่หน้าเว็บยังดูปกติทุกอย่าง เทสนี้จึงล็อกไว้ที่ header
 */
class ReportDownloadTest extends TestCase
{
    use RefreshDatabase;

    public function test_ดาวน์โหลด_json_เป็นไฟล์แนบพร้อมชื่อที่อ่านออก(): void
    {
        $report = $this->makeReport('url', 'https://www.itgenius.co.th/blog/post');

        $response = $this->get(route('reports.json', $report));

        $response->assertOk();
        $response->assertHeader('Content-Disposition', 'attachment; filename="geo-audit-www-itgenius-co-th-'
            . $report->createdAtLocal()->format('Ymd-Hi') . '.json"');
        $this->assertStringContainsString('attachment', $response->headers->get('Content-Disposition'));
    }

    public function test_ชื่อไฟล์ของโหมดอัปโหลดใช้ชื่อไฟล์ที่ส่งมา(): void
    {
        $report = $this->makeReport('upload', 'dist.zip');

        $response = $this->get(route('reports.json', $report));

        $this->assertStringContainsString('filename="geo-audit-dist-', $response->headers->get('Content-Disposition'));
    }

    public function test_เนื้อหาที่ดาวน์โหลดเป็น_json_ที่อ่านได้และมีข้อมูลครบ(): void
    {
        $report = $this->makeReport('url', 'https://example.com/page');

        $body = $this->get(route('reports.json', $report))->getContent();

        $data = json_decode($body, true);

        $this->assertSame(JSON_ERROR_NONE, json_last_error(), 'ไฟล์ที่ดาวน์โหลดต้อง parse เป็น JSON ได้');
        $this->assertSame('GEO Audit', $data['tool']);
        $this->assertSame(72, $data['score']);
        $this->assertArrayHasKey('categoryWeights', $data, 'ต้องมีน้ำหนักหมวดติดไปด้วย ไม่งั้นตีความคะแนนย้อนหลังไม่ได้');
        $this->assertCount(1, $data['pages']);
        $this->assertSame('title', $data['pages'][0]['audits'][0]['id']);
    }

    public function test_ภาษาไทยไม่ถูก_escape_เป็นรหัส_unicode(): void
    {
        $report = $this->makeReport('url', 'https://example.com/page');

        $body = $this->get(route('reports.json', $report))->getContent();

        // ถ้าไม่ใส่ JSON_UNESCAPED_UNICODE ภาษาไทยจะกลายเป็นลำดับ ย ที่คนเปิดอ่านเองไม่ได้
        $this->assertStringContainsString('ยาวพอดี', $body);
        $this->assertStringNotContainsString('\u0e', $body);
    }

    private function makeReport(string $mode, string $target): Report
    {
        $report = Report::create([
            'mode' => $mode,
            'target' => $target,
            'status' => 'done',
            'score' => 72,
        ]);

        PageResult::create([
            'report_id' => $report->id,
            'position' => 0,
            'url' => 'https://example.com/page',
            'page_type' => 'other',
            'score' => 72,
            'http_status' => 200,
            'load_ms' => 120,
            'bytes' => 4096,
            'payload' => [
                'url' => 'https://example.com/page',
                'score' => 72,
                'categories' => ['seo' => ['label' => 'On-Page SEO', 'weight' => 20, 'score' => 72]],
                'audits' => [
                    [
                        'id' => 'title',
                        'title' => 'title ยาวพอดีและสื่อความ',
                        'category' => 'seo',
                        'weight' => 2.5,
                        'score' => 0.8,
                        'verdict' => 'average',
                        'displayValue' => '64 ตัวอักษร',
                        'details' => [],
                        'fix' => '',
                        'byAi' => false,
                    ],
                ],
            ],
        ]);

        return $report->fresh();
    }
}
