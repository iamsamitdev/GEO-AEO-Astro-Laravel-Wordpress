<?php

namespace App\Audit\Content;

/**
 * ส่วนหนึ่งของเนื้อหา = หัวข้อ + ย่อหน้าที่ตามมาจนถึงหัวข้อถัดไป
 *
 * นี่คือหน่วยที่ระบบ retrieval ของ AI ตัดไปใช้จริง (chunk)
 * การให้คะแนน AEO เกือบทั้งหมดทำงานบนหน่วยนี้ ไม่ใช่บนทั้งหน้า
 */
final class Section
{
    /** @param list<string> $paragraphs */
    public function __construct(
        public readonly ?Heading $heading,
        public readonly array $paragraphs,
        public readonly int $listItems = 0,
        public readonly int $tables = 0,
    ) {}

    public function title(): string
    {
        return $this->heading?->text ?? '';
    }

    public function text(): string
    {
        return trim(implode(' ', $this->paragraphs));
    }

    public function firstParagraph(): string
    {
        return $this->paragraphs[0] ?? '';
    }

    public function isEmpty(): bool
    {
        return $this->paragraphs === [] && $this->listItems === 0 && $this->tables === 0;
    }
}
